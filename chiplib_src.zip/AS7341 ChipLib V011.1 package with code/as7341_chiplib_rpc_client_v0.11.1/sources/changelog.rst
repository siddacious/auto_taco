ams software changelog (www.ams.com)
-------------------------------------------------------------------------------

Overview

        This document lists all notable changes to AS7341 ChipLib RPC client

*******************************************************************************
Version 0.11.0
*******************************************************************************

Version comment

        Added synchronization features


Added

        * Added functions for synchronization
        * Added function to start bootloader for external DFU software


Changed

        * Updated all sub-components


Deprecated

        n/a


Removed

        n/a


Fixed

        n/a


Known issues & limitations

        n/a

*******************************************************************************
Version 0.10.0
*******************************************************************************

Version comment

        First release version based on ChipLib v0.10.1


Added

        * ChipLib v0.10.1
        * RPC protocol v1.0.0


Changed

        n/a


Deprecated

        n/a


Removed

        n/a


Fixed

        n/a


Known issues & limitations

        n/a
