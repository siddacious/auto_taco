/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "as7341_chiplib.h"
#include "as7341_chiplib_rpc.h"
#include "as7341_rpc_version.h"
#include "as7341_typedefs.h"
#include "client_communication.h"
#include "error_codes.h"

#include "cmd_base_definition.h"
#include "cmd_chiplib_definition.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

struct chiplib_data {
    as7341_callback_t callback;
    void *p_cb_param;
    volatile enum as7341_states state;
    volatile err_code_t error;
    volatile uint8_t *p_measure_data;
    volatile uint32_t measure_data_size;
};

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static struct chiplib_data g_chiplib_data[NUM_SUPPORTED_DEVICES] = {{0}};

/* Only one interface is supported */
static void *gp_com_handle = NULL;
static char g_interface_description[40];
static uint8_t g_init_counter = 0;

/******************************************************************************
 *                              LOCAL FUNCTIONS                               *
 ******************************************************************************/

static void chiplib_callback(uint8_t dev_id, uint8_t msg_id, uint8_t error, uint8_t *p_data, uint32_t size,
                             void *p_callback_data)
{
    uint8_t *p_measure_data;
    void *p_payload;
    void *p_items;
    uint16_t size_16;
    uint32_t items_size;

    M_UNUSED_PARAM(p_callback_data);

    if (dev_id >= NUM_SUPPORTED_DEVICES) {
        return;
    }

    if (CMD_ID_CHIPLIB_CALLBACK == msg_id) {

        if (NULL != g_chiplib_data[dev_id].callback) {
            if (sizeof(size_16) < size) {
                p_payload = p_data + sizeof(size_16);
                size_16 = *((uint16_t *)p_data);
                p_items = p_data + size_16 + sizeof(size_16);
                items_size = size - sizeof(size_16) - size_16;
            } else {
                p_payload = NULL;
                size_16 = 0;
                p_items = NULL;
                items_size = 0;
            }
            g_chiplib_data[dev_id].callback(dev_id, error, p_payload, (uint32_t)size_16, p_items, items_size,
                                            g_chiplib_data[dev_id].p_cb_param);
        } else if (NULL == g_chiplib_data[dev_id].p_measure_data) {
            p_measure_data = malloc(size + sizeof(error));
            if (p_measure_data) {
                p_measure_data[0] = error;
                memcpy(p_measure_data + 1, p_data, size);
                g_chiplib_data[dev_id].p_measure_data = p_measure_data;
                g_chiplib_data[dev_id].measure_data_size = size + sizeof(error);
            }
        }
    } else if (CMD_ID_CHIPLIB_STATE == msg_id) {
        g_chiplib_data[dev_id].state = (enum as7341_states)p_data[0];
        g_chiplib_data[dev_id].error = (err_code_t)p_data[1];
    }
}

/******************************************************************************
 *                              GLOBAL FUNCTIONS                              *
 ******************************************************************************/

as7341_rpc_version_t CHIPLIB_DECLDIR as7341_get_version(void)
{
    as7341_rpc_version_t version = {AS7341_RPC_VER_MAJOR, AS7341_RPC_VER_MINOR, AS7341_RPC_VER_PATCH};

    return version;
}

err_code_t CHIPLIB_DECLDIR as7341_get_measure_data(const uint8_t device, uint8_t *p_error, void *p_data,
                                                   uint32_t *p_data_size, void *p_items, uint32_t *p_items_size)
{
    uint16_t measure_data_size_16, item_data_size_16;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_error);
    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_NULL_POINTER(p_data_size);
    M_CHECK_NULL_POINTER(p_items_size);

    if (NULL == g_chiplib_data[device].p_measure_data ||
        (sizeof(*p_error) + sizeof(uint16_t)) >= g_chiplib_data[device].measure_data_size) {
        return ERR_NO_DATA;
    }

    measure_data_size_16 = *((uint16_t *)(((uint8_t *)g_chiplib_data[device].p_measure_data) + sizeof(*p_error)));
    if (*p_data_size < measure_data_size_16) {
        return ERR_SIZE;
    }
    *p_error = g_chiplib_data[device].p_measure_data[0];
    memcpy(p_data, (uint8_t *)(g_chiplib_data[device].p_measure_data + 3), measure_data_size_16);
    *p_data_size = (uint32_t)measure_data_size_16;

    /* copy item data */
    if ((NULL != p_items) && (0 < *p_items_size) &&
        (0 < (g_chiplib_data[device].measure_data_size - sizeof(*p_error) - sizeof(measure_data_size_16) -
              measure_data_size_16))) {
        item_data_size_16 = g_chiplib_data[device].measure_data_size - sizeof(*p_error) - sizeof(measure_data_size_16) -
                            measure_data_size_16;
        memcpy(p_items,
               (uint8_t *)(g_chiplib_data[device].p_measure_data) + sizeof(*p_error) + sizeof(measure_data_size_16) +
                   measure_data_size_16,
               item_data_size_16);
        *p_items_size = (uint32_t)item_data_size_16;
    } else {
        *p_items_size = 0;
    }

    if (NULL != g_chiplib_data[device].p_measure_data) {
        free((uint8_t *)g_chiplib_data[device].p_measure_data);
        g_chiplib_data[device].p_measure_data = NULL;
        g_chiplib_data[device].measure_data_size = 0;
    }

    return ERR_SUCCESS;
}

err_code_t CHIPLIB_DECLDIR as7341_set_sync_pulse_on_start(uint8_t enable)
{
    uint32_t receive_size = 0;

    return com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_SET_EXT_START_SYNC, 0, &enable, sizeof(enable),
                                      NULL, &receive_size);
}

err_code_t CHIPLIB_DECLDIR as7341_set_sync(uint32_t period_us)
{
    uint32_t receive_size = 0;

    return com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_SET_SYNC, 0, &period_us, sizeof(period_us), NULL,
                                      &receive_size);
}

err_code_t CHIPLIB_DECLDIR as7341_start_bootloader(void)
{
    err_code_t result;
    uint32_t receive_size = 0;

    result = com_client_transmit_packet(gp_com_handle, CMD_BASE_ID_SYS_START_BL, 0, NULL, 0, NULL, &receive_size);
    if (ERR_TIMEOUT == result) {
        result = ERR_SUCCESS;
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_firmware_name(char *p_name, uint8_t size)
{
    err_code_t result;
    uint32_t receive_size = size - 1;

    M_CHECK_NULL_POINTER(p_name);

    result = com_client_transmit_packet(gp_com_handle, CMD_BASE_ID_APPL_NAME, 0, NULL, 0, p_name, &receive_size);
    if (ERR_SUCCESS == result) {
        p_name[receive_size] = 0;
    }
    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_firmware_version(char *p_version, uint8_t size)
{
    err_code_t result;
    uint32_t receive_size = size - 1;

    M_CHECK_NULL_POINTER(p_version);

    result = com_client_transmit_packet(gp_com_handle, CMD_BASE_ID_VERSION, 0, NULL, 0, p_version, &receive_size);
    if (ERR_SUCCESS == result) {
        p_version[receive_size] = 0;
    }
    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_initialize(uint8_t device, as7341_callback_t p_callback, const void *p_cb_param,
                                             const char *p_remote)
{
    err_code_t result;
    uint8_t msg_ids[2] = {CMD_ID_CHIPLIB_CALLBACK, CMD_ID_CHIPLIB_STATE};
    uint32_t receive_size = 0;
    uint32_t copy_size;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    g_chiplib_data[device].callback = p_callback;
    g_chiplib_data[device].p_cb_param = (void *)p_cb_param;
    g_chiplib_data[device].p_measure_data = NULL;
    g_chiplib_data[device].measure_data_size = 0;
    g_chiplib_data[device].state = STATE_CONFIG;
    g_chiplib_data[device].error = ERR_SUCCESS;

    copy_size = strlen(p_remote);
    if (sizeof(g_interface_description) < copy_size) {
        copy_size = sizeof(g_interface_description);
    }

    if (NULL == gp_com_handle) {
        result = com_client_connect(&gp_com_handle, p_remote, chiplib_callback, NULL, msg_ids, sizeof(msg_ids));
        if (ERR_SUCCESS == result) {
            memcpy(g_interface_description, p_remote, copy_size);
            g_init_counter = 0;
        }
    } else {
        /* Check if new interface description is equal to the configured one */
        if (0 == memcmp(g_interface_description, p_remote, copy_size)) {
            result = ERR_SUCCESS;
        } else {
            result = ERR_COM_INTERFACE;
        }
    }

    if (ERR_SUCCESS == result) {
        result =
            com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_INITIALIZE, device, NULL, 0, NULL, &receive_size);
    }

    if (ERR_SUCCESS == result) {
        g_init_counter++;
    } else {
        /* Do not check the return code here, because we don't want to overwrite the real error code.
           This function helps to free the communication interface */
        as7341_shutdown(device);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_shutdown(uint8_t device)
{
    err_code_t result, result_client;
    uint32_t receive_size = 0;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    if (NULL != g_chiplib_data[device].p_measure_data) {
        free((uint8_t *)(g_chiplib_data[device].p_measure_data));
        g_chiplib_data[device].p_measure_data = NULL;
        g_chiplib_data[device].measure_data_size = 0;
    }

    result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_SHUTDOWN, device, NULL, 0, NULL, &receive_size);
    g_chiplib_data[device].state = STATE_CONFIG;
    g_chiplib_data[device].error = ERR_ACCESS;

    if (1 >= g_init_counter) {
        /* the function must not overwrite an old error code */
        result_client = com_client_disconnect(&gp_com_handle);
        if (ERR_SUCCESS == result) {
            result = result_client;
        }
        g_init_counter = 0;
        g_interface_description[0] = 0;
        gp_com_handle = NULL;
    } else {
        g_init_counter--;
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_set_configuration(uint8_t device, uint8_t *p_data, uint32_t size)
{
    uint32_t recv_size = 0;
    err_code_t result;
    uint8_t *p_datagram;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    /* create send data buffer */
    p_datagram = (uint8_t *)malloc(size);
    if (NULL == p_datagram) {
        result = ERR_MEMORY;
    } else {
        result = ERR_SUCCESS;
    }

    if (ERR_SUCCESS == result) {
        memcpy(p_datagram, p_data, size);
        result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_SET_CONFIG, device, p_datagram, size, NULL,
                                            &recv_size);
    }

    if (NULL != p_datagram) {
        free(p_datagram);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_configuration(uint8_t device, uint8_t *p_data, uint32_t *p_size)
{
    uint8_t *p_datagram;
    err_code_t result;
    uint32_t recv_size;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_size);

    if ((0 != *p_size) && (NULL == p_data)) {
        return ERR_POINTER;
    }

    /* create send data buffer */
    p_datagram = (uint8_t *)malloc(4);
    if (NULL == p_datagram) {
        result = ERR_MEMORY;
    } else {
        result = ERR_SUCCESS;
    }

    if (ERR_SUCCESS == result) {
        memcpy(p_datagram, p_size, sizeof(*p_size));

        /* ask for necessary memory size */
        if (0 == *p_size) {
            recv_size = sizeof(*p_size);
            result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_GET_CONFIG, device, p_datagram,
                                                sizeof(*p_size), (uint8_t *)p_size, &recv_size);
        } else {
            result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_GET_CONFIG, device, p_datagram,
                                                sizeof(*p_size), p_data, p_size);
        }
    }

    if (NULL != p_datagram) {
        free(p_datagram);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_set_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
{
    uint32_t receive_size = 0;
    uint8_t *p_datagram;
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    /* We reserved only one byte in protocol. Therefore check id size! */
    if (0xFF < (uint32_t)id) {
        return ERR_ARGUMENT;
    }

    /* create send data buffer */
    p_datagram = (uint8_t *)malloc(1 + size);
    if (NULL == p_datagram) {
        result = ERR_MEMORY;
    } else {
        result = ERR_SUCCESS;
    }

    if (ERR_SUCCESS == result) {
        p_datagram[0] = (uint8_t)id;
        memcpy(p_datagram + 1, p_data, size);
        result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_SET_ITEM, device, p_datagram, 1 + size, NULL,
                                            &receive_size);
    }

    if (NULL != p_datagram) {
        free(p_datagram);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
{
    uint32_t receive_size = size;
    uint8_t *p_datagram;
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    /* We reserved only one byte in protocol. Therefore check id size! */
    if (0xFF < (uint32_t)id) {
        return ERR_ARGUMENT;
    }

    /* create send data buffer */
    p_datagram = (uint8_t *)malloc(2);
    if (NULL == p_datagram) {
        result = ERR_MEMORY;
    } else {
        result = ERR_SUCCESS;
    }

    if (ERR_SUCCESS == result) {
        p_datagram[0] = (uint8_t)id;
        p_datagram[1] = size;
        result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_GET_ITEM, device, p_datagram, 2, p_data,
                                            &receive_size);
    }

    if (NULL != p_datagram) {
        free(p_datagram);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_start_measurement(uint8_t device)
{
    err_code_t result;
    uint32_t receive_size = 0;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    result = com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_START, device, NULL, 0, NULL, &receive_size);
    if (ERR_SUCCESS == result) {
        g_chiplib_data[device].state = STATE_MEASURE;
        g_chiplib_data[device].error = ERR_SUCCESS;
    }
    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_execute_state_machine(const uint8_t device, enum as7341_states *p_state)
{
    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_state);

    *p_state = g_chiplib_data[device].state;

    return g_chiplib_data[device].error;
}

err_code_t CHIPLIB_DECLDIR as7341_abort_measurement(uint8_t device)
{
    uint32_t receive_size = 0;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    return com_client_transmit_packet(gp_com_handle, CMD_ID_CHIPLIB_ABORT, device, NULL, 0, NULL, &receive_size);
}
