/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_CHIP_LIB_RPC_H__
#define __AS7341_CHIP_LIB_RPC_H__

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/*!
 * \file      as7341_chiplib_rpc.h
 * \authors   ARIT
 * \copyright ams
 * \addtogroup chiplib_group_rpc
 *
 * \brief This is an extension to the chip library for ams spectral sensor AS7341.
 *
 * @{
 */

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include <stdint.h>

#include "error_codes.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#if defined POSIX
#define CHIPLIB_DECLDIR
#else
#if defined CHIPLIB_DLL_EXPORT
#define CHIPLIB_DECLDIR __declspec(dllexport)
#elif defined CHIPLIB_DLL_IMPORT
#define CHIPLIB_DECLDIR __declspec(dllimport)
#else
#define CHIPLIB_DECLDIR
#endif
#endif

/*! version structure for the RPC-library */
typedef struct {
    uint8_t major; /*!< Major version information */
    uint8_t minor; /*!< Minor version information */
    uint8_t patch; /*!< Patch level of library */
} as7341_rpc_version_t;

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/*!
 * \brief This function sets a cyclic sync signal on AS7341 GPIO pin
 *
 * \attention: This function is only supported on ChipLib-RPC.
 *
 * \param[in] period_us         Sync period in micro seconds. Zero deactivates the sync signal

 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_ARGUMENT       Argument device is not supported.
 */
err_code_t CHIPLIB_DECLDIR as7341_set_sync(uint32_t period_us);

/*!
 * \brief This function sets one sync pulse on Unicom-Board Output GPIO3
 * during the call of the function start_measurement.
 *
 * The signal is low active and the signal is a peak with a width of 1ms.
 *
 * \attention: This function is only supported on ChipLib-RPC.
 *
 * \note It can't be used to synchronize AS7341 itself. Only external devices like spectrometers are supported.
 *
 * \param[in] enable         Sync period in micro seconds. Zero deactivates the sync signal

 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_ARGUMENT       Argument device is not supported.
 */
err_code_t CHIPLIB_DECLDIR as7341_set_sync_pulse_on_start(uint8_t enable);

/*!
 * \brief Starts the bootloader for firmware update
 *
 * \attention: To switch back to firmware, use DFU tool or switch board off and on.
 *
 * \retval ::ERR_SUCCESS        Function returns without error.
 */
err_code_t CHIPLIB_DECLDIR as7341_start_bootloader(void);

/*!
 * \brief Can read the data manually if no callback function is supported (like Labview)
 *
 * This function can readout the first measurement data if the function ::as7341_initialize gets no callback function.
 * Further data will be dropped. After reading the data, new data will be saved internally and can be taken by this
 * function.
 *
 * \attention: This function is only supported on ChipLib-RPC.
 *
 * \param[in] device            Handle to the device (default 0, only for multi device purposes).
 * \param[out] p_error          Pointer to memory, where error code can be saved.
 * \param[out] p_data           Pointer to memory, where measurement data can be saved
 * \param[inout] p_data_size    Takes the size of p_data-buffer. Function returns here the written bytes.
 * \param[out] p_items          Pointer to memory, where additional item data can be saved
 * \param[inout] p_items_size   Takes the size of p_items-buffer. Function returns here the written bytes.
 *
 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_POINTER        Detects NULL pointer in arguments.
 * \retval ::ERR_ARGUMENT       Argument device is not supported.
 * \retval ::ERR_NO_DATA        No data available.
 * \retval ::ERR_SIZE           The given buffers are too small.
 */
err_code_t CHIPLIB_DECLDIR as7341_get_measure_data(const uint8_t device, uint8_t *p_error, void *p_data,
                                                   uint32_t *p_data_size, void *p_items, uint32_t *p_items_size);

/*!
 * \brief Returns the version information of the library
 *
 * \returns version information, see \ref rpc_version_t
 */
as7341_rpc_version_t CHIPLIB_DECLDIR as7341_get_version(void);

/*!
 * \brief Readout the firmware name

 * \attention: This function is only supported on ChipLib-RPC.
 *
 * \param[out] p_name           Pointer to buffer, where firmware name can be saved
 * \param[in] size              Size of p_name buffer
 *
 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_POINTER        Detects NULL pointer in arguments.
 */
err_code_t CHIPLIB_DECLDIR as7341_get_firmware_name(char *p_name, uint8_t size);

/*!
 * \brief Readout the version of the firmware

 * \attention: This function is only supported on ChipLib-RPC.
 *
 * \param[out] p_version        Pointer to buffer, where version string can be saved
 * \param[in] size              Size of p_version buffer
 *
 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_POINTER        Detects NULL pointer in arguments.
 */
err_code_t CHIPLIB_DECLDIR as7341_get_firmware_version(char *p_version, uint8_t size);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* __AS7341_CHIP_LIB_H__ */
