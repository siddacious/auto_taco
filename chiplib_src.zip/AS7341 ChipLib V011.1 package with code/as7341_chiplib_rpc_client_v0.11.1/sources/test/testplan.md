# Testplan AS7341 ChipLib RPC

## integration test

* Execute unit tests of ChipLib directly
* Add special stress tests for unicom communication
* Add tests for special labview data handling