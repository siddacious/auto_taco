/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "gtest/gtest.h"
#include <cstdio>
#include <stdlib.h>

#if defined(REMOTE)
char g_interface_description[30] = REMOTE;
#else
const char *comParam = "--REMOTE=";
char g_interface_description[30];

GTEST_API_ int main(int argc, char **argv)
{
    int i;

    printf("Running main() from %s\n", __FILE__);

    for (i = 0; i < argc; i++) {
        printf("Printing args %d: %s\n", i, argv[i]);
        if (NULL != strstr(argv[i], comParam)) {
            if ((strlen(argv[i]) - strlen(comParam) + 1) < sizeof(g_interface_description)) {
                memset(g_interface_description, 0, strlen(argv[i]) - strlen(comParam) + 1);
                memcpy(g_interface_description, argv[i] + strlen(comParam), strlen(argv[i]) - strlen(comParam) + 1);
            }
        }
    }

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
    return 0;
}
#endif