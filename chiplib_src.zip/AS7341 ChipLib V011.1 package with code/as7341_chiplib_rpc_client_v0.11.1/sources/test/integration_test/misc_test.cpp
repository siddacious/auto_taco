#include "as7341_chiplib.h"
#include "as7341_chiplib_rpc.h"
#include "as7341_rpc_version.h"
#include "error_codes.h"
#include "gtest/gtest.h"

#define DEV_ID 0
#define MAX_TEST_RUNS 2000

extern char g_interface_description[30];
uint32_t g_testRuns = 0;

void misc_test_measurement_callback(uint8_t device, uint8_t error, void *p_data, uint32_t data_size, void *p_items,
                                    uint32_t items_size, void *p_cb_param)
{
    M_UNUSED_PARAM(device);
    M_UNUSED_PARAM(error);
    M_UNUSED_PARAM(p_data);
    M_UNUSED_PARAM(data_size);
    M_UNUSED_PARAM(p_items);
    M_UNUSED_PARAM(items_size);
    M_UNUSED_PARAM(p_cb_param);
}

class misc_test : public ::testing::Test
{
  public:
    misc_test()
    {
        // initialization code here
    }

    void SetUp()
    {
        // code here will execute just before the test ensues
    }

    void TearDown()
    {
        // code here will be called just after the test completes
        // ok to through exceptions from here if need be
        ASSERT_EQ(g_testRuns, MAX_TEST_RUNS);
    }

    ~misc_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }

    // put in any custom data members that you need
};

TEST_F(misc_test, parameter_CHANNEL)
{
    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,    CHANNEL_F2,       CHANNEL_F3,  CHANNEL_F4,
                                        CHANNEL_F5,    CHANNEL_F6,       CHANNEL_F7,  CHANNEL_F8,
                                        CHANNEL_CLEAR, CHANNEL_DISABLED, CHANNEL_NIR, CHANNEL_FLICKER};

    g_testRuns = 0;
    while (++g_testRuns < MAX_TEST_RUNS) {
        ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description),
                  ERR_SUCCESS);
        ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);
        as7341_shutdown(DEV_ID);
    }
}

TEST_F(misc_test, init_shutdown_loop)
{
    g_testRuns = 0;
    while (++g_testRuns < MAX_TEST_RUNS) {
        ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description),
                  ERR_SUCCESS);
        ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    }
}

TEST_F(misc_test, astep_loop)
{
    uint16_t astep, expected;

    ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

    g_testRuns = 0;
    while (++g_testRuns < MAX_TEST_RUNS) {
        astep = 0;
        expected = (uint16_t)g_testRuns;
        ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (uint8_t *)&expected, ITEM_SIZE_ASTEP), ERR_SUCCESS);
        ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (uint8_t *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
        ASSERT_EQ(expected, astep);
    }

    ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
}

TEST_F(misc_test, version)
{
    as7341_rpc_version_t version;

    version = as7341_get_version();
    ASSERT_EQ(AS7341_RPC_VER_MAJOR, version.major);
    ASSERT_EQ(AS7341_RPC_VER_MINOR, version.minor);
    ASSERT_EQ(AS7341_RPC_VER_PATCH, version.patch);

    g_testRuns = MAX_TEST_RUNS;
}

TEST_F(misc_test, firmware_name)
{
    char firmware_name[30];

    ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

    ASSERT_EQ(as7341_get_firmware_name(firmware_name, sizeof(firmware_name)), ERR_SUCCESS);

    ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    g_testRuns = MAX_TEST_RUNS;
}

TEST_F(misc_test, firmware_version)
{
    char firmware_version[30];

    ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

    ASSERT_EQ(as7341_get_firmware_version(firmware_version, sizeof(firmware_version)), ERR_SUCCESS);

    ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    g_testRuns = MAX_TEST_RUNS;
}

TEST_F(misc_test, sync_pulse_test)
{
    enum as7341_states state;
    uint16_t exceptect_count = 1;

    /* Only the function call will be tested here. To measure the sync pulse,
       a oscilloscope is necessary for measuring a 1ms low pulse on GPIO3 */

    ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_sync_pulse_on_start(TRUE), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    g_testRuns = MAX_TEST_RUNS;
}

// TEST_F(misc_test, bootloader)
// {
//     ASSERT_EQ(as7341_initialize(DEV_ID, misc_test_measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

//     ASSERT_EQ(as7341_start_bootloader(), ERR_SUCCESS);

//     ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_COM_INTERFACE);
//     g_testRuns = MAX_TEST_RUNS;
// }
