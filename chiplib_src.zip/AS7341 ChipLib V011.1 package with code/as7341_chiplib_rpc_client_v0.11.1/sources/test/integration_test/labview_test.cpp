#include "as7341_chiplib.h"
#include "as7341_chiplib_rpc.h"
#include "as7341_rpc_version.h"
#include "error_codes.h"
#include "gtest/gtest.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define DEV_ID 0

#define MAX_MEASUREMENTS 20
#define MAX_CHANNELS 12
extern char g_interface_description[30];
static uint16_t g_count;

static void logging(osal_id_t osal_id, uint8_t level, const char *module_name, const char *fmt, ...)
{
    static const char *level_names[] = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"};
    uint8_t log_level_index;

    enum { LOG_TRACE = 0, LOG_DEBUG = 20, LOG_INFO = 40, LOG_WARN = 60, LOG_ERROR = 80, LOG_FATAL = 100 };

    /* Get current time */
    struct timeval tv;
    time_t t = time(NULL);
    struct tm *lt = localtime(&t);
    long milliseconds;
    va_list args;
    char buf[32];

    if ((LOG_DEBUG - 10) > level) {
        log_level_index = 0;
    } else if ((LOG_INFO - 10) > level) {
        log_level_index = 1;
    } else if ((LOG_WARN - 10) > level) {
        log_level_index = 2;
    } else if ((LOG_ERROR - 10) > level) {
        log_level_index = 3;
    } else if ((LOG_FATAL - 10) > level) {
        log_level_index = 4;
    } else {
        log_level_index = 5;
    }

    gettimeofday(&tv, NULL);
    milliseconds = tv.tv_usec / 1000;

    /* Log to stderr */
    buf[strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)] = '\0';
    fprintf(stderr, "[%s:%03ld] %-5s <%s%d>: ", buf, milliseconds, level_names[log_level_index], module_name,
            osal_id.dev);
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n");
    fflush(stderr);
}

static void print_measured_values(const uint8_t device, uint16_t id, uint16_t *p_values, uint8_t number)
{
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};
    uint8_t i;
    char string_buffer[100];
    int buffer_pointer = 0;
    buffer_pointer += sprintf(string_buffer, "Data: ");
    for (i = 0; i < number; i++) {
        buffer_pointer += sprintf(string_buffer + buffer_pointer, "%d\t", p_values[i]);
    }
    logging(osal_id, 30, "T_M", "Index: %d, %s", id, string_buffer);
}

class labview_test : public ::testing::Test
{
  public:
    labview_test()
    {
        // initialization code here
    }

    void SetUp()
    {
        // code here will execute just before the test ensues
        ASSERT_EQ(as7341_initialize(DEV_ID, NULL, NULL, g_interface_description), ERR_SUCCESS);
    }

    void TearDown()
    {
        // code here will be called just after the test completes
        // ok to through exceptions from here if need be
        as7341_shutdown(DEV_ID);
    }

    ~labview_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }
};

TEST_F(labview_test, ulf)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    uint16_t led_pattern[ITEM_SIZE_LED_PATTERN / sizeof(uint16_t)];
    uint8_t data[100];
    uint8_t items[30];
    uint8_t error;
    uint32_t data_size;
    uint32_t item_size;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_RESERVED};
    uint64_t serial;

    led_pattern[0] = (0x05 << 8) | 1;
    led_pattern[1] = (0x00 << 8) | 3;
    led_pattern[2] = (0x09 << 8) | 4;
    led_pattern[3] = (0x00 << 8) | 5;
    led_pattern[4] = (0x11 << 8) | 2;
    led_pattern[5] = (0x00 << 8) | 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    measure_items[0] = ITEM_ID_SERIAL;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, (uint8_t *)measure_items, ITEM_SIZE_MEASURE_ITEMS),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_SERIAL, (void *)&serial, ITEM_SIZE_SERIAL), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {

        data_size = sizeof(data);
        item_size = sizeof(items);
        if (ERR_SUCCESS == as7341_get_measure_data(DEV_ID, &error, data, &data_size, items, &item_size)) {
            ASSERT_LE(24, data_size);
            print_measured_values(DEV_ID, g_count, (uint16_t *)data, 12);

            ASSERT_EQ(ITEM_SIZE_SERIAL, item_size);
            ASSERT_EQ(serial, *((uint64_t *)items));

            g_count++;
        }

        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    /* values with LED0 enabled are in saturation */
    // uint16_t max_values[MAX_MEASUREMENTS]{500, 500, 1000, 1000, 1000, 500,  500, 500, 500, 500,
    //                                       500, 500, 500,  500,  1000, 1000, 500, 500, 500, 500};
    // for (i = 0; i < MAX_MEASUREMENTS; i++) {
    //     for (j = 0; j < MAX_CHANNELS; j++) {
    //         ASSERT_GE(max_values[i], g_channels[i][j]);
    //     }
    // }
}
