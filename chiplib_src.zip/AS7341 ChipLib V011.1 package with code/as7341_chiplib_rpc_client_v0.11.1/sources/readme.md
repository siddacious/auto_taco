### Howto build

To build AS7341 Chiplib RPC Client do:

    mkdir build
    cd build
    cmake ..
    cmake --build . --target chip_lib_rpc

