# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""Tests the Chip Library Python Wrapper
"""

from time import sleep

import pytest

from as7341 import ChipLib
from as7341.chiplib.chipclib import ChipLibCError
from as7341.chiplib.errorcodes import ChipLibErrorCodes
from as7341.chiplib.config import (
    Gain,
    ItemIds,
    MeasureType,
    SpectralChannel,
    LedConfig,
    LedPattern,
    LedMasks,
    FifoChannels,
)

@pytest.fixture
def dut(remote):
    """
    Instansiate ChipLib class and initialize
    with given remote string.

    Args:
        remote (pytest.fixture): Remote string from command line args

    Returns:
        ChipLib: object under test
    """
    chip_lib = ChipLib()
    chip_lib.initialize(0, remote)
    yield chip_lib
    chip_lib.shutdown()


class TestChipLibInitialize:
    """Tests the Chip Library Python Wrapper
    """

    def test_initialize(self):
        """Test initialize function without error.
        """
        chiplib = ChipLib()
        chiplib.initialize(0, None)
        chiplib.shutdown()

    def test_initialize_error(self):
        """Test initialize function with error.
        """
        chiplib = ChipLib()
        with pytest.raises(ChipLibCError):
            chiplib.initialize(1, None)

    def test_initialize_with_serial(self, remote):
        """Test initialize with a connection string.
        """
        chiplib = ChipLib()
        chiplib.initialize(0, remote)
        chiplib.shutdown()


class TestChipLibConfig:
    """Tests the configuration interface
    """

    @pytest.fixture(autouse=True)
    def test_fixture(self, remote):
        """Test fixture
        """
        self.chiplib = ChipLib()
        self.chiplib.initialize(0, remote=remote)
        yield
        self.chiplib.shutdown()

    def assertEqual(self, ref, act):
        assert ref == act

    def test_astep(self):
        """Test the getter and setter for astep parameter.
        """
        test_values = [1, 65534]
        for value in test_values:
            self.chiplib.configuration.astep = value
            self.assertEqual(value, self.chiplib.configuration.astep)

    def test_atime(self):
        """Test the getter and setter for atime parameter.
        """
        test_values = [0, 255]
        for value in test_values:
            self.chiplib.configuration.atime = value
            self.assertEqual(value, self.chiplib.configuration.atime)

    def test_itime(self):
        """Test the getter and setter for itime parameter.
        """
        test_values = [6, 46602667]
        for value in test_values:
            self.chiplib.configuration.itime = value
            self.assertEqual(value, self.chiplib.configuration.itime)

    def test_again(self):
        """Test the getter and setter for again parameter.
        """
        for value in Gain:
            self.chiplib.configuration.again = value
            self.assertEqual(value, self.chiplib.configuration.again)

    def test_measure_type(self):
        """Test the getter and setter for measure_type parameter.
        """
        for value in MeasureType:
            self.chiplib.configuration.measure_type = value
            self.assertEqual(value, self.chiplib.configuration.measure_type)

    def test_break_time(self):
        """Test the getter and setter for break_time parameter.
        """
        test_values = [0, 2780, 10000000]
        for value in test_values:
            self.chiplib.configuration.break_time = value

            if 10000000 == value:
                value = 9994430
            self.assertEqual(value, self.chiplib.configuration.break_time)

    def test_channels(self):
        """Test the getter and setter for channels parameter
        """
        test_values = [
            [
                SpectralChannel.NIR,
                SpectralChannel.CLEAR,
                SpectralChannel.F1,
                SpectralChannel.F2,
                SpectralChannel.F3,
                SpectralChannel.F4,
                SpectralChannel.F5,
                SpectralChannel.F6,
                SpectralChannel.F7,
                SpectralChannel.F8,
                SpectralChannel.FLICKER,
                SpectralChannel.DISABLED,
            ],
            [
                SpectralChannel.F1,
                SpectralChannel.F2,
                SpectralChannel.F3,
                SpectralChannel.F4,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
                SpectralChannel.DISABLED,
            ],
        ]
        for value in test_values:
            self.chiplib.configuration.channels = value
            self.assertEqual(value, self.chiplib.configuration.channels)

    def test_version(self):
        """Test the getter for version parameter.
        """
        version = self.chiplib.configuration.version
        print("Chip Library Version: {0[0]}.{0[1]}.{0[2]}.{0[3]}".format(version))
        assert len(version) == 4
        assert sum(version) > 0

    def test_serial(self):
        """Test the getter for serial parameter.
        """
        serial = self.chiplib.configuration.serial
        print("Chip Serial: {0[0]}.{0[1]}".format(serial))
        assert len(serial) == 2
        assert serial[0] > 1451606400 # value must be higher than unix code timestamp 1.01.2016
        assert serial[1] >= 0
        assert serial[1] <= 1

    def test_autozero(self):
        """Test the getter and setter for autozero parameter.
        """
        test_values = [0, 128, 255]
        for value in test_values:
            self.chiplib.configuration.autozero = value
            self.assertEqual(value, self.chiplib.configuration.autozero)

    def test_meas_count(self):
        """Test the getter and setter for meas_count parameter.
        """
        test_values = [0, 128, 65535]
        for value in test_values:
            self.chiplib.configuration.meas_count = value
            self.assertEqual(value, self.chiplib.configuration.meas_count)

    def test_led_pattern(self):
        """Test the getter and setter for led_pattern parameter.
        """
        test_pattern = [
            [LedMasks.INTERN, LedMasks.EXT_2, LedMasks.EXT_4, LedMasks.OUTPUT],
            [LedMasks.EXT_0, LedMasks.EXT_1, LedMasks.EXT_3, LedMasks.EXT_5],
        ]
        test_value = [
            LedPattern(count=1, pattern=test_pattern[0]),
            LedPattern(count=2, pattern=test_pattern[1]),
            LedPattern(count=1, pattern=test_pattern[0]),
            LedPattern(count=1, pattern=test_pattern[1]),
            LedPattern(count=1, pattern=test_pattern[0]),
            LedPattern(count=1, pattern=test_pattern[1]),
            LedPattern(count=1, pattern=test_pattern[0]),
            LedPattern(count=254, pattern=test_pattern[1]),
            LedPattern(count=255, pattern=test_pattern[0]),
            LedPattern(),
            ]
        self.chiplib.configuration.led_pattern = test_value
        self.assertEqual(test_value, self.chiplib.configuration.led_pattern)

    def test_led_wait_time(self):
        """Test the getter and setter of led_wait_time parameter.
        """
        test_values = [0, 10000000]
        for value in test_values:
            self.chiplib.configuration.led_wait_time = value
            self.assertEqual(value, self.chiplib.configuration.led_wait_time)

    def test_interrupt_pin(self):
        """Test the getter and setter of interrupt_pin parameter.
        """
        test_values = [1, 0]
        for value in test_values:
            self.chiplib.configuration.interrupt_pin = value
            self.assertEqual(value, self.chiplib.configuration.interrupt_pin)

    def test_led_intern(self):
        """Test the getter and setter of led_intern parameter.
        """
        test_values = [LedConfig(0, 1000), LedConfig(1, 0)]
        for value in test_values:
            self.chiplib.configuration.led_intern = value
            self.assertEqual(value, self.chiplib.configuration.led_intern)

    def test_led_ext_0(self, sensor):
        """Test the getter and setter of led_ext_0 parameter.
        """
        if sensor in ["a001ha"]:
            test_values = [LedConfig(0, 1), LedConfig(1, 0)]
            for value in test_values:
                self.chiplib.configuration.led_ext_0 = value
                self.assertEqual(value, self.chiplib.configuration.led_ext_0)
        else:
            with pytest.raises(ChipLibCError) as e:
                self.chiplib.configuration.led_ext_0 = LedConfig(0, 1)
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.led_ext_0
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

    def test_led_ext_1(self, sensor):
        """Test the getter and setter of led_ext_1 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                self.chiplib.configuration.led_ext_1 = LedConfig(0, 1)
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.led_ext_1
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            test_values = [LedConfig(0, 1), LedConfig(1, 0)]
            for value in test_values:
                self.chiplib.configuration.led_ext_1 = value
                self.assertEqual(value, self.chiplib.configuration.led_ext_1)

    def test_led_ext_2(self, sensor):
        """Test the getter and setter of led_ext_2 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                self.chiplib.configuration.led_ext_2 = LedConfig(0, 1)
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.led_ext_2
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            test_values = [LedConfig(0, 1), LedConfig(1, 0)]
            for value in test_values:
                self.chiplib.configuration.led_ext_2 = value
                self.assertEqual(value, self.chiplib.configuration.led_ext_2)

    def test_led_ext_3(self, sensor):
        """Test the getter and setter of led_ext_3 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                self.chiplib.configuration.led_ext_3 = LedConfig(0, 1)
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.led_ext_3
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            test_values = [LedConfig(0, 1), LedConfig(1, 0)]
            for value in test_values:
                self.chiplib.configuration.led_ext_3 = value
                self.assertEqual(value, self.chiplib.configuration.led_ext_3)

    def test_led_ext_4(self, sensor):
        """Test the getter and setter of led_ext_4 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                self.chiplib.configuration.led_ext_4 = LedConfig(0, 1)
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.led_ext_4
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            test_values = [LedConfig(0, 1), LedConfig(1, 0)]
            for value in test_values:
                self.chiplib.configuration.led_ext_4 = value
                self.assertEqual(value, self.chiplib.configuration.led_ext_4)

    def test_led_ext_5(self):
        """Test the getter and setter of led_ext_5 parameter.
        """
        with pytest.raises(ChipLibCError) as e:
            self.chiplib.configuration.led_ext_5 = LedConfig(0, 1)
        assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

        with pytest.raises(ChipLibCError) as e:
            _ = self.chiplib.configuration.led_ext_5
        assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

    def test_output(self):
        """Test the getter and setter of output parameter.
        """
        test_values = [1, 0]
        for value in test_values:
            self.chiplib.configuration.output = value
            self.assertEqual(value, self.chiplib.configuration.output)

    def test_temp_ext_0(self):
        """Test the getter of temp_ext_0 parameter.
        """
        with pytest.raises(ChipLibCError) as e:
            _ = self.chiplib.configuration.temp_ext_0
        assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

    def test_temp_ext_1(self, sensor):
        """Test the getter of temp_ext_1 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.temp_ext_1
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            assert self.chiplib.configuration.temp_ext_1 > 0

    def test_temp_ext_2(self, sensor):
        """Test the getter of temp_ext_2 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.temp_ext_2
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            assert self.chiplib.configuration.temp_ext_2 > 0

    def test_temp_ext_3(self, sensor):
        """Test the getter of temp_ext_3 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.temp_ext_3
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            assert self.chiplib.configuration.temp_ext_3 > 0

    def test_temp_ext_4(self, sensor):
        """Test the getter of temp_ext_4 parameter.
        """
        if sensor in ["a001ha"]:
            with pytest.raises(ChipLibCError) as e:
                _ = self.chiplib.configuration.temp_ext_4
            assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code
        else:
            assert self.chiplib.configuration.temp_ext_4 > 0

    def test_temp_ext_5(self):
        """Test the getter of temp_ext_5 parameter.
        """
        with pytest.raises(ChipLibCError) as e:
            _ = self.chiplib.configuration.temp_ext_5
        assert ChipLibErrorCodes.ERR_NOT_SUPPORTED.value == e.value.error_code

    def test_measure_items(self):
        """Test the getter and setter of measure_item parameter.
        """
        test_values = [
            [
                ItemIds.ASTEP,
                ItemIds.ATIME,
                ItemIds.ITIME,
                ItemIds.AGAIN,
                ItemIds.MEAS_TYPE,
                ItemIds.BREAK,
                ItemIds.CHANNELS,
                ItemIds.VERSION,
                ItemIds.SERIAL,
                ItemIds.AUTOZERO,
            ],
            [
                ItemIds.MEAS_COUNT,
                ItemIds.LED_PATTERN,
                ItemIds.LED_WAIT_TIME,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
                ItemIds.RESERVED,
            ],
            [
                ItemIds.INTERRUPT_PIN,
                ItemIds.LED_INTERN,
                ItemIds.LED_EXT_0,
                ItemIds.LED_EXT_1,
                ItemIds.LED_EXT_2,
                ItemIds.LED_EXT_3,
                ItemIds.LED_EXT_4,
                ItemIds.LED_EXT_5,
                ItemIds.OUTPUT,
                ItemIds.TEMP_EXT_0,
            ],
            [
                ItemIds.TEMP_EXT_1,
                ItemIds.TEMP_EXT_2,
                ItemIds.TEMP_EXT_3,
                ItemIds.TEMP_EXT_4,
                ItemIds.TEMP_EXT_5,
                ItemIds.MEASURE_ITEMS,
                ItemIds.FGAIN,
                ItemIds.FTIME,
                ItemIds.FTIME_US,
                ItemIds.FCHANNELS,
            ],
        ]
        for value in test_values:
            self.chiplib.configuration.measure_items = value
            self.assertEqual(value, self.chiplib.configuration.measure_items)

    def test_fgain(self):
        """Test the getter and setter for fgain parameter.
        """
        for value in Gain:
            self.chiplib.configuration.fgain = value
            self.assertEqual(value, self.chiplib.configuration.fgain)

    def test_ftime(self):
        """Test the getter and setter for ftime parameter.
        """
        test_values = [0, 0x07FF]
        for value in test_values:
            self.chiplib.configuration.ftime = value
            self.assertEqual(value, self.chiplib.configuration.ftime)

    def test_ftime_us(self):
        """Test the getter and setter for ftime_us parameter.
        """
        test_values = [3, 5689]
        for value in test_values:
            self.chiplib.configuration.ftime_us = value
            self.assertEqual(value, self.chiplib.configuration.ftime_us)

    def test_fchannels(self):
        """Test the getter and setter for the fchannels parameter.
        """
        for value in FifoChannels:
            self.chiplib.configuration.fchannels = [value]
            self.assertEqual([value], self.chiplib.configuration.fchannels)

        self.chiplib.configuration.fchannels = list(FifoChannels)
        self.assertEqual(list(FifoChannels), self.chiplib.configuration.fchannels)

    def test_timestamp(self):
        """Test the getter of timestamp parameter.
        """
        t1 = self.chiplib.configuration.timestamp
        sleep(0.01)
        t2 = self.chiplib.configuration.timestamp
        assert (t2-t1) >= 0.01

    def test_auto_gain_range(self):
        """Test the getter and setter for the auto_gain_range parameter.
        """
        # Check default value
        expected_value = [Gain.GAIN_0_5X, Gain.GAIN_0_5X]
        self.assertEqual(expected_value, self.chiplib.configuration.auto_gain_range)

        # Check setter
        expected_value = [Gain.GAIN_1X, Gain.GAIN_512X]
        self.chiplib.configuration.auto_gain_range = expected_value
        self.assertEqual(expected_value, self.chiplib.configuration.auto_gain_range)

    def test_gain_factors(self):
        """Test the getter and setter for the gain_factors parameter.
        """
        # Check default value
        expected_value = [9770, 9770, 9770, 9620, 10000, 10000, 10000, 10000, 10000, 10130, 10320]
        self.assertEqual(expected_value, self.chiplib.configuration.gain_factors)

        # Check setter
        expected_value = [1, 2, 500, 600, 1000, 1001, 10500, 15000, 19000, 19999, 20000]
        self.chiplib.configuration.gain_factors = expected_value
        self.assertEqual(expected_value, self.chiplib.configuration.gain_factors)


class TestChipLibMeasurement:
    """Test of the measurement functionality"""

    @pytest.fixture(autouse=True)
    def test_fixture(self):
        """Test fixture
        """
        self.chiplib = ChipLib()
        self.chiplib.initialize(0, None)
        yield
        self.chiplib.abort_measurement()
        self.chiplib.shutdown()

    def test_spectral_measurement(self):
        """Test measurement in spectral mode"""
        self.chiplib.configuration.measure_type = MeasureType.SPECTRAL
        self.chiplib.configuration.meas_count = 10
        self.chiplib.start_measurement()
        data = list(self.chiplib.get_measurement_data(timeout=2.0))
        assert 10 == len(data)
        for tmp in data:
            assert 12 == len(tmp[0]), "Spectral data have the wrong size"
            assert {} == tmp[1], "Additional measurement data are not empty"

        # test with only 6 channels
        self.chiplib.configuration.channels = [
            SpectralChannel.F1,
            SpectralChannel.F2,
            SpectralChannel.F3,
            SpectralChannel.F4,
            SpectralChannel.F5,
            SpectralChannel.F6,
            SpectralChannel.DISABLED,
            SpectralChannel.DISABLED,
            SpectralChannel.DISABLED,
            SpectralChannel.DISABLED,
            SpectralChannel.DISABLED,
            SpectralChannel.DISABLED,
        ]
        self.chiplib.start_measurement()
        data = list(self.chiplib.get_measurement_data(timeout=2.0))
        assert 10 == len(data)
        for tmp in data:
            assert 6 == len(tmp[0]), "Spectral data have the wrong size"
            assert {} == tmp[1], "Additional measurement data are not empty"

    def test_spectral_measurement_add_data(self):
        """
        Test the additional data in spectral measurement mode.
        Each possible item must be tested.
        The min and max count of additional data must be tested.

        Precondition:
            Chip Library is initialized.
            Spectral measurement mode is configured.
            Additional measurement data are configured.

        Steps:
            1. Start the measurement
            2. Check the additional data

        Expectation:
            The additional will be correct interpreted.
        """
        test_pattern = [
            [
                ItemIds.ASTEP,
                ItemIds.ATIME,
                ItemIds.ITIME,
                ItemIds.AGAIN,
                ItemIds.MEAS_TYPE,
                ItemIds.BREAK,
                ItemIds.CHANNELS,
                ItemIds.VERSION,
                ItemIds.SERIAL,
                ItemIds.AUTOZERO,
            ],
            [
                ItemIds.MEAS_COUNT,
                ItemIds.LED_PATTERN,
                ItemIds.LED_WAIT_TIME,
                ItemIds.INTERRUPT_PIN,
                ItemIds.LED_INTERN,
                ItemIds.LED_EXT_1,
                ItemIds.LED_EXT_2,
                ItemIds.LED_EXT_3,
                ItemIds.LED_EXT_4,
                ItemIds.OUTPUT,
            ],
            [
                ItemIds.TEMP_EXT_1,
                ItemIds.TEMP_EXT_2,
                ItemIds.TEMP_EXT_3,
                ItemIds.TEMP_EXT_4,
                ItemIds.MEASURE_ITEMS,
                ItemIds.FGAIN,
                ItemIds.FTIME,
                ItemIds.FTIME_US,
                ItemIds.FCHANNELS,
            ],
        ]
        self.chiplib.configuration.measure_type = MeasureType.SPECTRAL
        self.chiplib.configuration.meas_count = 2

        for pattern in test_pattern:
            self.chiplib.configuration.measure_items = pattern

            self.chiplib.start_measurement()

            data = list(self.chiplib.get_measurement_data(timeout=2.0))
            assert 2 == len(data)

            # check additional measurement data
            for _, add_data in data:
                for item_id in pattern:
                    if not item_id == ItemIds.RESERVED:
                        assert item_id in add_data
                        if item_id not in [ItemIds.TEMP_EXT_1,
                                           ItemIds.TEMP_EXT_2,
                                           ItemIds.TEMP_EXT_3,
                                           ItemIds.TEMP_EXT_4,
                                           ]:
                            assert add_data[item_id] == self.chiplib.get_item(item_id), "Item {0} doesn't match.".format(item_id)

    def test_fifo_measurement(self):
        """Test measurement in spectral mode"""
        self.chiplib.configuration.measure_type = MeasureType.FIFO
        self.chiplib.configuration.meas_count = 500
        self.chiplib.start_measurement()
        data = []
        for tmp_data, add_data in self.chiplib.get_measurement_data(timeout=2.0):
            data += tmp_data
            assert {} == add_data, "Additional measurement data are not empty"
        assert 500 == len(data)

    def test_fifo_measurement_add_data(self):
        """
        Test the additional data in FIFO measurement mode.
        Each possible item must be tested.
        The min and max count of additional data must be tested.

        Precondition:
            Chip Library is initialized.
            FIFO measurement mode is configured.
            Additional measurement data are configured.

        Steps:
            1. Start the measurement
            2. Check the additional data

        Expectation:
            The additional will be correct interpreted.
        """
        test_pattern = [
            [
                ItemIds.ASTEP,
                ItemIds.ATIME,
                ItemIds.ITIME,
                ItemIds.AGAIN,
                ItemIds.MEAS_TYPE,
                ItemIds.BREAK,
                ItemIds.CHANNELS,
                ItemIds.VERSION,
                ItemIds.SERIAL,
                ItemIds.AUTOZERO,
            ],
            [
                ItemIds.MEAS_COUNT,
                ItemIds.LED_PATTERN,
                ItemIds.LED_WAIT_TIME,
                ItemIds.INTERRUPT_PIN,
                ItemIds.LED_INTERN,
                ItemIds.LED_EXT_1,
                ItemIds.LED_EXT_2,
                ItemIds.LED_EXT_3,
                ItemIds.LED_EXT_4,
                ItemIds.OUTPUT,
            ],
            [
                ItemIds.TEMP_EXT_1,
                ItemIds.TEMP_EXT_2,
                ItemIds.TEMP_EXT_3,
                ItemIds.TEMP_EXT_4,
                ItemIds.MEASURE_ITEMS,
                ItemIds.FGAIN,
                ItemIds.FTIME,
                ItemIds.FTIME_US,
                ItemIds.FCHANNELS,
            ],
        ]
        self.chiplib.configuration.measure_type = MeasureType.FIFO
        self.chiplib.configuration.meas_count = 10
        for pattern in test_pattern:
            self.chiplib.configuration.measure_items = pattern

            self.chiplib.start_measurement()
            data = list(self.chiplib.get_measurement_data(timeout=2.0))
            assert len(data) > 0
            for _, add_data in data:
                for item_id in pattern:
                    if not item_id == ItemIds.RESERVED:
                        assert item_id in add_data
                        if item_id not in [ItemIds.TEMP_EXT_1,
                                           ItemIds.TEMP_EXT_2,
                                           ItemIds.TEMP_EXT_3,
                                           ItemIds.TEMP_EXT_4,
                                           ]:
                            assert add_data[item_id] == self.chiplib.get_item(item_id), "Item {0} doesn't match.".format(item_id)

    def test_abort_measurement(self):
        """Test the abort_measurement function"""
        # configure measurement
        self.chiplib.configuration.measure_type = MeasureType.SPECTRAL
        self.chiplib.configuration.meas_count = 100

        # start measurement
        self.chiplib.start_measurement()

        # abort measurement
        meas_cnt = 0
        for _tmp_data in self.chiplib.get_measurement_data(timeout=2.0):
            meas_cnt += 1
            if meas_cnt == 20:
                self.chiplib.abort_measurement()

        # restart measurement
        self.chiplib.start_measurement()
        data = list(self.chiplib.get_measurement_data(timeout=2.0))
        assert 100 == len(data)


class TestLedPattern:
    """Test the LedPattern class
    """
    def test_set_pattern(self):
        """
        Test the setter of the pattern property and the
        getter of the config property.
        """
        dut = LedPattern()
        for mask in LedMasks:
            dut.pattern = [mask]
            assert mask.value == dut.config

        dut.pattern = list(LedMasks)
        assert 0xFF == dut.config

    def test_get_pattern(self):
        """
        Test the getter of the pattern property and the
        setter of the config property.
        """
        dut = LedPattern()
        for mask in LedMasks:
            dut.config = mask.value
            assert [mask] == dut.pattern

        dut.config = 0xFF
        assert list(LedMasks)[1:] == dut.pattern
