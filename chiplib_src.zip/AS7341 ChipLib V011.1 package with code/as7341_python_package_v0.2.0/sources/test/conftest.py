# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""Test configuration for chip library tests.
"""

import pytest

def pytest_addoption(parser):
    """register argparse-style options and ini-style config values, called once at the beginning of a test run.
    """
    parser.addoption(
        "--REMOTE", action="store", default=None, help="Connection string"
    )
    parser.addoption(
        "--SENSOR", action="store", default="a0011a", help="Id of the connected sensor board"
    )


@pytest.fixture
def remote(request):
    """
    Get the remote string from command line arguments.

    Args:
        request (pytest.fixture): The request fixture is a special fixture providing
            information of the requesting test function.

    Returns:
        str: Remote string
    """
    return request.config.getoption("--REMOTE")

@pytest.fixture
def sensor(request):
    """
    Get the id of the connected sensor from command line arguments.

    Args:
        request (pytest.fixture): The request fixture is a special fixture providing
            information of the requesting test function.

    Returns:
        str: sensor id
    """
    return request.config.getoption("--SENSOR")
