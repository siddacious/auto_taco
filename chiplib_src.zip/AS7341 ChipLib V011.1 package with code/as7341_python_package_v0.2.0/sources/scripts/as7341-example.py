# Example for executing measurements with the ams AS741 Evaluation Board.
#
# Requirements:
#
#     * AS7341 evaluation board connected via FTDI USB cable
#     * Installed Python distribution
#     * Installed as7341 Python package


from as7341 import (
    ChipLib,
    MeasureType,
    ItemIds,
)

##############################################################################
# Initialization
##############################################################################

# Object for configuration and measurement (the chip library's Python wrapper)
chiplib = ChipLib()

# Initialize the chip library and opens the connection to the evaluation board.
# The first FTDI cable which is found is used. If you want to connect to a
# specific FTDI cable, you can use a connection string with the serial number
# of the cable. e.g. chiplib.initialize(remote="FTDI:FT311D2E")
chiplib.initialize()

try:
    # Retrieve the version of the chip library.
    version = chiplib.configuration.version
    print("Chip library version: {}.{}.{}".format(*version))


    ##############################################################################
    # Spectral Measurement
    ##############################################################################

    # configure the measurement
    chiplib.configuration.measure_type = MeasureType.SPECTRAL
    # set itime as additional measurement data
    chiplib.configuration.measure_items = [ItemIds.ITIME]
    chiplib.configuration.meas_count = 10

    # start measurement
    chiplib.start_measurement()

    # get measurement data
    for spectral_data, add_data in chiplib.get_measurement_data():
        print("Spectral data: {0}".format(spectral_data))
        print("Additional data: {0}".format(add_data))

    ##############################################################################
    # FIFO Measurement
    ##############################################################################

    # configure the measurement
    chiplib.configuration.measure_type = MeasureType.FIFO
    # set itime as additional measurement data
    chiplib.configuration.measure_items = [ItemIds.ITIME]
    chiplib.configuration.meas_count = 500

    # start measurement
    chiplib.start_measurement()

    # get measurement data
    for raw_data, add_data in chiplib.get_measurement_data():
        print("Fifo data: {0}".format(raw_data))
        print("Additional data: {0}".format(add_data))

##############################################################################
# Deinitialization
##############################################################################
finally:
    # Deinitialize the chip library
    chiplib.shutdown()
