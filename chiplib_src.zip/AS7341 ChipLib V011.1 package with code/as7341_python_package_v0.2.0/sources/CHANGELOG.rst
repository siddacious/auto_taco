##################################
AS741 Python Package - Change Log
##################################

*************
Version 0.2.0
*************

* added support for Python 3.5
* added Linux support for I2C driver on Raspberry Pi
* added autogain feature
* added RPC support for UniCom board
* updated AS7341 Chip library to v0.10.1
* updated AS7341 RPC client library to v0.10.0

*************
Version 0.1.0
*************
Initial version.
