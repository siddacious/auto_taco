import os
from setuptools import setup

from as7341 import __version__ as pkg_version


setup(name="as7341",
      version=pkg_version,
      description="Python wrapper of the C libraries of the sensor AS7341.",
      long_description=open(os.path.join(os.path.dirname(__file__), "README.rst")).read(),
      author="ams AG",
      # author_email="info@ams.com",
      url="https://ams.com",
      # license="unknown",
      keywords=(
          "spectral sensing",
          "spectral analysis",
      ),
      packages=["as7341", "as7341.chiplib"],
      # package_dir={"": ""},
      package_data={"as7341.chiplib": ["libs/*/*/*.so", "libs/*/*/*.dll"]},
      # data_files=[("", ["LICENSE.txt"])],
      #install_requires=[],
      python_requires=">=3.5",
      classifiers=[
          "Development Status :: 4 - Beta",
          # "Environment :: Win32 (MS Windows)",
          "Programming Language :: Python :: 3.5",
          "License :: Other/Proprietary License",
          # "Operating System :: Microsoft :: Windows :: Windows 10",
          "Topic :: Software Development :: Libraries :: Python Modules",
          "Intended Audience :: Science/Research",
          "Intended Audience :: Developers",
      ],
      )
