# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""
Configuration items for the AS7341 chip library.
"""

from enum import Enum
from ctypes import (
    c_int32,
    c_uint8,
    c_uint16,
    c_uint32,
    c_uint64
)


__all__ = [
    "ItemIds",
    "Gain",
    "MeasureType",
    "SpectralChannel",
    "LedMasks",
    "FifoChannels",
    "LedPattern",
    "LedConfig",
]


def ctypes2int(c_value):
    """
    Convert a simple ctypes type to int.

    Args:
        c_value (_SimpleCData): value to be converted

    Returns:
        int: converted value
    """
    return c_value.value


def int2ctypes(value, c_type):
    """
    Convert a int to a ctypes type.

    Args:
        value (int): value to be converted

        c_type (_SimpleCData): type which used for conversion

    Returns:
        converted value
    """
    return c_type(value)


def list2ctypes(values, c_type):
    """
    Convert a list to a ctypes type.

    Args:
        values (list of int): values to be converted

        c_type (ctypes type): type which used for conversion

    Returns:
        converted value
    """
    return c_type(*values)


def ctypes2list(c_value):
    """
    Convert a ctypes array to list of int.

    Args:
        c_value (ctypes array): value to be converted

    Returns:
        list of int: converted value
    """
    return [e for e in c_value]


def enum2ctypes(value, c_type):
    """
    Convert a enum to a ctypes type.

    Args:
        values (Enum): values to be converted

        c_type (ctypes type): type which used for conversion

    Returns:
        converted value
    """
    return c_type(value.value)


def enum_list2ctypes(values, c_type):
    """
    Convert a list of enums to a ctypes type.

    Args:
        values (list of Enum): values to be converted

        c_type (ctypes type): type which used for conversion

    Returns:
        converted values
    """
    return list2ctypes([e.value for e in values], c_type)


def ctypes2config_gain(c_value):
    """
    Convert a ctype value to Gain enum.

    Args:
        c_value (_SimpleCData): value to be converted

    Returns:
        Gain: converted value
    """
    return Gain(c_value.value)

def ctypes2gain_list(c_values):
    """
    Converts a list of simple ctype values to a list
    of Gain enums.

    Args:
        c_values (list of _SimpleCData): values to be coverted

    Returns:
        list of Gain enums
    """
    return [Gain(e) for e in c_values]


def ctypes2config_measure_type(raw_data):
    return MeasureType(raw_data.value)


def channel_config2ctypes(raw_data):
    return [SpectralChannel(e) for e in raw_data]


def led_pattern2ctypes(value, c_type):
    data = []
    for pattern in value:
        data.append(pattern.count)
        data.append(pattern.config)
    return list2ctypes(data, c_type)


def ctypes2led_pattern(raw_data):
    pattern = []
    for i in range(0, len(raw_data), 2):
        pattern.append(LedPattern(count=raw_data[i], config=raw_data[i+1]))
    return pattern


def led_config2ctypes(value, c_type):
    return list2ctypes([value.enable, value.brightness], c_type)


def ctypes2led_config(raw_data):
    return LedConfig(enable=raw_data[0], brightness=raw_data[1])


def measure_items2ctypes(value, c_type):
    return list2ctypes([e.value for e in value], c_type)


def ctypes2measure_items(raw_data):
    return [ItemIds(e) for e in raw_data]


def fifo_channels2ctypes(value, c_type):
    data = 0
    for mask in value:
        data |= mask.value
    return int2ctypes(data, c_type)


def ctypes2fifo_channels(raw_data):
    channels = []
    for mask in FifoChannels:
        if (raw_data.value & mask.value) > 0:
            channels.append(mask)
    return channels


class ItemIds(Enum):
    """Ids for the configuration items
    """
    RESERVED = 0
    ASTEP = 1
    ATIME = 2
    ITIME = 3
    AGAIN = 4
    MEAS_TYPE = 5
    BREAK = 6
    CHANNELS = 7
    VERSION = 8
    SERIAL = 9
    AUTOZERO = 10
    MEAS_COUNT = 11
    LED_PATTERN = 12
    LED_WAIT_TIME = 13
    INTERRUPT_PIN = 14
    LED_INTERN = 15
    LED_EXT_0 = 16
    LED_EXT_1 = 17
    LED_EXT_2 = 18
    LED_EXT_3 = 19
    LED_EXT_4 = 20
    LED_EXT_5 = 21
    OUTPUT = 22
    TEMP_EXT_0 = 23
    TEMP_EXT_1 = 24
    TEMP_EXT_2 = 25
    TEMP_EXT_3 = 26
    TEMP_EXT_4 = 27
    TEMP_EXT_5 = 28
    MEASURE_ITEMS = 29
    FGAIN = 30
    FTIME = 31
    FTIME_US = 32
    FCHANNELS = 33
    TIMESTAMP = 34
    AUTO_GAIN = 35
    GAIN_FACTOR = 36


class Gain(Enum):
    """supported gains for items AGAIN and FGAIN to set the spectral sensitivity"""
    GAIN_0_5X = 0  # gain of 0.5x
    GAIN_1X = 1    # gain of 1x
    GAIN_2X = 2    # gain of 2x
    GAIN_4X = 3    # gain of 4x
    GAIN_8X = 4    # gain of 8x
    GAIN_16X = 5   # gain of 16x
    GAIN_32X = 6   # gain of 32x
    GAIN_64X = 7   # gain of 64x
    GAIN_128X = 8  # gain of 128
    GAIN_256X = 9  # gain of 256x
    GAIN_512X = 10 # gain of 512x


class MeasureType(Enum):
    """List of supported measurement types for item MEAS_TYPE
    """
    # spectral measurement: measures six chanels in parallel, otherwise you can
    # measure 12 channels in two blocks a 6 chanels (twice integration time!)
    SPECTRAL = 0

    # FIFO measurement: measures with one ADC only in fast FIFO mode: It is possible to
    # map more than one channel to this ADC
    FIFO = 1


class SpectralChannel(Enum):
    """supported channel types for spectral measurement
    """
    DISABLED = 0  # place holder for unused channels
    F1 = 1        # channel F1
    F2 = 2        # channel F2
    F3 = 3        # channel F3
    F4 = 4        # channel F4
    F5 = 5        # channel F5
    F6 = 6        # channel F6
    F7 = 7        # channel F7
    F8 = 8        # channel F8
    NIR = 9       # channel NIR
    CLEAR = 10    # channel CLEAR
    FLICKER = 11  # channel FLICKER


class LedMasks(Enum):
    """This bit masks will be used for configuration of the LED pattern"""
    OFF = 0x00     # mask that no LED will be set
    INTERN = 0x01  # mask that the internal LED will be set
    EXT_0 = 0x02   # mask that the external LED 0 will be set
    EXT_1 = 0x04   # mask that the external LED 1 will be set
    EXT_2 = 0x08   # mask that the external LED 2 will be set
    EXT_3 = 0x10   # mask that the external LED 3 will be set
    EXT_4 = 0x20   # mask that the external LED 4 will be set
    EXT_5 = 0x40   # mask that the external LED 5 will be set
    OUTPUT = 0x80  # mask that the output pin will be set


class FifoChannels(Enum):
    """Masks to configure the channels used for FIFO measurement mode"""
    F1_1 = (1 << 0) # Filter F1 Pixel 1
    F1_2 = (1 << 1) # Filter F1 Pixel 2
    F2_1 = (1 << 2) # Filter F2 Pixel 1
    F2_2 = (1 << 3) # Filter F2 Pixel 2
    F3_1 = (1 << 4) # Filter F3 Pixel 1
    F3_2 = (1 << 5) # Filter F3 Pixel 2
    F4_1 = (1 << 6) # Filter F4 Pixel 1
    F4_2 = (1 << 7) # Filter F4 Pixel 2
    F5_1 = (1 << 8) # Filter F5 Pixel 1
    F5_2 = (1 << 9) # Filter F5 Pixel 2
    F6_1 = (1 << 10) # Filter F6 Pixel 1
    F6_2 = (1 << 11) # Filter F6 Pixel 2
    F7_1 = (1 << 12) # Filter F7 Pixel 1
    F7_2 = (1 << 13) # Filter F7 Pixel 2
    F8_1 = (1 << 14) # Filter F8 Pixel 1
    F8_2 = (1 << 15) # Filter F8 Pixel 2
    CLEAR_1 = (1 << 16) # CLEAR Diode Pixel 1
    CLEAR_2 = (1 << 17) # CLEAR Diode Pixel 2
    NIR = (1 << 18) # NIR Diode
    FLICKER = (1 << 19) # FLICKER Diode

CONFIG_ITEMS = {
    ItemIds.ASTEP: {"type": c_uint16, "size": 2, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.ATIME: {"type": c_uint8, "size": 1, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.ITIME: {"type": c_uint32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.AGAIN: {"type": c_uint8, "size": 1, "c2py": ctypes2config_gain, "py2c": enum2ctypes},
    ItemIds.MEAS_TYPE: {"type": c_uint8, "size": 1, "c2py": ctypes2config_measure_type, "py2c": enum2ctypes},
    ItemIds.BREAK: {"type": c_uint32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.CHANNELS: {"type": c_uint8*12, "size": 12, "c2py": channel_config2ctypes, "py2c": enum_list2ctypes},
    ItemIds.VERSION: {"type": c_uint8*4, "size": 4, "c2py": ctypes2list, "py2c": list2ctypes},
    ItemIds.SERIAL: {"type": c_uint32*2, "size": 8, "c2py": ctypes2list, "py2c": list2ctypes},
    ItemIds.AUTOZERO: {"type": c_uint8, "size": 1, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.MEAS_COUNT: {"type": c_uint16, "size": 2, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.LED_PATTERN: {"type": c_uint8*20, "size": 20, "c2py": ctypes2led_pattern, "py2c": led_pattern2ctypes},
    ItemIds.LED_WAIT_TIME: {"type": c_uint32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.INTERRUPT_PIN: {"type": c_uint8, "size": 1, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.LED_INTERN: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_0: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_1: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_2: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_3: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_4: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.LED_EXT_5: {"type": c_uint16*2, "size": 4, "c2py": ctypes2led_config, "py2c": led_config2ctypes},
    ItemIds.OUTPUT: {"type": c_uint8, "size": 1, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_0: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_1: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_2: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_3: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_4: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.TEMP_EXT_5: {"type": c_int32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.MEASURE_ITEMS: {"type": c_uint8*10, "size": 10, "c2py": ctypes2measure_items, "py2c": measure_items2ctypes},
    ItemIds.FGAIN: {"type": c_uint8, "size": 1, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.FTIME: {"type": c_uint16, "size": 2, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.FTIME_US: {"type": c_uint32, "size": 4, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.FCHANNELS: {"type": c_uint32, "size": 4, "c2py": ctypes2fifo_channels, "py2c": fifo_channels2ctypes},
    ItemIds.TIMESTAMP: {"type": c_uint64, "size": 8, "c2py": ctypes2int, "py2c": int2ctypes},
    ItemIds.AUTO_GAIN: {"type": c_uint8*2, "size": 2, "c2py": ctypes2gain_list, "py2c": enum_list2ctypes},
    ItemIds.GAIN_FACTOR: {"type": c_uint16*11, "size": 22, "c2py": ctypes2list, "py2c": list2ctypes},
}


class LedPattern:
    """
    Definition for LED pattern.
    This is used to switch the LEDs synchronized to the spectral measurement

    Args:
        count (int): defines how often the current LED configuration will be used

        pattern (list of LedMasks): select the LEDs for the next measurement cycles

        config (int): config value for the chip library. It's a disjunction of the pattern values.

    """
    def __init__(self, count=0, pattern=None, config=None):
        self._count = count
        if pattern is None:
            self._pattern = [LedMasks.OFF]
        else:
            self._pattern = pattern

        if config is not None:
            self.config = config

    def __eq__(self, value):
        return (self.count == value.count) and (self.config == value.config)

    @property
    def count(self):
        """
        int: defines how often the current LED configuration will be used
        """
        return self._count

    @count.setter
    def count(self, value):
        self._count = value

    @property
    def pattern(self):
        """
        list of LedMasks: select the LEDs for the next measurement cycles
        """
        return self._pattern

    @pattern.setter
    def pattern(self, value):
        self._pattern = value

    @property
    def config(self):
        """
        int: config value for the chip library. It's a disjunction of the pattern values.
        """
        value = 0
        for mask in self._pattern:
            value |= mask.value
        return value

    @config.setter
    def config(self, value):
        self._pattern = []
        if value == 0:
            self._pattern.append(LedMasks.OFF)
        else:
            for mask in LedMasks:
                if (value & mask.value) > 0:
                    self._pattern.append(mask)


class LedConfig:
    """
    Configuration of the LEDs.

    Attributes:
        enable (int): Unequal zero means that LED shall be enabled, otherwise disabled.

        brightness (int): Brightness value in per mil (0 - 1000)
    """
    def __init__(self, enable=0, brightness=0):
        self.enable = enable
        self.brightness = brightness

    def __eq__(self, value):
        return (self.enable == value.enable) and (self.brightness == value.brightness)


class ChipLibConfiguration:
    """
    Configuration class for the chip library.

    Args:
        chiplib (ChipLib): Chip C library instance used to set and get configuration items.
    """
    def __init__(self, chiplib):
        self._chiplib = chiplib

    @property
    def astep(self):
        """
        int: Value of the ASTEP register
        """
        return self._chiplib.get_item(ItemIds.ASTEP)

    @astep.setter
    def astep(self, value):
        self._chiplib.set_item(ItemIds.ASTEP, value)

    @property
    def atime(self):
        """
        int: Value of the ATIME register
        """
        return self._chiplib.get_item(ItemIds.ATIME)

    @atime.setter
    def atime(self, value):
        self._chiplib.set_item(ItemIds.ATIME, value)

    @property
    def itime(self):
        """
        int: Value of the integration time in microseconds.
        """
        return self._chiplib.get_item(ItemIds.ITIME)

    @itime.setter
    def itime(self, value):
        self._chiplib.set_item(ItemIds.ITIME, value)

    @property
    def again(self):
        """
        ConfigGain: Gain setting of the CFG_1 register
        """
        return self._chiplib.get_item(ItemIds.AGAIN)

    @again.setter
    def again(self, value):
        self._chiplib.set_item(ItemIds.AGAIN, value)

    @property
    def measure_type(self):
        """
        ConfigMeasureType: Measurement type
        """
        return self._chiplib.get_item(ItemIds.MEAS_TYPE)

    @measure_type.setter
    def measure_type(self, value):
        self._chiplib.set_item(ItemIds.MEAS_TYPE, value)

    @property
    def break_time(self):
        """
        int: Break time betwen measurements
        """
        return self._chiplib.get_item(ItemIds.BREAK)

    @break_time.setter
    def break_time(self, value):
        self._chiplib.set_item(ItemIds.BREAK, value)

    @property
    def channels(self):
        """
        list of SpectralChannels: channel configuration for the spectral measurement
        """
        return self._chiplib.get_item(ItemIds.CHANNELS)

    @channels.setter
    def channels(self, value):
        self._chiplib.set_item(ItemIds.CHANNELS, value)

    @property
    def version(self):
        """
        list of int: Chip library version [major, minor, patch, build]
        """
        return self._chiplib.get_item(ItemIds.VERSION)

    @property
    def serial(self):
        """
        list of int: Unique chip identifier [timestamp, id]
        """
        return self._chiplib.get_item(ItemIds.SERIAL)

    @property
    def autozero(self):
        """
        int: Autozero setting of the AZ_CONFIG register
        """
        return self._chiplib.get_item(ItemIds.AUTOZERO)

    @autozero.setter
    def autozero(self, value):
        self._chiplib.set_item(ItemIds.AUTOZERO, value)

    @property
    def meas_count(self):
        """
        int: Number of measurements, 0 means continuous measurement
        """
        return self._chiplib.get_item(ItemIds.MEAS_COUNT)

    @meas_count.setter
    def meas_count(self, value):
        self._chiplib.set_item(ItemIds.MEAS_COUNT, value)

    @property
    def led_pattern(self):
        """
        list of LedPattern: led pattern sequence used for the measurement
        """
        return self._chiplib.get_item(ItemIds.LED_PATTERN)

    @led_pattern.setter
    def led_pattern(self, value):
        self._chiplib.set_item(ItemIds.LED_PATTERN, value)

    @property
    def led_wait_time(self):
        """
        int: warm up time in microseconds for synchronized LED switching
        """
        return self._chiplib.get_item(ItemIds.LED_WAIT_TIME)

    @led_wait_time.setter
    def led_wait_time(self, value):
        self._chiplib.set_item(ItemIds.LED_WAIT_TIME, value)

    @property
    def interrupt_pin(self):
        """
        int: Unequal zero means that the interrupt pin will be used, zero means that the wait
            time will be calculated internally by the ChipLib. The base of the wait time is
            the configured integration time plus a measurement-mode-specific offset.

        """
        return self._chiplib.get_item(ItemIds.INTERRUPT_PIN)

    @interrupt_pin.setter
    def interrupt_pin(self, value):
        self._chiplib.set_item(ItemIds.INTERRUPT_PIN, value)

    @property
    def led_intern(self):
        """
        LedConfig: configuration of the internal led
        """
        return self._chiplib.get_item(ItemIds.LED_INTERN)

    @led_intern.setter
    def led_intern(self, value):
        self._chiplib.set_item(ItemIds.LED_INTERN, value)

    @property
    def led_ext_0(self):
        """
        LedConfig: configuration of the external led 0
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_0)

    @led_ext_0.setter
    def led_ext_0(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_0, value)

    @property
    def led_ext_1(self):
        """
        LedConfig: configuration of the external led 1
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_1)

    @led_ext_1.setter
    def led_ext_1(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_1, value)

    @property
    def led_ext_2(self):
        """
        LedConfig: configuration of the external led 2
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_2)

    @led_ext_2.setter
    def led_ext_2(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_2, value)

    @property
    def led_ext_3(self):
        """
        LedConfig: configuration of the external led 3
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_3)

    @led_ext_3.setter
    def led_ext_3(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_3, value)

    @property
    def led_ext_4(self):
        """
        LedConfig: configuration of the external led 4
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_4)

    @led_ext_4.setter
    def led_ext_4(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_4, value)

    @property
    def led_ext_5(self):
        """
        LedConfig: configuration of the external led 5
        """
        return self._chiplib.get_item(ItemIds.LED_EXT_5)

    @led_ext_5.setter
    def led_ext_5(self, value):
        self._chiplib.set_item(ItemIds.LED_EXT_5, value)

    @property
    def output(self):
        """
        int: The output is configured as an open collector. On default the
            output is HI-Z and is disconnected. Unequal zero means that the
            output pin drives low.

        """
        return self._chiplib.get_item(ItemIds.OUTPUT)

    @output.setter
    def output(self, value):
        self._chiplib.set_item(ItemIds.OUTPUT, value)

    @property
    def temp_ext_0(self):
        """
        int: temperature of the external temperature sensor 0 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_0)

    @property
    def temp_ext_1(self):
        """
        int: temperature of the external temperature sensor 1 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_1)

    @property
    def temp_ext_2(self):
        """
        int: temperature of the external temperature sensor 2 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_2)

    @property
    def temp_ext_3(self):
        """
        int: temperature of the external temperature sensor 3 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_3)

    @property
    def temp_ext_4(self):
        """
        int: temperature of the external temperature sensor 4 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_4)

    @property
    def temp_ext_5(self):
        """
        int: temperature of the external temperature sensor 5 in millidegree
        """
        return self._chiplib.get_item(ItemIds.TEMP_EXT_5)

    @property
    def measure_items(self):
        """
        list of ConfigItemIds: additional measure data
        """
        return self._chiplib.get_item(ItemIds.MEASURE_ITEMS)

    @measure_items.setter
    def measure_items(self, value):
        self._chiplib.set_item(ItemIds.MEASURE_ITEMS, value)

    @property
    def fgain(self):
        """
        ConfigGain: Gain setting for the fast fifo measure mode
        """
        return Gain(self._chiplib.get_item(ItemIds.FGAIN))

    @fgain.setter
    def fgain(self, value):
        self._chiplib.set_item(ItemIds.FGAIN, value.value)

    @property
    def ftime(self):
        """
        int: Value of the FD_TIME register
        """
        return self._chiplib.get_item(ItemIds.FTIME)

    @ftime.setter
    def ftime(self, value):
        self._chiplib.set_item(ItemIds.FTIME, value)

    @property
    def ftime_us(self):
        """
        int: Value of the integration time in microseconds.
        """
        return self._chiplib.get_item(ItemIds.FTIME_US)

    @ftime_us.setter
    def ftime_us(self, value):
        self._chiplib.set_item(ItemIds.FTIME_US, value)

    @property
    def fchannels(self):
        """
        list of FIFO channels: channels used for FIFO measurement mode
        """
        return self._chiplib.get_item(ItemIds.FCHANNELS)

    @fchannels.setter
    def fchannels(self, value):
        self._chiplib.set_item(ItemIds.FCHANNELS, value)

    @property
    def timestamp(self):
        """
        int: Reads a microseconds timestamp. It can be used to get accurate
            time difference between to measurements. The timestamp is reset
            during initialization and on start measurement.

        """
        return self._chiplib.get_item(ItemIds.TIMESTAMP)

    @property
    def auto_gain_range(self):
        """
        list of `Gain`: Set the lower und upper limit for auto gain control [<lower limit>, <upper limit>].
            Auto gain is enabled if the lower limit is lower than the upper.
        """
        return self._chiplib.get_item(ItemIds.AUTO_GAIN)

    @auto_gain_range.setter
    def auto_gain_range(self, value):
        self._chiplib.set_item(ItemIds.AUTO_GAIN, value)

    @property
    def gain_factors(self):
        """
        list of int: Gain correction values for each gain [GAIN_0_5X, ..., GAIN_512X]
        The given factors will be divided by 10000 internally to get the right factor with four decimal places.
        """
        return self._chiplib.get_item(ItemIds.GAIN_FACTOR)

    @gain_factors.setter
    def gain_factors(self, value):
        self._chiplib.set_item(ItemIds.GAIN_FACTOR, value)
