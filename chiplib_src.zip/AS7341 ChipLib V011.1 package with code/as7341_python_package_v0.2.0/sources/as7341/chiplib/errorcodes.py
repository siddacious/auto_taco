# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""
Error codes from the AS7341 chip library.
"""

from enum import Enum


class ChipLibErrorCodes(Enum):
    """Error codes for the AS7341 chip library.
    """
    ERR_SUCCESS = 0
    ERR_PERMISSION = 1
    ERR_MESSAGE = 2
    ERR_MESSAGE_SIZE = 3
    ERR_POINTER = 4
    ERR_ACCESS = 5
    ERR_ARGUMENT = 6
    ERR_SIZE = 7
    ERR_NOT_SUPPORTED = 8
    ERR_TIMEOUT = 9
    ERR_CHECKSUM = 10
    ERR_OVERFLOW = 11
    ERR_EVENT = 12
    ERR_INTERRUPT = 13
    ERR_TIMER_ACCESS = 14
    ERR_LED_ACCESS = 15
    ERR_TEMP_SENSOR_ACCESS = 16
    ERR_DATA_TRANSFER = 17
    ERR_FIFO = 18
    ERR_OVER_TEMP = 19
    ERR_IDENTIFICATION = 20
    ERR_COM_INTERFACE = 21
    ERR_SYNCHRONISATION = 22
    ERR_PROTOCOL = 23
    ERR_MEMORY = 24
    ERR_THREAD = 25
    ERR_DAC_ACCESS = 27
    ERR_I2C = 28
    ERR_NO_DATA = 29
    ERR_SYSTEM_CONFIG = 30
    ERR_USB_ACCESS = 31
    ERR_ADC_ACCESS = 32
    ERR_SENSOR_CONFIG = 33
    ERR_SATURATION = 34

ERROR_DESCRIPTIONS = {
    ChipLibErrorCodes.ERR_PERMISSION: "Operation not permitted",
    ChipLibErrorCodes.ERR_MESSAGE: "Message is invalid.",
    ChipLibErrorCodes.ERR_MESSAGE_SIZE: "Message has the wrong size.",
    ChipLibErrorCodes.ERR_POINTER: "Pointer is invalid. Can be a NULL Pointer or point to a wrong memory area.",
    ChipLibErrorCodes.ERR_ACCESS: "Permission denied",
    ChipLibErrorCodes.ERR_ARGUMENT: "Invalid argument",
    ChipLibErrorCodes.ERR_SIZE: "Argument size is too long or too short.",
    ChipLibErrorCodes.ERR_NOT_SUPPORTED: "Function is not supported/implemented.",
    ChipLibErrorCodes.ERR_TIMEOUT: "Got timeout while waiting for answer.",
    ChipLibErrorCodes.ERR_CHECKSUM: "Checksum comparision failed.",
    ChipLibErrorCodes.ERR_OVERFLOW: "Data overflow detected.",
    ChipLibErrorCodes.ERR_EVENT: "Error to get or set an event.",
    ChipLibErrorCodes.ERR_INTERRUPT: "Error to get or set an interrupt.",
    ChipLibErrorCodes.ERR_TIMER_ACCESS: "Error while accessing timer periphery.",
    ChipLibErrorCodes.ERR_LED_ACCESS: "Error while accessing LED periphery.",
    ChipLibErrorCodes.ERR_TEMP_SENSOR_ACCESS: "Error while accessing temperature sensor.",
    ChipLibErrorCodes.ERR_DATA_TRANSFER: "Communication error",
    ChipLibErrorCodes.ERR_FIFO: "Faulty FIFO handling",
    ChipLibErrorCodes.ERR_OVER_TEMP: "Overtemperature detected.",
    ChipLibErrorCodes.ERR_IDENTIFICATION: "Sensor identification failed.",
    ChipLibErrorCodes.ERR_COM_INTERFACE: "Generic communication interface error.",
    ChipLibErrorCodes.ERR_SYNCHRONISATION: "Synchronisation error, e.g. on protocol",
    ChipLibErrorCodes.ERR_PROTOCOL: "Generic protocol error",
    ChipLibErrorCodes.ERR_MEMORY: "Memory allocation error",
    ChipLibErrorCodes.ERR_THREAD: "Thread can not created.",
    ChipLibErrorCodes.ERR_DAC_ACCESS: "Error while accessing DAC periphery.",
    ChipLibErrorCodes.ERR_I2C: "Error while accessing I2C periphery.",
    ChipLibErrorCodes.ERR_NO_DATA: "No data available.",
    ChipLibErrorCodes.ERR_SYSTEM_CONFIG: "Error during system configuration",
    ChipLibErrorCodes.ERR_USB_ACCESS: "USB error",
    ChipLibErrorCodes.ERR_ADC_ACCESS: "Error while accessing ADC periphery.",
    ChipLibErrorCodes.ERR_SENSOR_CONFIG: "Error during sensor configuration.",
    ChipLibErrorCodes.ERR_SATURATION: "Saturation detected",
}
