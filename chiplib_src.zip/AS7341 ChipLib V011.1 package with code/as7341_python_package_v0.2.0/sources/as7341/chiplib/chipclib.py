# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""
Loads the AS7341 chip library and executes the C function calls.
"""

from ctypes import (
    c_char_p,
    c_int,
    c_uint8,
    c_uint32,
    c_void_p,
    cdll,
    CFUNCTYPE,
    POINTER,
)

from as7341.chiplib.errorcodes import (
    ChipLibErrorCodes,
    ERROR_DESCRIPTIONS
)


__all__ = [
]


# ----------------------------------------------------------------------------
# C library structure definitions
# ----------------------------------------------------------------------------



# ----------------------------------------------------------------------------
# C library function prototypes
# ----------------------------------------------------------------------------

AS7341_CALLBACK = CFUNCTYPE(
    None,
    c_uint8,  # device
    c_uint8,  # error
    POINTER(c_uint8),  # p_data
    c_uint32,  # data_size
    POINTER(c_uint8),  # p_items
    c_uint32,  # item_size
    c_void_p,  # p_cb_param
    )


CHIPLIB_FUNCTION_PROTOTYPES = [
    # (Python method name (str),
    #  C function name (str),
    #  function prototype (ctypes.CFUNCTYPE),
    #  parameter flags (tuple),
    #  error description (dict or None)
    #  )

    ("initialize",
     "as7341_initialize",
     CFUNCTYPE(c_int, c_uint8, AS7341_CALLBACK, c_void_p, c_char_p),
     ((1, "device"), (1, "p_callback"), (1, "p_cb_param"), (1, "p_remote")),
     ERROR_DESCRIPTIONS
     ),

    ("shutdown",
     "as7341_shutdown",
     CFUNCTYPE(c_int, c_uint8),
     ((1, "device"), ),
     ERROR_DESCRIPTIONS
     ),

    ("set_item",
     "as7341_set_item",
     CFUNCTYPE(c_int, c_uint8, c_int, c_void_p, c_uint8),
     ((1, "device"), (1, "id"), (1, "p_data"), (1, "size")),
     ERROR_DESCRIPTIONS
     ),

    ("get_item",
     "as7341_get_item",
     CFUNCTYPE(c_int, c_uint8, c_int, c_void_p, c_uint8),
     ((1, "device"), (1, "id"), (3, "p_data"), (1, "size")),
     ERROR_DESCRIPTIONS
     ),

    ("set_configuration",
     "as7341_set_configuration",
     CFUNCTYPE(c_int, c_uint8, POINTER(c_uint8), c_uint32),
     ((1, "device"), (1, "p_data"), (1, "size")),
     ERROR_DESCRIPTIONS
     ),

    ("get_configuration",
     "as7341_get_configuration",
     CFUNCTYPE(c_int, c_uint8, POINTER(c_uint8), c_uint32),
     ((1, "device"), (3, "p_data"), (3, "size")),
     ERROR_DESCRIPTIONS
     ),

    ("start_measurement",
     "as7341_start_measurement",
     CFUNCTYPE(c_int, c_uint8),
     ((1, "device"), ),
     ERROR_DESCRIPTIONS
     ),

    ("execute_state_machine",
     "as7341_execute_state_machine",
     CFUNCTYPE(c_int, c_uint8, POINTER(c_int)),
     ((1, "device"), (3, "p_state")),
     ERROR_DESCRIPTIONS
     ),

    ("abort_measurement",
     "as7341_abort_measurement",
     CFUNCTYPE(c_int, c_uint8),
     ((1, "device"), ),
     ERROR_DESCRIPTIONS
     ),
]


# ----------------------------------------------------------------------------
# Error handling
# ----------------------------------------------------------------------------

class ChipLibCError(Exception):
    """
    Chip Library C Interface exception class

    Args:
        error_code (int): error code

        error_description (str): error description

    Attributes:
        error_code (int): error code

        error_description (str): error description
    """

    def __init__(self, error_code, error_description=None):
        Exception.__init__(self)
        self.error_code = error_code
        self.error_description = error_description

    def __str__(self):
        # pylint: disable=len-as-condition
        # pylint is overdoing here: https://github.com/PyCQA/pylint/issues/2684
        if (self.error_description is not None) and (len(self.error_description) > 0):
            err_msg = "{self.error_code}: {self.error_description}".format(self=self)
        else:
            err_msg = "{self.error_code}".format(self=self)
        return err_msg

    def __repr__(self):
        return "ChipLibCError: {}".format(str(self))


# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------

# methods will be dynamically added at runtime
# pylint: disable=too-few-public-methods
class ChipCLibrary:
    """
    Interface to the chip C library
    """
    def __init__(self):
        pass

    @staticmethod
    def _get_error_check(error_description):
        """
        Returns a function to handle errors of the library function automatically.

        Args:
            error_description (dict): Dictionary, which keys are the specific error codes and
                the values are error the assigned error strings.

        Returns:
            func: Function to check the returned error code.
        """
        # noinspection PyUnusedLocal
        def check_error(result, func, arguments):
            """
            Executes the error checking of the library function.

            Implementation conforms to the guidelines of the attribute `errcheck` for C function pointers.
            Only the return value of the library function is evaluated. In the case of an error a
            :exc:`ChipLibError` exception will be raised..
            """
            del func, arguments     # unused
            error_code = ChipLibErrorCodes(result)
            if ChipLibErrorCodes.ERR_SUCCESS != error_code:
                if error_code in error_description:
                    error_string = error_description[error_code]
                else:
                    error_string = None
                raise ChipLibCError(result, error_description=error_string)
        return check_error

    def load_library(self, path, function_prototypes):
        """
        Loads the library and adds its functions as attributes to this object. The names of the
        attributes are resulting from the definition of the function prototypes
        (see :const:`CHIPLIB_FUNCTION_PROTOTYPES`).

        Args:
            path (str): path including the file name of the library to load.

            function_prototypes (list): Definition of the function prototypes. One list entry consist
                of the following elements:

                  - Name of the attribute to add to this object, which contains the call to the
                    specific library function (str)
                  - Function name as contained in the C library (str)
                  - Function prototype (ctypes.CFUNCTYPE)
                  - Parameter flags as specified in the 'Function prototypes' section of the
                    ctypes documentation (list)
                  - Error description (dict or None). An entry consists of the library function's
                    error code (key) and error description (value)

        """
        handle = cdll.LoadLibrary(path)
        for method_name, lib_func_name, func_prototype, param_flags, err_description in function_prototypes:
            func = func_prototype((lib_func_name, handle), param_flags)
            if err_description is not None:
                func.errcheck = self._get_error_check(err_description)
            setattr(self, method_name, func)
