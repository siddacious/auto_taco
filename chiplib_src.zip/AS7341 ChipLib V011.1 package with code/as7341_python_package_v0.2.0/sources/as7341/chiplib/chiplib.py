# -*- coding: utf-8 -*-
#############################################################################
# Copyright by ams AG                                                       #
# All rights are reserved.                                                  #
#                                                                           #
# IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     #
# THE SOFTWARE.                                                             #
#                                                                           #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          #
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     #
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     #
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      #
#############################################################################

"""
Python wrapper of the AS7341 Chip C Library.

"""

import os
import platform

from enum import Enum
from queue import (
    Queue,
    Empty,
)
from time import sleep
from threading import Thread
from ctypes import (
    byref,
    c_int,
    c_uint8,
)

from as7341.chiplib.chipclib import (
    ChipCLibrary,
    CHIPLIB_FUNCTION_PROTOTYPES,
    AS7341_CALLBACK,
    ChipLibErrorCodes,
    ChipLibCError,
    ERROR_DESCRIPTIONS,
)
from as7341.chiplib.config import (
    CONFIG_ITEMS,
    ChipLibConfiguration,
    MeasureType,
    ItemIds,
)


__all__ = [
    "ChipLibError",
    "ChipLib",
]


class ChipLibError(Exception):
    """
    Chip Library exception class

    Args:
        error_description (str): error description

    Attributes:
        error_description (str): error description
    """

    def __init__(self, error_description):
        Exception.__init__(self)
        self.error_description = error_description

    def __str__(self):
        return self.error_description

    def __repr__(self):
        return "ChipLibError: {0}".format(self)


class MeasureState(Enum):
    """state of the measurement engine"""
    CONFIG = 0  # no measurement is running
    MEASURE = 1  # measurement is active


class SpectralData:
    """
    Class to hold the spectral measurement data

    Args:
        raw_data (list of bytes): Raw measurement data received from chip library
    """
    def __init__(self, raw_data):
        self._raw_data = raw_data
        self._spectral_data = self.extract_spectral_data(raw_data)

    @staticmethod
    def extract_spectral_data(raw_data):
        """
        Extract the spectral channels from the raw data.

        Args:
            raw_data (list of bytes): Raw data from spectral measurement.

        Returns:
            list of int: raw measurement data converted to uint16
        """
        spec_data = []
        for i in range(0, len(raw_data), 2):
            # todo: use cast of uint16 to get spectral data
            spec_data.append(raw_data[i] + (raw_data[i+1]<<8))
        return spec_data

    @property
    def spectral_data(self):
        """Value of the 12 spectral channels"""
        return self._spectral_data


class ChipLib:
    """
    API of the AS7341 Chip Library.

    Attributes:
        configuration (ChipLibConfiguration): Provides all config and device items as attributes.
    """

    def __init__(self):
        self._chip_c_lib = ChipCLibrary()
        self._device = None
        self._callback_func = self._get_callback_func()
        self._callback_data = Queue()
        self._state_machine_thread = None
        self._active_meas_mode = None
        self._active_meas_items = []

        self.configuration = ChipLibConfiguration(self)

    def _is_thread_running(self):
        return self._state_machine_thread is not None and self._state_machine_thread.is_alive()

    def _load_library(self, osal_layer='ftdi'):
        """
        Loads the c libray dependend from osal layer, operation system and
        system architecture.

        Args:
            osal_layer (str, optional): OSAL layer which should be used.
                Supported layers are 'ftdi', 'i2c' and 'rpc'.
                Defaults to 'ftdi'.

        Raises:
            EnvironmentError: The given system is not supported.
        """
        system = platform.system().lower()
        arch = platform.machine().lower()
        if arch in ["amd64"]:
            arch = "x86_64"

        file_name_lib = None
        if osal_layer == "ftdi":
            if system == "windows":
                if arch == "x86_64":
                    file_name_lib = "as7341_chiplib_ftdi.dll"
            elif system == "linux":
                if arch in ["x86_64", "armv7l"]:
                    file_name_lib = "libas7341_chiplib_ftdi.so"

        elif osal_layer == 'i2c':
            if system == "linux":
                if arch in ["armv7l"]:
                    file_name_lib = "libas7341_chiplib_linux.so"

        if osal_layer == "rpc":
            if system == "windows":
                if arch == "x86_64":
                    file_name_lib = "as7341_chiplib_rpc.dll"
            elif system == "linux":
                if arch in ["x86_64", "armv7l"]:
                    file_name_lib = "as7341_chiplib_rpc.so"

        if file_name_lib is None:
            raise EnvironmentError("System {0} {1} not supported.".format(system, arch))

        lib_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "libs", arch, system, file_name_lib)
        self._chip_c_lib.load_library(lib_path, CHIPLIB_FUNCTION_PROTOTYPES)

    def _get_callback_func(self):
        """
        Get the callback function for the chip library

        Returns:
            AS7341_CALLBACK: callback function
        """
        # p_cb_data is not used but part of function interface
        def func(device, error, p_data, data_size, p_items, item_size, _p_cb_data):
            """
            Put the received data in the callback_data queue.
            (device, error, data, items)
            """
            self._callback_data.put((device, error, p_data[:data_size], p_items[:item_size]))

        return AS7341_CALLBACK(func)

    def _execute_state_machine(self, wait_time=0.01):
        """
        Executes the measurement state machine until the IDLE state is reached.

        Args:
            wait_time (float): Wait time in seconds between the execution calls
                of the state machine.
        """
        state = c_int(MeasureState.MEASURE.value)
        while MeasureState(state.value) == MeasureState.MEASURE:
            sleep(wait_time)
            # noinspection PyUnresolvedReferences
            # pylint: disable=no-member
            # If an exception is raised or the function doesn't returns, the
            # self.get_measurement_data function, which wait for the data,
            # timed out.
            self._chip_c_lib.execute_state_machine(self._device, byref(state))

        self._callback_data.put(None)  # measurement are finished

    def initialize(self, device=0, remote=None):
        """
        Initializes the library.

        This function has to be called once, before calling any other function of this library.

        Args:
            device (int): Id of the device. The default is 0. This parameter is only relevant if
                the chip library supports more than one device.

            remote (str): Connection string. The default is None. For that the first FTDI adapter
                which is found is used.
                The following remote strings are supported:

                    * FTDI:<serial> to connect to a FTDI adapter via his serial number.
                    * COM:<serial_port> to connect to a UniCom board

        Raises:
            `ChipLibCError`: Call to Chip Library function returned with an error.

        """
        self._device = device
        # noinspection PyUnresolvedReferences
        # pylint: disable=no-member
        if remote is not None:
            if remote.startswith("FTDI:"):
                osal = 'ftdi'
            elif remote.startswith("I2C:"):
                osal = 'i2c'
            elif remote.startswith("COM:") \
                or remote.startswith("UDP:"):
                osal = 'rpc'
            remote = remote.encode()
        else:
            osal = 'ftdi'

        self._load_library(osal)
        self._chip_c_lib.initialize(self._device, self._callback_func, None, remote)

    def shutdown(self):
        """
        Deinitialize the library.

        When work with this library has been finished (e.g. application termination) this function
        frees all resources allocated by the library.

        Raises:
            ChipLibError: Call to Chip Library function returned with an error.

        """
        try:
            if self._is_thread_running():
                self.abort_measurement()
                self._state_machine_thread.join(timeout=1.0)
                if self._state_machine_thread.is_alive():
                    raise ChipLibError("Measurement Thread is still running")
        finally:
            self._chip_c_lib.shutdown(self._device)  # pylint: disable=no-member

    def get_item(self, item_id):
        """
        Reads the actual settings of sensor or library items

        Args:
            item_id (`ConfigItemIds`): Id of the configuration item.

        Returns:
            Data of the configuration item.

        Raises:
            ChipLibCError: Call to Chip Library function returned with an error.
        """
        p_data = CONFIG_ITEMS[item_id]["type"]()
        size = CONFIG_ITEMS[item_id]["size"]
        # noinspection PyUnresolvedReferences
        # pylint: disable=no-member
        self._chip_c_lib.get_item(self._device, item_id.value, byref(p_data), size)

        return CONFIG_ITEMS[item_id]["c2py"](p_data)

    def set_item(self, item_id, value):
        """
        Set an configuration item

        Args:
            item_id (`ConfigItemIds`): Id of the configuration item.

            value : Value of the configuration item.

        Raises:
            ChipLibCError: Call to Chip Library function returned with an error.
        """
        data = CONFIG_ITEMS[item_id]["py2c"](value, CONFIG_ITEMS[item_id]["type"])
        size = CONFIG_ITEMS[item_id]["size"]
        # noinspection PyUnresolvedReferences
        # pylint: disable=no-member
        self._chip_c_lib.set_item(self._device, item_id.value, byref(data), size)

    def start_measurement(self, wait_time=0.01):
        """
        Starts the measurement.

        Args:
            wait_time (float): Cycle time of chip library state machine in seconds

        Raises:
            ChipLibError: Measurement Thread is still running
        """
        self._active_meas_mode = self.configuration.measure_type
        self._active_meas_items = self.configuration.measure_items

        if self._is_thread_running():
            raise ChipLibError("Measurement Thread is still running")

        # noinspection PyUnresolvedReferences
        # pylint: disable=no-member
        self._chip_c_lib.start_measurement(self._device)

        self._state_machine_thread = Thread(target=self._execute_state_machine, kwargs={'wait_time': wait_time})
        self._state_machine_thread.start()

    def abort_measurement(self):
        """
        Aborts the measurement.
        """
        # noinspection PyUnresolvedReferences
        # pylint: disable=no-member
        self._chip_c_lib.abort_measurement(self._device)

    def get_measurement_data(self, timeout=2.0):
        """
        Receives the measurement data from a running measurement process.
        Returns the measurement data until the measurement process stops or the
        timeout expires.

        Args:
            timeout (float): Receive timeout in seconds for measurement data.​

        Yields:
            list of int: spectral raw values

            dict: additional measurement data, key is the item id (ConfigItemIds)

        Raises:
            ChipLibError: No measurement data available

            ChipLibCError: Callback function returned an error

        """

        while True:
            try:
                raw_data = self._callback_data.get(block=True, timeout=timeout)
            except Empty:
                raise ChipLibError("Wait for measurement data timed out.")

            if raw_data is not None:
                if raw_data[0] != self._device:
                    raise ChipLibError("Received data from the wrong device ({0})".format(raw_data[0]))

                # check error code
                error = ChipLibErrorCodes(raw_data[1])
                if error != ChipLibErrorCodes.ERR_SUCCESS:
                    raise ChipLibCError(error.value, ERROR_DESCRIPTIONS[error])

                # parse measurement data
                if self._active_meas_mode == MeasureType.SPECTRAL:
                    data = SpectralData.extract_spectral_data(raw_data[2])
                elif self._active_meas_mode == MeasureType.FIFO:
                    data = SpectralData.extract_spectral_data(raw_data[2])
                else:
                    raise ChipLibError("Unsupported measurement mode {0}".format(0))

                # parse additional measurement data
                read_pointer = 0
                add_items = {}
                for item_id in self._active_meas_items:
                    if not item_id == ItemIds.RESERVED:
                        raw_item_size = CONFIG_ITEMS[item_id]["size"]
                        tmp_buffer = (c_uint8 * raw_item_size)(*raw_data[3][read_pointer:read_pointer+raw_item_size])
                        read_pointer += raw_item_size
                        raw_item_data = CONFIG_ITEMS[item_id]["type"].from_buffer(tmp_buffer)
                        add_items[item_id] = CONFIG_ITEMS[item_id]["c2py"](raw_item_data)

                yield (data, add_items)
            else:
                break
