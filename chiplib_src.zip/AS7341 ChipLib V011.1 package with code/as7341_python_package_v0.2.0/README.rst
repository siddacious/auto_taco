#######################
AS7341 - Python Package
#######################

This Python package is a collection of some function for the AS7341 sensor.
It provides an easy interface to take measurements with the AS7341 Evaluation Kit.


Installation Requirements
=========================

* Windows or Linux
* Python 3.5 or higher

.. note:: Chip Libraries for the supported operating systems
    are included in the Python package.


Example
=======

Use the help function to display an example for measurement execution
using the ams AS7341 Evaluation Board:

    $ python
    >>> import as7341
    >>> help(as7341)

