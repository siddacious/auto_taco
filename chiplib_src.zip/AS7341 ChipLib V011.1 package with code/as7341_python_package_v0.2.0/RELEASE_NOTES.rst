#####################################
AS7341 Python Package - Release Notes
#####################################

This Python package is a collection of some function for the AS7341 sensor.
It provides an easy interface to take measurements with the AS7341 Evaluation Kit.

*************
Version 0.2.0
*************

Supported measurement modes:
    * spectral measurements
    * fast measurement in FIFO mode

Supported hardware:
    * AS7341 Evaluation Board with FTDI cable
    * UniCom Board with firmware v0.10.0 via RPC

Included libraries:
    * AS7341 Chip library v0.10.1
    * AS7341 RPC client v0.10.0

Supported platforms
===================

Windows 10
----------
* x86_64


Resolved issues
===============
-

Known issues & limitations
==========================
-