ams software changelog (www.ams.com)
-------------------------------------------------------------------------------

Overview

        This document lists all notable changes to AS7341 ChipLib.

*******************************************************************************
Version 0.11.1 - 2020-06-24
*******************************************************************************

Version comment

        Bug fix version for spectral measurement


Added

        n/a


Changed

        n/a


Deprecated

        n/a


Removed

        n/a


Fixed

        * Fixed state machine of spectral measurement in interrupt mode 
          with more than one devices (Got faulty values)


Known issues & limitations

        n/a

*******************************************************************************
Version 0.11.0 - 2020-05-15
*******************************************************************************

Version comment

        Support of Synchronization


Added

        * Support for SYNS mode: External Synchronization by a falling edge trigger
        * standard include file as7341_stdinc.h to include system specific
          header files


Changed

        * changed 64 bit divisions to use macro DIV64


Deprecated

        n/a


Removed

        n/a


Fixed

        n/a


Known issues & limitations

        n/a

*******************************************************************************
Version 0.10.1
*******************************************************************************

Version comment

        Fixed OSAL-function 'spectral_osal_get_timestamp' 
        to run on 32bit operating systems


Added

        n/a


Changed

        * Changed parameter of function 'spectral_osal_get_timestamp' 
          from on 64bit to two 32bit values. 


Deprecated

        n/a


Removed

        n/a


Fixed

        n/a


Known issues & limitations

        n/a

*******************************************************************************
Version 0.10.0
*******************************************************************************

Version comment

        Added support of automatic gain control


Added

        * Support of automatic gain control
        * Support of gain factors


Changed

        * set_configuration can be used with readable items. 
          This items will be ignored.
        * item ITEM_ID_TIMESTAMP has a size of 64bit instead 32bit


Deprecated

        n/a


Removed

        n/a


Fixed

        * LED pattern failed if first configuration had a length of 1
        * Saturation on FIFO-mode results in faulty zero values


Known issues & limitations

        n/a

*******************************************************************************
Version 0.9.0
*******************************************************************************

Version comment

        First release version of this software component.


Added

        * Spectral measurement with up to 12 channels
        * Synchronization of LEDs and temperature sensors
        * Fast FIFO measurement


Changed

        n/a


Deprecated

        n/a


Removed

        n/a


Fixed

        n/a


Known issues & limitations

        n/a

