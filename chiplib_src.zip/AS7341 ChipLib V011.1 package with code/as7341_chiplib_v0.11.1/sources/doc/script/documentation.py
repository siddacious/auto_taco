import sys
import re

if __name__== "__main__":
    """
    first argument: version file
    second argument: tex file
    """
    version_file = sys.argv[1]
    tex_file = sys.argv[2]

    f = open(version_file, "r")
    lines = f.readlines()
    f.close()

    major = "0"
    minor = "0"
    patch = "0"
    build = "0"

    for line in lines:

        if line.startswith("#define"):
            match = re.findall(r"define VER_MAJOR (\d+)", line)
            if match:
                major = match[0]
            match = re.findall(r"define VER_MINOR (\d+)", line)
            if match:
                minor = match[0]
            match = re.findall(r"define VER_PATCH (\d+)", line)
            if match:
                patch = match[0]
            match = re.findall(r"define VER_BUILD (\d+)", line)
            if match:
                build = match[0]

    f = open(tex_file, "w+")
    f.write("revision v%s.%s.%s.%s" % (major, minor, patch, build))
    f.close()

