/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"

#include "as7341_chiplib.h"
#include "as7341_typedefs.h"
#include "chiplib/as7341_configuration.h"
#include "chiplib/as7341_measurement.h"
#include "error_codes.h"
#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/*! Helper for configuration data: Describes the byte offsets of every item */
enum chiplib_config_offsets {
    CONFIG_OFFSET_SIZE = 0,   /*!< Item size is the first byte */
    CONFIG_OFFSET_ITEM = 1,   /*!< The type of the item is the second byte */
    CONFIG_OFFSET_PAYLOAD = 2 /*!< The item-data starts on second byte */
};

/*! Identification of this module in logging messages */
#define MODULE_NAME "LIB"

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

/*! The current state of the measurement state machine */
static enum FSM_STATES g_fsm_state[NUM_SUPPORTED_DEVICES] = {FSM_STATE_UNKNOWN};

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

/*!
 * \brief Returns the read and optional write function of an item
 *
 * \param[in] osal_id - handle to the device
 * \param[in] item_id - identification of an item, which shall be read or write
 * \param[in] payload_size - item size
 * \param[out] pp_cmd_item_entry - pointer to the entry of the item handler
 * \returns ERR_SUCCESS, otherwise failure
 */
static err_code_t get_item_handler(const osal_id_t osal_id, uint8_t item_id, uint8_t payload_size,
                                   struct config_item_entry **pp_cmd_item_entry)
{
    err_code_t result;
    struct config_item_entry *p_item_table;
    uint32_t num_of_entries;

    M_CHECK_ARGUMENT_LOWER(item_id, ITEM_ID_MAX);

    result = config_get_item_table(osal_id, &p_item_table, &num_of_entries);
    if (ERR_SUCCESS == result) {
        *pp_cmd_item_entry = NULL;
        for (uint32_t i = 0; num_of_entries; i++) {
            if (item_id == p_item_table[i].item_id) {
                if (ITEM_NO_LENGTH_CHECK != p_item_table[i].size) {
                    if (payload_size == p_item_table[i].size) {
                        /* return pointer to entry */
                        *pp_cmd_item_entry = (struct config_item_entry *)&(p_item_table[i]);
                        break;
                    } else {
                        /* no match, stop now */
                        result = ERR_SIZE;
                        break;
                    }
                } else {
                    /* return pointer to entry */
                    *pp_cmd_item_entry = (struct config_item_entry *)&(p_item_table[i]);
                    break;
                }
            }
        }

        if (NULL != *pp_cmd_item_entry) {
            result = ERR_SUCCESS;
        }
    }

    return result;
}

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

err_code_t CHIPLIB_DECLDIR as7341_initialize(uint8_t device, as7341_callback_t p_callback, const void *p_cb_param,
                                             const char *p_interface_descr)
{
    err_code_t result;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_callback);

    if (FSM_STATE_UNKNOWN != g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    result = spectral_osal_initialize(osal_id, p_interface_descr);

    if (ERR_SUCCESS == result) {
        result = config_initialize(osal_id);
    }

    if (ERR_SUCCESS == result) {
        result = measure_initialize(osal_id, p_callback, p_cb_param);
    }

    if (ERR_SUCCESS == result) {
        g_fsm_state[device] = FSM_STATE_IDLE;
    } else {
        g_fsm_state[device] = FSM_STATE_UNKNOWN;
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_shutdown(uint8_t device)
{
    err_code_t result;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    if (FSM_STATE_UNKNOWN == g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    result = measure_shutdown(osal_id);

    if (ERR_SUCCESS == result) {
        result = config_shutdown(osal_id);
    }

    if (ERR_SUCCESS == result) {
        result = spectral_osal_shutdown(osal_id);
    }

    g_fsm_state[device] = FSM_STATE_UNKNOWN;

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_set_configuration(uint8_t device, uint8_t *p_data, uint32_t size)
{
    err_code_t result = ERR_SUCCESS;
    uint32_t i;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    if (FSM_STATE_IDLE != g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    for (i = 0; ERR_SUCCESS == result && i < size;) {
        result = as7341_set_item(device, (enum as7341_item_ids)p_data[i + CONFIG_OFFSET_ITEM],
                                 p_data + i + CONFIG_OFFSET_PAYLOAD, p_data[i + CONFIG_OFFSET_SIZE]);
        if (ERR_NOT_SUPPORTED == result) {
            result = ERR_SUCCESS;
        }
        i += p_data[i] + CONFIG_OFFSET_PAYLOAD;
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_configuration(uint8_t device, uint8_t *p_data, uint32_t *p_size)
{
    err_code_t result = ERR_SUCCESS;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};
    uint8_t i;
    uint32_t expected_size;
    uint8_t *p_data_pointer = p_data;
    uint8_t item_size;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_size);

    if (FSM_STATE_IDLE != g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    /* calculate the minimum size */
    expected_size = 0;
    for (i = ITEM_SIZE_RESERVED + 1; i < ITEM_ID_MAX && ERR_SUCCESS == result; i++) {
        result = config_get_item_size(osal_id, i, &item_size);
        expected_size += (uint32_t)item_size + CONFIG_OFFSET_PAYLOAD;
    }

    /* retrieve the necessary data size */
    if (NULL == p_data && 0 == *p_size) {
        *p_size = expected_size;
        result = ERR_SUCCESS;
    } else {
        M_CHECK_NULL_POINTER(p_data);

        if (expected_size > *p_size) {
            result = ERR_SIZE;
        } else {
            result = ERR_SUCCESS;
            for (i = 1; ERR_SUCCESS == result && i < ITEM_ID_MAX; i++) {
                result = config_get_item_size(osal_id, i, &item_size);
                if (ERR_SUCCESS == result) {
                    result = as7341_get_item(device, (enum as7341_item_ids)i, p_data_pointer + CONFIG_OFFSET_PAYLOAD,
                                             item_size);
                    if (ERR_NOT_SUPPORTED == result) {
                        result = ERR_SUCCESS;
                        continue;
                    }
                }

                if (ERR_SUCCESS == result) {
                    p_data_pointer[CONFIG_OFFSET_SIZE] = item_size;
                    p_data_pointer[CONFIG_OFFSET_ITEM] = i;
                    p_data_pointer += item_size + CONFIG_OFFSET_PAYLOAD;
                }
            }
            *p_size = p_data_pointer - p_data;
        }
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_set_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
{
    err_code_t result;
    struct config_item_entry *p_item_entry = NULL;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    if (FSM_STATE_IDLE != g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    result = get_item_handler(osal_id, id, size, &p_item_entry);
    if (ERR_SUCCESS == result) {
        if (NULL == p_item_entry->set_fct_pnt) {
            result = ERR_NOT_SUPPORTED;
        }
    }

    if (ERR_SUCCESS == result) {
        result = p_item_entry->set_fct_pnt(osal_id, p_item_entry->index, p_data, size);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_get_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
{
    err_code_t result;
    struct config_item_entry *p_item_entry = NULL;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);

    if (FSM_STATE_UNKNOWN == g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    result = get_item_handler(osal_id, id, size, &p_item_entry);
    if (ERR_SUCCESS == result) {
        if (NULL == p_item_entry->get_fct_pnt) {
            result = ERR_ARGUMENT;
        }
    }

    if (ERR_SUCCESS == result) {
        result = p_item_entry->get_fct_pnt(osal_id, p_item_entry->index, p_data, size);
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_start_measurement(uint8_t device)
{
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    if (FSM_STATE_IDLE != g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    return spectral_osal_set_event(osal_id, EVENT_START, 0);
}

err_code_t CHIPLIB_DECLDIR as7341_execute_state_machine(uint8_t device, enum as7341_states *p_state)
{
    err_code_t result, func_result = ERR_SUCCESS;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};
    uint16_t event, payload;
    uint8_t i;
    uint8_t event_handled = FALSE;
    struct transitions *p_transitions;
    uint32_t num_of_transitions;

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_state);

    if (FSM_STATE_UNKNOWN == g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    /* check if new event is available */
    result = spectral_osal_wait_for_event(osal_id, &event, &payload);
    if (ERR_SUCCESS == result) {
        if (event == EVENT_NONE) {
            if (FSM_STATE_IDLE == g_fsm_state[device]) {
                *p_state = STATE_CONFIG;
            } else {
                *p_state = STATE_MEASURE;
            }
            return ERR_SUCCESS;
        }
    }

    result = measure_get_transition_table(osal_id, &p_transitions, &num_of_transitions);

    for (i = 0; i < num_of_transitions; i++) {
        if (p_transitions[i].current_state == g_fsm_state[device] || FSM_STATE_ALL == p_transitions[i].current_state) {
            if (p_transitions[i].event == event) {
                if ((EVENT_NEW_STATE == p_transitions[i].event) && (p_transitions[i].new_state != payload)) {
                    continue;
                }
                log_debug(osal_id, MODULE_NAME, "Current state: %d, event: %d, new state: %d", g_fsm_state[device],
                          p_transitions[i].event, p_transitions[i].new_state);

                /* Set new state */
                g_fsm_state[device] = p_transitions[i].new_state;

                /* Call the state function if defined */
                if (NULL != p_transitions[i].func) {
                    func_result = p_transitions[i].func(osal_id, g_fsm_state[device]);
                }

                event_handled = TRUE;

                break;
            }
        }
    }

    if (!event_handled) {
        log_warn(osal_id, MODULE_NAME, "Event not handled: %d, payload: %d\n", event, payload);
    }

    if (ERR_SUCCESS != func_result) {
        measure_set_fsm_error(osal_id, func_result);
    }

    /* signal the application the current state */
    if (FSM_STATE_IDLE == g_fsm_state[device]) {
        *p_state = STATE_CONFIG;
    } else {
        *p_state = STATE_MEASURE;
    }

    return result;
}

err_code_t CHIPLIB_DECLDIR as7341_abort_measurement(uint8_t device)
{
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    M_CHECK_ARGUMENT_LOWER(device, NUM_SUPPORTED_DEVICES);

    if (FSM_STATE_UNKNOWN == g_fsm_state[device]) {
        return ERR_PERMISSION;
    }

    return spectral_osal_set_event(osal_id, EVENT_ABORT, 0);
}
