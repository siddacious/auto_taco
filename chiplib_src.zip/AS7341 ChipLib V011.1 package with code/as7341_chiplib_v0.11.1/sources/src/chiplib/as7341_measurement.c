/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"

#include "as7341_chiplib.h"
#include "as7341_typedefs.h"
#include "chiplib/as7341_configuration.h"
#include "chiplib/as7341_interface.h"
#include "chiplib/as7341_measurement.h"
#include "error_codes.h"
#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

#define LED_NOT_SUPPORTED 0xFFFE
#define USE_DEFAULT_BRIGHTNESS 0xFFFF
#define MAX_LED_BRIGHTNESS 1000
#define DEFAULT_LED_STATE 0
#define DEFAULT_LED_BRIGHTNESS 100
#define DEFAULT_LED_WAIT_TIME 100000
#define DEFAULT_BREAK_TIME 0
#define MAX_BREAK_TIME 10000000
#define MAX_GAIN_FACTOR 20000
#define GAIN_FACTOR_DIVIDER 10000

#define MODULE_NAME "MEAS"

enum LED_STATES { LED_STATE_NONE = 0, LED_STATE_ENABLED = 1, LED_STATE_DISABLED = 2 };

enum TIMER_IDS { TIMER_ID_MEASUREMENT = 0, TIMER_ID_TIME_OUT = 1, TIMER_ID_LED = 2 };

struct measurement_config {
    uint8_t type;
    uint8_t is_second_channel;
    uint8_t use_interrupt_pin;
    uint8_t autozero_counter;
    uint8_t led_enable_state[LED_ID_MAX];
    uint16_t spectral_data[MAX_SUPPORTED_CHANNEL_BLOCKS][NUM_OF_ADC_CHANNELS];
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS];
    uint8_t restart;
    int32_t count;
    uint16_t max_count;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM];
    uint16_t led_pattern_id;
    int32_t led_switch_count;
    uint16_t led_brightness[LED_ID_MAX];
    uint32_t led_on_wait_time;
    uint32_t fifo_wait_time_us;
    err_code_t global_fsm_error;
    as7341_callback_t p_callback;
    void *p_callback_parameter;
    uint32_t break_time_us;
    uint32_t old_wait_time_us;
    uint8_t autogain_lower;
    uint8_t autogain_upper;
    uint16_t gain_factors[AS7341_GAIN_FACTOR_NUM];
    uint8_t autogain_finished;
};

/* USER_CODE END DEFINITIONS */

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static struct measurement_config g_measurement_config[NUM_SUPPORTED_DEVICES];

/* described gain factors from datasheet (see Gain ratio) */
static const uint16_t g_default_gain_factors[AS7341_GAIN_FACTOR_NUM] = {9770,  9770,  9770,  9620,  10000, 10000,
                                                                        10000, 10000, 10000, 10130, 10320};

/* USER_CODE BEGIN GLOBALS */

/* USER_CODE END GLOBALS */

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

/* USER_CODE BEGIN LOCAL_FUNCTIONS */

static err_code_t configure_leds(const osal_id_t osal_id, uint8_t initialize, enum LED_STATES *p_led_state)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t new_settings = 0, old_settings = 0;
    uint8_t set_leds = FALSE;

    *p_led_state = LED_STATE_NONE;

    if (initialize) {
        if (0 != g_measurement_config[osal_id.dev].led_pattern[0].count) {
            /* set initial values for all LEDs */
            new_settings = g_measurement_config[osal_id.dev].led_pattern[0].config;
            old_settings = ~new_settings;
            set_leds = TRUE;
            g_measurement_config[osal_id.dev].led_pattern_id = 0;
            g_measurement_config[osal_id.dev].led_switch_count = g_measurement_config[osal_id.dev].led_pattern[0].count;
        }
    } else if ((g_measurement_config[osal_id.dev].led_switch_count - 1) == g_measurement_config[osal_id.dev].count) {
        /* set new LED configuration */
        new_settings =
            g_measurement_config[osal_id.dev].led_pattern[g_measurement_config[osal_id.dev].led_pattern_id + 1].config;
        old_settings =
            g_measurement_config[osal_id.dev].led_pattern[g_measurement_config[osal_id.dev].led_pattern_id].config;

        /* point to next configuration */
        g_measurement_config[osal_id.dev].led_switch_count +=
            g_measurement_config[osal_id.dev].led_pattern[g_measurement_config[osal_id.dev].led_pattern_id + 1].count;
        g_measurement_config[osal_id.dev].led_pattern_id++;
        set_leds = TRUE;
    }

    if (set_leds) {
        for (uint8_t i = 0; (ERR_SUCCESS == result) && (i < 8); i++) {
            if ((old_settings & (1 << i)) != (new_settings & (1 << i))) {
                result = measure_set_led(osal_id, i, new_settings & (1 << i), USE_DEFAULT_BRIGHTNESS);
                if (ERR_NOT_SUPPORTED == result && (initialize)) {
                    /* skip error message on initialization state only */
                    result = ERR_SUCCESS;
                }

                if (new_settings & (1 << i)) {
                    *p_led_state = LED_STATE_ENABLED;
                } else if (LED_STATE_NONE == *p_led_state) {
                    *p_led_state = LED_STATE_DISABLED;
                }
            }
        }
    }

    return result;
}

static err_code_t update_autozero_counter(const osal_id_t osal_id)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t auto_zero;

    result = as7341_get_internal_autozero(osal_id, &auto_zero);
    g_measurement_config[osal_id.dev].autozero_counter++;
    if (auto_zero <= g_measurement_config[osal_id.dev].autozero_counter) {
        g_measurement_config[osal_id.dev].autozero_counter = 0;
    }
    if (AS7341_AUTOZERO_ONE == auto_zero) {
        g_measurement_config[osal_id.dev].autozero_counter = AS7341_AUTOZERO_ONE;
    }

    return result;
}

static err_code_t calculate_integration_wait_time(const osal_id_t osal_id, uint32_t *p_wait_time)
{
    err_code_t result = ERR_SUCCESS;
    const uint32_t fix_overhead_time = 500;
    const uint32_t fix_autozero_overhead = 15000;
    uint8_t auto_zero;

    result = as7341_get_integration_time_us(osal_id, p_wait_time);

    if (ERR_SUCCESS == result) {
        result = as7341_get_internal_autozero(osal_id, &auto_zero);
    }

    if (ERR_SUCCESS == result) {
        *p_wait_time += fix_overhead_time;
        if (AS7341_AUTOZERO_NONE < auto_zero) {
            if (0 == g_measurement_config[osal_id.dev].autozero_counter) {
                *p_wait_time += fix_autozero_overhead;
            }
        }
    }

    return result;
}

static err_code_t set_fifo_wait_timer(const osal_id_t osal_id, uint8_t last_read_num)
{
    const uint32_t adjust = 100;

    log_debug(osal_id, MODULE_NAME, "FIFO timer: %d,last_read: %d", g_measurement_config[osal_id.dev].fifo_wait_time_us,
              last_read_num);
    if (60 < last_read_num && adjust < g_measurement_config[osal_id.dev].fifo_wait_time_us) {
        g_measurement_config[osal_id.dev].fifo_wait_time_us -= adjust;
    } else if (40 > last_read_num) {
        g_measurement_config[osal_id.dev].fifo_wait_time_us += adjust;
    }

    return spectral_osal_configure_timer(osal_id, TIMER_ID_MEASUREMENT,
                                         g_measurement_config[osal_id.dev].fifo_wait_time_us);
}

static err_code_t spectral_init(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    enum LED_STATES led_state;
    uint8_t gain;

    M_UNUSED_PARAM(fsm_state);

    g_measurement_config[osal_id.dev].is_second_channel = FALSE;
    g_measurement_config[osal_id.dev].count = 0;
    g_measurement_config[osal_id.dev].led_pattern_id = 0;
    g_measurement_config[osal_id.dev].led_switch_count = 0;
    g_measurement_config[osal_id.dev].autozero_counter = 0;
    g_measurement_config[osal_id.dev].restart = 0;
    memset(g_measurement_config[osal_id.dev].spectral_data, 0, sizeof(g_measurement_config[osal_id.dev].spectral_data));

    result = as7341_stop(osal_id, MEAS_TYPE_SPECTRAL);

    if (ERR_SUCCESS == result) {
        result = as7341_activate_interrupt(
            osal_id, (g_measurement_config[osal_id.dev].use_interrupt_pin) ? INTERRUPT_SPECTRAL : INTERRUPT_NONE);
    }

    /* Set break time again: integration time could be changed since the last
     * configuration */
    if (ERR_SUCCESS == result) {
        result = measure_set_break_time_us(osal_id, g_measurement_config[osal_id.dev].break_time_us);
    }

    /* check auto gain range */
    if (ERR_SUCCESS == result &&
        g_measurement_config[osal_id.dev].autogain_lower != g_measurement_config[osal_id.dev].autogain_upper) {
        result = as7341_get_saved_gain(osal_id, &gain);
        if (ERR_SUCCESS == result) {
            if (g_measurement_config[osal_id.dev].autogain_lower > gain ||
                g_measurement_config[osal_id.dev].autogain_upper < gain) {
                result = as7341_set_gain(osal_id, g_measurement_config[osal_id.dev].autogain_lower);
            }
        }
    }

    if (ERR_SUCCESS == result) {
        result = configure_leds(osal_id, TRUE, &led_state);
    }

    if (ERR_SUCCESS == result) {
        if (LED_STATE_NONE == led_state) {
            result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_CONF_BLOCK_0);
        } else {
            result = spectral_osal_configure_timer(
                osal_id, TIMER_ID_LED,
                (LED_STATE_ENABLED == led_state) ? g_measurement_config[osal_id.dev].led_on_wait_time : 0);

            if (ERR_SUCCESS == result) {
                result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_WAIT_FOR_LED_INIT_TIMER);
            }
        }
    }

    return result;
}

static err_code_t spectral_restart(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;

    M_UNUSED_PARAM(fsm_state);

    result = as7341_stop(osal_id, MEAS_TYPE_SPECTRAL);

    if (ERR_SUCCESS == result) {
        result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_RETRY);
    }

    if (ERR_SUCCESS == result) {
        result = as7341_start(osal_id, MEAS_TYPE_SPECTRAL);
    }

    if (ERR_SUCCESS == result) {
        g_measurement_config[osal_id.dev].autozero_counter = 0;
        g_measurement_config[osal_id.dev].restart = 1;
    }

    return result;
}

static err_code_t spectral_config(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    uint32_t wait_time;

    result = as7341_stop(osal_id, MEAS_TYPE_SPECTRAL);

    if (ERR_SUCCESS == result) {
        result = as7341_switch_channels(osal_id, g_measurement_config[osal_id.dev].is_second_channel);
    }

    if (ERR_SUCCESS == result) {
        result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE,
                                         FSM_STATE_WAIT_BLOCK_0 + (fsm_state - FSM_STATE_CONF_BLOCK_0));
    }

    if (ERR_SUCCESS == result && !g_measurement_config[osal_id.dev].use_interrupt_pin) {
        g_measurement_config[osal_id.dev].autozero_counter = 0;
        result = calculate_integration_wait_time(osal_id, &wait_time);
        if (ERR_SUCCESS == result) {
            result = spectral_osal_configure_timer(osal_id, TIMER_ID_MEASUREMENT, wait_time);
        }
    }

    if (ERR_SUCCESS == result) {
        result = as7341_start(osal_id, MEAS_TYPE_SPECTRAL);
    }

    return result;
}

static err_code_t check_interrupt(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    M_UNUSED_PARAM(fsm_state);

    return spectral_osal_check_pending_interrupt(osal_id);
}

static err_code_t check_spectral_finished(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    uint8_t state;

    result = as7341_is_data_ready(osal_id, &state);

    if (ERR_SUCCESS == result) {
        if (state) {
            result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE,
                                             FSM_STATE_READ_BLOCK_0 + fsm_state - FSM_STATE_CHECK_BLOCK_0_FINISHED);
        } else {
            result = spectral_osal_configure_timer(osal_id, TIMER_ID_MEASUREMENT, 5000);

            if (ERR_SUCCESS == result) {
                result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE,
                                                 FSM_STATE_WAIT_BLOCK_0 + fsm_state - FSM_STATE_CHECK_BLOCK_0_FINISHED);
            }
        }
    }

    return result;
}

static err_code_t spectral_read(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t state;

    result = as7341_get_channel_data(
        osal_id, g_measurement_config[osal_id.dev].spectral_data[g_measurement_config[osal_id.dev].is_second_channel],
        sizeof(g_measurement_config[osal_id.dev].spectral_data[0]));
    if (ERR_SUCCESS == result) {
        result = as7341_reset_interrupt(osal_id, INTERRUPT_SPECTRAL);
    }

    if (ERR_SUCCESS == result) {
        /* measurement finished, update counter for autozero */
        if (!g_measurement_config[osal_id.dev].use_interrupt_pin) {
            result = update_autozero_counter(osal_id);
        }
    }

    if (ERR_SUCCESS == result) {
        if (0 == fsm_state - FSM_STATE_READ_BLOCK_0) {
            result = as7341_is_second_smux_conf_available(osal_id, &state);
            if (ERR_SUCCESS == result) {
                if (FALSE != state) {
                    g_measurement_config[osal_id.dev].is_second_channel =
                        !g_measurement_config[osal_id.dev].is_second_channel;
                    result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE,
                                                     FSM_STATE_CONF_BLOCK_1 + FSM_STATE_READ_BLOCK_0 - fsm_state);
                } else {
                    /* no second channel configuration, jump to state where data will be
                     * sent to app */
                    result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_POST_PROCESS);
                }
            }
        } else {
            result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_POST_PROCESS);
        }
    }

    return result;
}

static err_code_t read_measurement_items(const osal_id_t osal_id, uint8_t *p_memory, uint32_t *p_size)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t i, item_size;
    uint16_t item_buffer_index = 0;

    M_CHECK_NULL_POINTER(p_memory);
    M_CHECK_NULL_POINTER(p_size);

    for (i = 0; i < sizeof(g_measurement_config[osal_id.dev].measure_items) && ERR_SUCCESS == result; i++) {
        if (ITEM_ID_RESERVED == g_measurement_config[osal_id.dev].measure_items[i]) {
            break;
        }

        result = config_get_item_size(osal_id, g_measurement_config[osal_id.dev].measure_items[i], &item_size);
        if (ERR_SUCCESS == result) {
            if ((item_buffer_index + item_size) > *p_size) {
                result = ERR_SIZE;
            }
        }

        if (ERR_SUCCESS == result) {
            result =
                as7341_get_item(osal_id.dev, (enum as7341_item_ids)g_measurement_config[osal_id.dev].measure_items[i],
                                p_memory + item_buffer_index, item_size);
        }

        if (ERR_SUCCESS == result) {
            item_buffer_index += (uint16_t)item_size;
        }
    }

    if (ERR_SUCCESS == result) {
        *p_size = item_buffer_index;
    }

    return result;
}

static err_code_t spectral_post_process(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    enum LED_STATES led_state;
    uint32_t items_size = AS7341_MAX_ITEM_BUFFER_SIZE;
    uint8_t item_buffer[AS7341_MAX_ITEM_BUFFER_SIZE];
    uint8_t value_numbers;
    uint16_t highest_value, maximum_adc;
    uint8_t is_saturation = 0;
    uint8_t current_gain, new_gain;
    uint8_t i;
    uint32_t value;

    M_UNUSED_PARAM(fsm_state);

    /* append additional items on the end of measurement data */
    result = read_measurement_items(osal_id, item_buffer, &items_size);

    if (ERR_SUCCESS == result) {
        result = as7341_is_second_smux_conf_available(osal_id, &value_numbers);
        value_numbers = (value_numbers + 1) * NUM_OF_ADC_CHANNELS;
    }
    if (ERR_SUCCESS == result) {
        result = as7341_get_maximum_spectral_adc(osal_id, &maximum_adc);
    }
    if (ERR_SUCCESS == result) {
        result = as7341_get_saved_gain(osal_id, &current_gain);
    }

    /* check auto gain */
    if (ERR_SUCCESS == result &&
        g_measurement_config[osal_id.dev].autogain_lower != g_measurement_config[osal_id.dev].autogain_upper) {
        result = as7341_get_highest_value((uint16_t *)(g_measurement_config[osal_id.dev].spectral_data), value_numbers,
                                          &highest_value);
        if (ERR_SUCCESS == result) {
            new_gain = current_gain;
            result =
                as7341_get_optimized_gain(maximum_adc, highest_value, g_measurement_config[osal_id.dev].autogain_lower,
                                          g_measurement_config[osal_id.dev].autogain_upper, &new_gain, &is_saturation);
        }
        if (ERR_SUCCESS == result) {
            if (new_gain != current_gain) {
                result = as7341_stop(osal_id, MEAS_TYPE_SPECTRAL);
                if (ERR_SUCCESS == result) {
                    result = as7341_set_gain(osal_id, new_gain);
                }
                if (ERR_SUCCESS == result) {
                    result = as7341_start(osal_id, MEAS_TYPE_SPECTRAL);
                }
            } else if (is_saturation) {
                result = ERR_SATURATION;
            }
        }
    }

    if (ERR_SUCCESS == result && !is_saturation) {
        /* multiply values with gain factors */
        for (i = 0; i < value_numbers; i++) {
            value = (uint32_t)(g_measurement_config[osal_id.dev].spectral_data[0][i]) *
                    (uint32_t)(g_measurement_config[osal_id.dev].gain_factors[current_gain]) / GAIN_FACTOR_DIVIDER;
            if (maximum_adc <= value || maximum_adc <= g_measurement_config[osal_id.dev].spectral_data[0][i]) {
                g_measurement_config[osal_id.dev].spectral_data[0][i] = AS7341_SATURATED;
            } else {
                g_measurement_config[osal_id.dev].spectral_data[0][i] = (uint16_t)value;
            }
        }

        /* send data to application */
        g_measurement_config[osal_id.dev].p_callback(
            osal_id.dev, ERR_SUCCESS, (uint8_t *)g_measurement_config[osal_id.dev].spectral_data,
            value_numbers * sizeof(uint16_t), (0 < items_size) ? item_buffer : NULL, items_size,
            g_measurement_config[osal_id.dev].p_callback_parameter);

        /* configure LEDs */
        result = configure_leds(osal_id, FALSE, &led_state);
    }

    if (ERR_SUCCESS == result) {
        if (!is_saturation) {
            if (LED_STATE_NONE == led_state) {
                result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_RETRY);
            } else {
                result = spectral_osal_configure_timer(
                    osal_id, TIMER_ID_LED,
                    (LED_STATE_ENABLED == led_state) ? g_measurement_config[osal_id.dev].led_on_wait_time : 0);

                if (ERR_SUCCESS == result) {
                    result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_WAIT_FOR_LED_MEAS_TIMER);
                }
            }
        } else {
            g_measurement_config[osal_id.dev].count--;
            result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_RETRY);
        }
    }

    return result;
}

static err_code_t spectral_retry(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result = ERR_SUCCESS;
    uint32_t wait_time;

    M_UNUSED_PARAM(fsm_state);

    g_measurement_config[osal_id.dev].count++;

    if (0 != g_measurement_config[osal_id.dev].max_count &&
        (uint32_t)(g_measurement_config[osal_id.dev].max_count) <= (uint16_t)g_measurement_config[osal_id.dev].count) {
        result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_ABORT);
    } else {
        if (!g_measurement_config[osal_id.dev].use_interrupt_pin) {
            result = calculate_integration_wait_time(osal_id, &wait_time);
            if (0 == g_measurement_config[osal_id.dev].restart) {
                wait_time += g_measurement_config[osal_id.dev].break_time_us;
            } else {
                g_measurement_config[osal_id.dev].restart = 0;
            }

            if (ERR_SUCCESS == result) {
                result = spectral_osal_configure_timer(osal_id, TIMER_ID_MEASUREMENT, wait_time);
            }
        }

        if (ERR_SUCCESS == result) {
            result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_0);
        }
    }

    return result;
}

static err_code_t spectral_abort(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;

    M_UNUSED_PARAM(fsm_state);

    result = as7341_stop(osal_id, MEAS_TYPE_SPECTRAL);
    if (ERR_SUCCESS == result) {
        result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_IDLE);
    }

    return result;
}

static err_code_t spectral_error(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    M_UNUSED_PARAM(fsm_state);

    g_measurement_config[osal_id.dev].p_callback(osal_id.dev, g_measurement_config[osal_id.dev].global_fsm_error, NULL,
                                                 0, NULL, 0, g_measurement_config[osal_id.dev].p_callback_parameter);
    return spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_ABORT);
}

static err_code_t fifo_init(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    uint8_t gain;

    M_UNUSED_PARAM(fsm_state);

    g_measurement_config[osal_id.dev].count = 0;

    result = as7341_set_fsmux(osal_id);
    if (ERR_SUCCESS == result) {
        result = as7341_activate_interrupt(
            osal_id, (g_measurement_config[osal_id.dev].use_interrupt_pin) ? INTERRUPT_FIFO : INTERRUPT_NONE);
    }

    /* check auto gain range */
    g_measurement_config[osal_id.dev].autogain_finished = 0;
    if (ERR_SUCCESS == result &&
        g_measurement_config[osal_id.dev].autogain_lower != g_measurement_config[osal_id.dev].autogain_upper) {
        result = as7341_get_saved_fgain(osal_id, &gain);
        if (ERR_SUCCESS == result) {
            if (g_measurement_config[osal_id.dev].autogain_lower > gain ||
                g_measurement_config[osal_id.dev].autogain_upper < gain) {
                result = as7341_set_fgain(osal_id, g_measurement_config[osal_id.dev].autogain_lower);
            }
        }
    }

    if (ERR_SUCCESS == result && !g_measurement_config[osal_id.dev].use_interrupt_pin) {
        result = as7341_get_fifo_integration_time_us(osal_id, &g_measurement_config[osal_id.dev].fifo_wait_time_us);
        g_measurement_config[osal_id.dev].fifo_wait_time_us *= 16;
        g_measurement_config[osal_id.dev].fifo_wait_time_us += 200;
        if (ERR_SUCCESS == result) {
            result = set_fifo_wait_timer(osal_id, 0);
        }
    }

    if (ERR_SUCCESS == result) {
        result = as7341_start(osal_id, MEAS_TYPE_FIFO);
    }

    return result;
}

static err_code_t fifo_transfer(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    err_code_t result;
    uint8_t fifo_buffer[254];
    uint8_t size = sizeof(fifo_buffer);
    uint32_t size32;
    uint8_t is_abort = 0;
    uint32_t items_size = AS7341_MAX_ITEM_BUFFER_SIZE;
    uint8_t item_buffer[AS7341_MAX_ITEM_BUFFER_SIZE];
    uint16_t highest_value, maximum_adc;
    uint8_t is_saturation = 0;
    uint8_t current_gain, new_gain;

    M_UNUSED_PARAM(fsm_state);

    result = as7341_get_flicker_data(osal_id, fifo_buffer, &size);
    if (ERR_SUCCESS == result && 0 < size) {

        /* check auto gain */
        if (g_measurement_config[osal_id.dev].autogain_lower != g_measurement_config[osal_id.dev].autogain_upper) {
            result = as7341_get_highest_value((uint16_t *)fifo_buffer, size / sizeof(uint16_t), &highest_value);
            if (ERR_SUCCESS == result) {
                result = as7341_get_saved_fgain(osal_id, &current_gain);
            }
            if (ERR_SUCCESS == result) {
                result = as7341_get_maximum_fifo_adc(osal_id, &maximum_adc);
            }

            if (ERR_SUCCESS == result) {
                new_gain = current_gain;
                result = as7341_get_optimized_gain(
                    maximum_adc, highest_value, g_measurement_config[osal_id.dev].autogain_lower,
                    g_measurement_config[osal_id.dev].autogain_upper, &new_gain, &is_saturation);
            }
            if (ERR_SUCCESS == result) {
                if (new_gain != current_gain && !g_measurement_config[osal_id.dev].autogain_finished) {
                    result = as7341_stop(osal_id, MEAS_TYPE_FIFO);
                    if (ERR_SUCCESS == result) {
                        result = as7341_set_fgain(osal_id, new_gain);
                    }
                    if (ERR_SUCCESS == result) {
                        result = spectral_osal_set_event(osal_id, EVENT_NEW_STATE, FSM_STATE_FIFO_RESTART);
                    }
                    is_abort = 1;
                    log_debug(osal_id, MODULE_NAME, "F AUTOGAIN: %d", new_gain);
                } else if (is_saturation) {
                    result = ERR_SATURATION;
                } else {
                    g_measurement_config[osal_id.dev].autogain_finished = 1;
                }
            }
        }

        if (ERR_SUCCESS == result && !is_abort) {
            if (0 != g_measurement_config[osal_id.dev].max_count &&
                ((uint32_t)(g_measurement_config[osal_id.dev].max_count) <=
                 (g_measurement_config[osal_id.dev].count + (size / sizeof(uint16_t))))) {
                size32 =
                    ((uint32_t)g_measurement_config[osal_id.dev].max_count - g_measurement_config[osal_id.dev].count) *
                    sizeof(uint16_t);
            } else {
                size32 = (uint32_t)size;
            }

            /* append additional items on the end of measurement data */
            result = read_measurement_items(osal_id, item_buffer, &items_size);

            if (ERR_SUCCESS == result) {
                log_debug(osal_id, MODULE_NAME, "F CALLBACK: %d", size32);
                g_measurement_config[osal_id.dev].p_callback(osal_id.dev, ERR_SUCCESS, fifo_buffer, size32,
                                                             (0 < items_size) ? item_buffer : NULL, items_size,
                                                             g_measurement_config[osal_id.dev].p_callback_parameter);
            }

            if (ERR_SUCCESS == result && (0 != g_measurement_config[osal_id.dev].max_count)) {
                g_measurement_config[osal_id.dev].count += size32 / sizeof(uint16_t);
                if ((uint32_t)(g_measurement_config[osal_id.dev].max_count) <=
                    (uint16_t)g_measurement_config[osal_id.dev].count) {
                    result = spectral_osal_set_event(osal_id, EVENT_ABORT, 0);
                    is_abort = 1;
                }
            }
        }
    }

    if (ERR_SUCCESS == result && !is_abort) {
        if (!g_measurement_config[osal_id.dev].use_interrupt_pin) {
            result = set_fifo_wait_timer(osal_id, size);
        } else {
            result = check_interrupt(osal_id, FSM_STATE_UNKNOWN);
        }
    }

    return result;
}

static err_code_t fifo_abort(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    M_UNUSED_PARAM(fsm_state);

    return as7341_stop(osal_id, MEAS_TYPE_FIFO);
}

static err_code_t fifo_error(const osal_id_t osal_id, enum FSM_STATES fsm_state)
{
    M_UNUSED_PARAM(fsm_state);

    g_measurement_config[osal_id.dev].p_callback(osal_id.dev, g_measurement_config[osal_id.dev].global_fsm_error, NULL,
                                                 0, NULL, 0, g_measurement_config[osal_id.dev].p_callback_parameter);
    return spectral_osal_set_event(osal_id, EVENT_ABORT, 0);
}

static const struct transitions g_state_transitions_spectral[] = {
    /* CURRENT_STATE  | EVENT   |  NEW STATE    | FUNCTION */
    {FSM_STATE_IDLE, EVENT_START, FSM_STATE_INIT, spectral_init},
    {FSM_STATE_INIT, EVENT_NEW_STATE, FSM_STATE_CONF_BLOCK_0, spectral_config},
    {FSM_STATE_INIT, EVENT_NEW_STATE, FSM_STATE_WAIT_FOR_LED_INIT_TIMER, NULL},
    {FSM_STATE_WAIT_FOR_LED_INIT_TIMER, EVENT_TIMER_LED, FSM_STATE_CONF_BLOCK_0, spectral_config},

    {FSM_STATE_CONF_BLOCK_0, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_0, check_interrupt},
    {FSM_STATE_CONF_BLOCK_1, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_1, check_interrupt},

    {FSM_STATE_WAIT_BLOCK_0, EVENT_INTERRUPT, FSM_STATE_CHECK_BLOCK_0_FINISHED, check_spectral_finished},
    {FSM_STATE_WAIT_BLOCK_1, EVENT_INTERRUPT, FSM_STATE_CHECK_BLOCK_1_FINISHED, check_spectral_finished},

    {FSM_STATE_WAIT_BLOCK_0, EVENT_TIMER_MEASUREMENT, FSM_STATE_CHECK_BLOCK_0_FINISHED, check_spectral_finished},
    {FSM_STATE_WAIT_BLOCK_1, EVENT_TIMER_MEASUREMENT, FSM_STATE_CHECK_BLOCK_1_FINISHED, check_spectral_finished},

    {FSM_STATE_CHECK_BLOCK_0_FINISHED, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_0, NULL},
    {FSM_STATE_CHECK_BLOCK_1_FINISHED, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_1, NULL},

    {FSM_STATE_CHECK_BLOCK_0_FINISHED, EVENT_NEW_STATE, FSM_STATE_READ_BLOCK_0, spectral_read},
    {FSM_STATE_CHECK_BLOCK_1_FINISHED, EVENT_NEW_STATE, FSM_STATE_READ_BLOCK_1, spectral_read},

    {FSM_STATE_READ_BLOCK_0, EVENT_NEW_STATE, FSM_POST_PROCESS, spectral_post_process},
    {FSM_STATE_READ_BLOCK_0, EVENT_NEW_STATE, FSM_STATE_CONF_BLOCK_1, spectral_config},
    {FSM_STATE_READ_BLOCK_1, EVENT_NEW_STATE, FSM_POST_PROCESS, spectral_post_process},

    {FSM_POST_PROCESS, EVENT_NEW_STATE, FSM_STATE_RETRY, spectral_retry},
    {FSM_POST_PROCESS, EVENT_NEW_STATE, FSM_STATE_WAIT_FOR_LED_MEAS_TIMER, NULL},
    {FSM_STATE_WAIT_FOR_LED_MEAS_TIMER, EVENT_TIMER_LED, FSM_STATE_RESTART, spectral_restart},
    {FSM_STATE_RESTART, EVENT_NEW_STATE, FSM_STATE_RETRY, spectral_retry},

    {FSM_STATE_RETRY, EVENT_NEW_STATE, FSM_STATE_WAIT_BLOCK_0, check_interrupt},
    {FSM_STATE_RETRY, EVENT_NEW_STATE, FSM_STATE_ABORT, spectral_abort},

    {FSM_STATE_ABORT, EVENT_NEW_STATE, FSM_STATE_IDLE, NULL},
    {FSM_STATE_ERROR, EVENT_NEW_STATE, FSM_STATE_ABORT, spectral_abort},

    /* special events which will be handled all the time */
    {FSM_STATE_ALL, EVENT_ABORT, FSM_STATE_ABORT, spectral_abort},
    {FSM_STATE_ALL, EVENT_ERROR, FSM_STATE_ERROR, spectral_error},
};

static const struct transitions g_state_transitions_fifo[] = {
    /* CURRENT_STATE  | EVENT   |  NEW STATE    | FUNCTION */
    {FSM_STATE_IDLE, EVENT_START, FSM_STATE_FIFO_READ, fifo_init},
    {FSM_STATE_FIFO_READ, EVENT_INTERRUPT, FSM_STATE_FIFO_READ, fifo_transfer},
    {FSM_STATE_FIFO_READ, EVENT_TIMER_MEASUREMENT, FSM_STATE_FIFO_READ, fifo_transfer},
    {FSM_STATE_FIFO_READ, EVENT_NEW_STATE, FSM_STATE_FIFO_RESTART, fifo_init},
    {FSM_STATE_FIFO_RESTART, EVENT_INTERRUPT, FSM_STATE_FIFO_READ, fifo_transfer},
    {FSM_STATE_FIFO_RESTART, EVENT_TIMER_MEASUREMENT, FSM_STATE_FIFO_READ, fifo_transfer},

    /* special events which will be handled all the time */
    {FSM_STATE_ALL, EVENT_ABORT, FSM_STATE_IDLE, fifo_abort},
    {FSM_STATE_ALL, EVENT_ERROR, FSM_STATE_ALL, fifo_error},
};

/* USER_CODE END LOCAL_FUNCTIONS */

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

/* USER_CODE BEGIN GLOBAL_FUNCTIONS */

err_code_t measure_initialize(osal_id_t osal_id, as7341_callback_t p_callback, const void *p_callback_parameter)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t i;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_callback);

    memset(&g_measurement_config[osal_id.dev], 0, sizeof(struct measurement_config));

    g_measurement_config[osal_id.dev].p_callback = p_callback;
    g_measurement_config[osal_id.dev].p_callback_parameter = (void *)p_callback_parameter;

    g_measurement_config[osal_id.dev].type = MEASUREMENT_TYPE_SPECTRAL;
    g_measurement_config[osal_id.dev].max_count = 0;
    g_measurement_config[osal_id.dev].led_on_wait_time = DEFAULT_LED_WAIT_TIME;
    g_measurement_config[osal_id.dev].use_interrupt_pin = FALSE;

    g_measurement_config[osal_id.dev].autogain_lower = GAIN_0_5X;
    g_measurement_config[osal_id.dev].autogain_upper = GAIN_0_5X;

    memset(g_measurement_config[osal_id.dev].measure_items, ITEM_SIZE_RESERVED,
           sizeof(g_measurement_config[osal_id.dev].measure_items));

    memcpy(g_measurement_config[osal_id.dev].gain_factors, g_default_gain_factors,
           sizeof(g_measurement_config[osal_id.dev].gain_factors));

    /* set old value to a different one as new one */
    g_measurement_config[osal_id.dev].old_wait_time_us = DEFAULT_BREAK_TIME + 1;
    result = measure_set_break_time_us(osal_id, DEFAULT_BREAK_TIME);

    for (i = 0; i < LED_ID_MAX && ERR_SUCCESS == result; i++) {
        result = measure_set_led(osal_id, i, DEFAULT_LED_STATE, DEFAULT_LED_BRIGHTNESS);

        if (result == ERR_NOT_SUPPORTED) {
            g_measurement_config[osal_id.dev].led_brightness[i] = LED_NOT_SUPPORTED;
            result = ERR_SUCCESS;
            log_info(osal_id, MODULE_NAME, "External LED ID %d can't be initialized", i);
        }
    }

    return result;
}

err_code_t measure_shutdown(osal_id_t osal_id)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t i;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    for (i = 0; i < LED_ID_MAX && ERR_SUCCESS == result; i++) {
        result = measure_set_led(osal_id, i, DEFAULT_LED_STATE, DEFAULT_LED_BRIGHTNESS);
    }
    return ERR_SUCCESS;
}

err_code_t measure_get_transition_table(osal_id_t osal_id, struct transitions **pp_transition_table,
                                        uint32_t *p_num_transitions)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(pp_transition_table);
    M_CHECK_NULL_POINTER(p_num_transitions);

    if (MEASUREMENT_TYPE_SPECTRAL == g_measurement_config[osal_id.dev].type) {
        *pp_transition_table = (struct transitions *)g_state_transitions_spectral;
        *p_num_transitions = sizeof(g_state_transitions_spectral) / sizeof(struct transitions);
    } else if (MEASUREMENT_TYPE_FIFO == g_measurement_config[osal_id.dev].type) {
        *pp_transition_table = (struct transitions *)g_state_transitions_fifo;
        *p_num_transitions = sizeof(g_state_transitions_fifo) / sizeof(struct transitions);
    }

    return ERR_SUCCESS;
}

err_code_t measure_set_fsm_error(osal_id_t osal_id, err_code_t error_code)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    g_measurement_config[osal_id.dev].global_fsm_error = error_code;

    return spectral_osal_set_event(osal_id, EVENT_ERROR, 0);
}

err_code_t measure_set_measurement_type(osal_id_t osal_id, uint8_t type)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER(type, MEASUREMENT_TYPE_NUM);

    g_measurement_config[osal_id.dev].type = type;

    return ERR_SUCCESS;
}

err_code_t measure_get_measurement_type(osal_id_t osal_id, uint8_t *p_type)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_type);

    *p_type = g_measurement_config[osal_id.dev].type;
    return ERR_SUCCESS;
}

err_code_t measure_set_measurement_count(osal_id_t osal_id, uint16_t count)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    g_measurement_config[osal_id.dev].max_count = count;

    return ERR_SUCCESS;
}

err_code_t measure_get_measurement_count(osal_id_t osal_id, uint16_t *p_count)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_count);

    *p_count = g_measurement_config[osal_id.dev].max_count;
    return ERR_SUCCESS;
}

err_code_t measure_enable_interrupt_pin(osal_id_t osal_id, uint8_t enable)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    g_measurement_config[osal_id.dev].use_interrupt_pin = enable;

    return ERR_SUCCESS;
}

err_code_t measure_is_interrupt_pin_enabled(osal_id_t osal_id, uint8_t *p_enabled)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_enabled);

    *p_enabled = g_measurement_config[osal_id.dev].use_interrupt_pin;
    return ERR_SUCCESS;
}

err_code_t measure_set_led_wait_time(osal_id_t osal_id, uint32_t wait_time_us)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(wait_time_us, 10000000);

    g_measurement_config[osal_id.dev].led_on_wait_time = wait_time_us;

    return ERR_SUCCESS;
}

err_code_t measure_get_led_wait_time(osal_id_t osal_id, uint32_t *p_wait_time_us)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_wait_time_us);

    *p_wait_time_us = g_measurement_config[osal_id.dev].led_on_wait_time;
    return ERR_SUCCESS;
}

err_code_t measure_set_led_pattern(osal_id_t osal_id, uint16_t *p_led_pattern, uint8_t size)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_led_pattern);
    M_CHECK_SIZE(size, ITEM_SIZE_LED_PATTERN / sizeof(uint16_t));

    memset(g_measurement_config[osal_id.dev].led_pattern, 0, ITEM_SIZE_LED_PATTERN);
    memcpy(g_measurement_config[osal_id.dev].led_pattern, (void *)p_led_pattern,
           sizeof(g_measurement_config[osal_id.dev].led_pattern[0]) * size);

    return ERR_SUCCESS;
}

err_code_t measure_get_led_pattern(osal_id_t osal_id, uint16_t *p_led_pattern, uint8_t size)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_led_pattern);
    M_CHECK_SIZE(size, ITEM_SIZE_LED_PATTERN / sizeof(uint16_t));

    memcpy((void *)p_led_pattern, g_measurement_config[osal_id.dev].led_pattern,
           sizeof(g_measurement_config[osal_id.dev].led_pattern[0]) * size);

    return ERR_SUCCESS;
}

err_code_t measure_set_led(osal_id_t osal_id, uint8_t led_id, uint8_t enable, uint16_t led_brightness)
{
    err_code_t result;
    uint8_t led_driving_strength = 0;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER(led_id, LED_ID_MAX);

    if ((MAX_LED_BRIGHTNESS < led_brightness) && (USE_DEFAULT_BRIGHTNESS != led_brightness)) {
        return ERR_ARGUMENT;
    }

    if (USE_DEFAULT_BRIGHTNESS == led_brightness) {
        led_brightness = g_measurement_config[osal_id.dev].led_brightness[led_id];
    }

    if (LED_ID_INTERN == led_id) {
        led_brightness =
            (uint16_t)((MAX_LED_DRIVING_STRENGTH * (uint32_t)led_brightness * 10 / MAX_LED_BRIGHTNESS) + 5) / 10;
        if (4 <= led_brightness) {
            led_driving_strength = (led_brightness >> 1) - 2;
        }
        if (enable) {
            led_driving_strength |= REG_BIT_LED_LED_ACT_MSK;
        }
        result = as7341_set_led(osal_id, led_driving_strength);
        if (ERR_SUCCESS == result) {
            /* calculate the real per mile */
            led_brightness = (uint16_t)(MAX_LED_BRIGHTNESS * (uint32_t)led_brightness / MAX_LED_DRIVING_STRENGTH);
        }
    } else if (LED_ID_OUTPUT == led_id) {
        /* brightness isn't used here, clear it */
        led_brightness = 0;
        result = as7341_set_oc_output_low(osal_id, enable);
    } else {
        result = spectral_osal_set_led(osal_id, led_id - 1, (enable) ? led_brightness : 0);
    }

    if (ERR_SUCCESS == result) {
        g_measurement_config[osal_id.dev].led_brightness[led_id] = led_brightness;
        g_measurement_config[osal_id.dev].led_enable_state[led_id] = !!enable;
    }
    return result;
}

err_code_t measure_get_led(osal_id_t osal_id, uint8_t led_id, uint8_t *p_enable, uint16_t *p_led_brightness)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_enable);
    M_CHECK_NULL_POINTER(p_led_brightness);
    M_CHECK_ARGUMENT_LOWER(led_id, LED_ID_MAX);

    if (LED_NOT_SUPPORTED == g_measurement_config[osal_id.dev].led_brightness[led_id]) {
        return ERR_NOT_SUPPORTED;
    }

    *p_enable = g_measurement_config[osal_id.dev].led_enable_state[led_id];
    *p_led_brightness = g_measurement_config[osal_id.dev].led_brightness[led_id];

    return ERR_SUCCESS;
}

err_code_t measure_set_items(osal_id_t osal_id, uint8_t *p_data, uint8_t size)
{
    uint8_t i;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_SIZE(ITEM_SIZE_MEASURE_ITEMS, size);

    for (i = 0; i < ITEM_SIZE_MEASURE_ITEMS; i++) {
        if (ITEM_ID_MAX <= p_data[i]) {
            return ERR_ARGUMENT;
        }
    }

    memcpy(g_measurement_config[osal_id.dev].measure_items, p_data, size);

    return ERR_SUCCESS;
}

err_code_t measure_get_items(osal_id_t osal_id, uint8_t *p_data, uint8_t size)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_SIZE(ITEM_SIZE_MEASURE_ITEMS, size);

    memcpy(p_data, g_measurement_config[osal_id.dev].measure_items, size);

    return ERR_SUCCESS;
}

err_code_t measure_set_break_time_us(const osal_id_t osal_id, uint32_t wait_break_us)
{
    err_code_t result;
    uint32_t wait_time_us;
    uint32_t integration_time_us;
    uint32_t wait_time_reg;
    uint8_t enable;
    uint8_t long_bit;
    const uint32_t minimum_break_time_us = 2780;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(wait_break_us, MAX_BREAK_TIME);

    result = as7341_get_integration_time_us(osal_id, &integration_time_us);
    if (ERR_SUCCESS != result) {
        return result;
    }

    wait_time_us = integration_time_us + wait_break_us;
    if (wait_time_us != g_measurement_config[osal_id.dev].old_wait_time_us) {
        if (0 == wait_break_us) {
            enable = FALSE;
            wait_time_reg = 0;
            long_bit = 0;
            result = ERR_SUCCESS;
        } else if (minimum_break_time_us <= wait_break_us) {
            enable = 1;

            if (MAX_WAIT_TIME_US < wait_time_us) {
                result = ERR_SENSOR_CONFIG;
            } else {
                if (MAX_WAIT_TIME_US_WITHOUT_WLONG < wait_time_us) {
                    long_bit = 1;
                    wait_time_us /= WAIT_TIME_WLONG_FACTOR;
                } else {
                    long_bit = 0;
                }
                /* Calculate wait time register with rounding: REG = (WAIT_MS / 2.78ms)
                 * - 1 */
                wait_time_reg =
                    (uint32_t)(DIV64_S64((DIV64_S64((uint64_t)wait_time_us * INTEGRATION_TIME_STEP_US_DIVIDER,
                                                    INTEGRATION_TIME_STEP_US_FACTOR) +
                                          DIV64_S64(CONVERSION_FACTOR_MS_TO_US, 2)),
                                         CONVERSION_FACTOR_MS_TO_US) -
                               1);

                if (255 < wait_time_reg) {
                    return ERR_ARGUMENT;
                }
            }
        } else {
            return ERR_ARGUMENT;
        }

        if (ERR_SUCCESS == result) {
            result = as7341_set_wait_time(osal_id, (uint8_t)wait_time_reg, enable, long_bit);
            if (ERR_SUCCESS == result) {
                g_measurement_config[osal_id.dev].old_wait_time_us = integration_time_us + wait_break_us;
                if (enable) {
                    wait_time_us = ((uint32_t)wait_time_reg + 1) * CONVERSION_FACTOR_MS_TO_US *
                                   INTEGRATION_TIME_STEP_US_FACTOR / INTEGRATION_TIME_STEP_US_DIVIDER;

                    if (long_bit) {
                        wait_time_us *= WAIT_TIME_WLONG_FACTOR;
                    }

                    /* rounding */
                    wait_time_us = ((wait_time_us + 5) / 10) * 10;

                    g_measurement_config[osal_id.dev].break_time_us = wait_time_us - integration_time_us;
                } else {
                    g_measurement_config[osal_id.dev].break_time_us = 0;
                }
            }
        }
    }

    return result;
}

err_code_t measure_get_break_time_us(const osal_id_t osal_id, uint32_t *p_wait_break_us)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_wait_break_us);

    *p_wait_break_us = g_measurement_config[osal_id.dev].break_time_us;
    return ERR_SUCCESS;
}

err_code_t measure_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us_l, uint32_t *p_timestamp_us_h)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_timestamp_us_l);
    M_CHECK_NULL_POINTER(p_timestamp_us_h);

    result = spectral_osal_get_timestamp(osal_id, p_timestamp_us_l, p_timestamp_us_h);

    return result;
}

err_code_t measure_set_auto_gain(const osal_id_t osal_id, uint8_t lower_limit, uint8_t upper_limit)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    M_CHECK_ARGUMENT_LOWER_EQUAL(upper_limit, GAIN_512X);
    M_CHECK_ARGUMENT_LOWER_EQUAL(lower_limit, upper_limit);

    g_measurement_config[osal_id.dev].autogain_lower = lower_limit;
    g_measurement_config[osal_id.dev].autogain_upper = upper_limit;

    return ERR_SUCCESS;
}

err_code_t measure_get_auto_gain(const osal_id_t osal_id, uint8_t *p_lower_limit, uint8_t *p_upper_limit)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_lower_limit);
    M_CHECK_NULL_POINTER(p_upper_limit);

    *p_lower_limit = g_measurement_config[osal_id.dev].autogain_lower;
    *p_upper_limit = g_measurement_config[osal_id.dev].autogain_upper;

    return ERR_SUCCESS;
}

err_code_t measure_set_gain_factors(const osal_id_t osal_id, uint16_t *p_data, uint8_t length)
{
    uint8_t i;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_SIZE(sizeof(g_measurement_config[osal_id.dev].gain_factors) / sizeof(uint16_t), length);

    for (i = 0; i < length; i++) {
        M_CHECK_ARGUMENT_LOWER_EQUAL(p_data[i], MAX_GAIN_FACTOR);
        if (0 == p_data[i]) {
            return ERR_ARGUMENT;
        }
    }

    memcpy(g_measurement_config[osal_id.dev].gain_factors, p_data,
           sizeof(g_measurement_config[osal_id.dev].gain_factors));

    return ERR_SUCCESS;
}

err_code_t measure_get_gain_factors(const osal_id_t osal_id, uint16_t *p_data, uint8_t length)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_SIZE(sizeof(g_measurement_config[osal_id.dev].gain_factors) / sizeof(uint16_t), length);

    memcpy(p_data, g_measurement_config[osal_id.dev].gain_factors,
           sizeof(g_measurement_config[osal_id.dev].gain_factors));

    return ERR_SUCCESS;
}

/* USER_CODE END GLOBAL_FUNCTIONS */
