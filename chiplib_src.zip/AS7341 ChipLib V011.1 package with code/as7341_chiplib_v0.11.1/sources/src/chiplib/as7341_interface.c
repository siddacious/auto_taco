/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"

#include "as7341_typedefs.h"
#include "chiplib/as7341_interface.h"
#include "error_codes.h"
#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

#define MAX_GAIN_INDEX 10
#define MAX_ADC_COUNT 65535
#define DEFAULT_AUTOZERO_CONF 255
#define PART_NUM_ID 0x09
#define DEFAULT_LED_CONF 0x00
#define DEFAULT_ASTEP 599
#define DEFAULT_ATIME 29
#define DEFAULT_GAIN 9
#define DEFAULT_FD_TIME 359
#define DEFAULT_FD_GAIN 5
#define DEFAULT_LED_REG_VALUE 0
#define DEFAULT_WTIME_REG_VALUE 0
#define DEFAULT_WTIME_ENABLE_BIT 0
#define DEFAULT_LONG_WTIME_ENABLE_BIT 0
#define DEFAULT_OUTPUT_LOW_STATE 0
#define SIZE_OF_SMUX_BUFFER 21
#define FIFO_THRESHOLD 16
#define DEFAULT_FCHANNELS (FCHANNEL_FLICKER_MASK)
#define MIN_ASTEP 1
#define MAX_ASTEP 65534
#define MIN_ITIME_US 6
#define MAX_ITIME_US 46602667
#define MIN_FTIME_US 3
#define MAX_FTIME_US 5689

#define ALL_CHANNELS 0xC9B6196D86 /* mask all available channels */

#define LOW_AUTO_GAIN_VALUE 3
#define AUTO_GAIN_DIVIDER 2
#define IS_SATURATION 1
#define SATURATION_LOW_PERCENT 80
#define SATURATION_HIGH_PERCENT 100

#define FIFO_SIZE_ERROR 126
#define MAX_FD_TIME 0x07FF
#define FD_GAIN_REG_OFFSET 3
#define BYTE_SHIFT 8
#define BYTE_MSK 0xFF

#define REG_BIT_CFG0_REG_BANK_OFFSET 4
#define REG_BIT_PART_ID_OFFSET 2

#define REG_BIT_CONFIG_LED_SEL_MSK 0x08
#define REG_BIT_CFG0_WLONG_MSK 0x04
#define REG_BIT_CFG1_AGAIN_MSK 0x1F
#define REG_BIT_CFG6_SMUX_CMD_WRITE 0x10
#define REG_BIT_CFG8_FIFO_TH_MSK 0xC0
#define REG_BIT_STATUS_2_AVALID_MSK 0x40
#define REG_BIT_GPIO_2_GPIO_OUT_MSK 0x02
#define REG_BIT_GPIO_2_GPIO_IN_EN_MSK 0x04

#define REG_BIT_CONTROL_FIFO_CLR_MSK 0x02

#define REG_BIT_FIFO_CFG_0_FIFO_WRITE_FD_MSK 0xA1

#define REG_BIT_FD_TIME_2_FD_TIME_MSK 0x07

#define REG_BIT_STATUS_6_FIFO_OV_MSK 0x80
#define REG_BIT_STATUS_6_OVTEMP_MSK 0x20
#define REG_BIT_STATUS_6_FD_TRIG_MSK 0x10

#define REG_BIT_CONFIG_INT_MODE_MSK 0x03
#define REG_BIT_CONFIG_INT_MODE_SYNS_MSK 0x01

enum REGISTER_ENABLE_BITS {
    REG_ENABLE_BIT_FDEN = 0x40,
    REG_ENABLE_BIT_SMUX_EN = 0x10,
    REG_ENABLE_BIT_WEN = 0x08,
    REG_ENABLE_BIT_SP_EN = 0x02,
    REG_ENABLE_BIT_PON = 0x01,
};

struct device_config {
    uint8_t long_wait_time;
    uint8_t auto_zero;
    uint8_t again;
    uint8_t atime;
    uint16_t astep;
    uint8_t register_enable;
    uint8_t smux_config[2][SIZE_OF_SMUX_BUFFER]; /* first byte for register address
                                                    and 20 bytes for configuration */
    uint8_t channels[CHANNEL_NUMBER];
    uint8_t second_smux_config_available;
    uint8_t register_gpio_2;
    uint16_t ftime;
    uint8_t fgain;
    uint32_t fchannels;
    uint8_t fsmux_config[SIZE_OF_SMUX_BUFFER];
};

/* USER_CODE END DEFINITIONS */

#define MODULE_NAME "IFCE"

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static struct device_config g_device_config[NUM_SUPPORTED_DEVICES];

/* USER_CODE BEGIN GLOBALS */

const uint16_t g_channel_settings[CHANNEL_NUMBER] = {
    AS7341_SMUX_DISABLE, AS7341_SMUX_F1, AS7341_SMUX_F2, AS7341_SMUX_F3,  AS7341_SMUX_F4,    AS7341_SMUX_F5,
    AS7341_SMUX_F6,      AS7341_SMUX_F7, AS7341_SMUX_F8, AS7341_SMUX_NIR, AS7341_SMUX_CLEAR, AS7341_SMUX_FLICKER};
const uint8_t g_default_channels[CHANNEL_NUMBER] = {CHANNEL_F1,    CHANNEL_F2,      CHANNEL_F3,  CHANNEL_F4,
                                                    CHANNEL_CLEAR, CHANNEL_FLICKER, CHANNEL_F5,  CHANNEL_F6,
                                                    CHANNEL_F7,    CHANNEL_F8,      CHANNEL_NIR, CHANNEL_FLICKER};
const uint8_t g_fifo_channels[] = {AS7341_SMUX_F1_1,    AS7341_SMUX_F1_2,    AS7341_SMUX_F2_1, AS7341_SMUX_F2_2,
                                   AS7341_SMUX_F3_1,    AS7341_SMUX_F3_2,    AS7341_SMUX_F4_1, AS7341_SMUX_F4_2,
                                   AS7341_SMUX_F5_1,    AS7341_SMUX_F5_2,    AS7341_SMUX_F6_1, AS7341_SMUX_F6_2,
                                   AS7341_SMUX_F7_1,    AS7341_SMUX_F7_2,    AS7341_SMUX_F8_1, AS7341_SMUX_F8_2,
                                   AS7341_SMUX_CLEAR_1, AS7341_SMUX_CLEAR_2, AS7341_SMUX_NIR,  AS7341_SMUX_FLICKER};

/* USER_CODE END GLOBALS */

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

/* USER_CODE BEGIN LOCAL_FUNCTIONS */

static err_code_t write_register(osal_id_t osal_id, uint8_t address, uint8_t value)
{
    uint8_t send_data[2] = {address, value};

    return spectral_osal_transfer_data(osal_id, send_data, sizeof(send_data), NULL, 0);
}

static err_code_t read_register(osal_id_t osal_id, uint8_t address, uint8_t *p_value)
{
    return spectral_osal_transfer_data(osal_id, &address, sizeof(address), p_value, 1);
}

static err_code_t write_register_16bit(osal_id_t osal_id, uint8_t address, uint16_t value)
{
    uint8_t send_data[3] = {address, (uint8_t)(value & 0xFF), (uint8_t)(value >> 8)};

    return spectral_osal_transfer_data(osal_id, send_data, sizeof(send_data), NULL, 0);
}

static err_code_t read_register_16bit(osal_id_t osal_id, uint8_t address, uint16_t *p_value)
{
    return spectral_osal_transfer_data(osal_id, &address, sizeof(address), (uint8_t *)p_value, 2);
}

static err_code_t switch_to_memory_bank(osal_id_t osal_id, uint8_t is_mem_bank)
{
    uint8_t value = !is_mem_bank << REG_BIT_CFG0_REG_BANK_OFFSET;

    /* handle global variable long wait time as well */
    if (g_device_config[osal_id.dev].long_wait_time) {
        value |= REG_BIT_CFG0_WLONG_MSK;
    }

    return write_register(osal_id, AS7341_REGADDR_CFG0, value);
}

static err_code_t set_led_pin(osal_id_t osal_id)
{
    uint8_t value;
    err_code_t result;

    result = read_register(osal_id, AS7341_REGADDR_CONFIG, &value);
    if (ERR_SUCCESS == result) {
        value |= REG_BIT_CONFIG_LED_SEL_MSK;
        result = write_register(osal_id, AS7341_REGADDR_CONFIG, value);
    }

    return result;
}

static err_code_t set_power_on(osal_id_t osal_id)
{
    g_device_config[osal_id.dev].register_enable = REG_ENABLE_BIT_PON;
    return write_register(osal_id, AS7341_REGADDR_ENABLE, g_device_config[osal_id.dev].register_enable);
}

static err_code_t set_power_off(osal_id_t osal_id)
{
    g_device_config[osal_id.dev].register_enable = 0;
    return write_register(osal_id, AS7341_REGADDR_ENABLE, g_device_config[osal_id.dev].register_enable);
}

static err_code_t set_smux_config(osal_id_t osal_id, uint8_t *p_smux_config, uint8_t size)
{
    err_code_t result;

    M_CHECK_SIZE(SIZE_OF_SMUX_BUFFER, size);

    /* switch register bank */
    result = switch_to_memory_bank(osal_id, TRUE);

    /* write smux conf from ram to smux chain*/
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_CFG6, REG_BIT_CFG6_SMUX_CMD_WRITE);
    }

    /* write smux config to ram */
    if (ERR_SUCCESS == result) {
        result = spectral_osal_transfer_data(osal_id, p_smux_config, size, NULL, 0);
    }

    /* power on, start smux command */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_ENABLE,
                                g_device_config[osal_id.dev].register_enable | REG_ENABLE_BIT_SMUX_EN);
    }

    /* switch register bank */
    if (ERR_SUCCESS == result) {
        result = switch_to_memory_bank(osal_id, FALSE);
    }

    return result;
}

static uint8_t find_highest_bit(uint32_t value)
{
    uint8_t i = 0;
    uint8_t order = 0;

    for (i = 0; i < 32; i++) {
        if (value == 0) {
            break;
        } else if ((value >> i) & 1) {
            order = i;
        }
    }

    return order;
}

/* USER_CODE END LOCAL_FUNCTIONS */

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

/* USER_CODE BEGIN GLOBAL_FUNCTIONS */

err_code_t as7341_get_highest_value(uint16_t *p_data, uint32_t number, uint16_t *p_highest)
{
    uint32_t i;

    M_CHECK_NULL_POINTER(p_data);
    M_CHECK_NULL_POINTER(p_highest);

    if (0 == number) {
        return ERR_SIZE;
    }

    *p_highest = p_data[0];
    for (i = 1; i < number; i++) {
        if (*p_highest < p_data[i]) {
            *p_highest = p_data[i];
        }
    }
    return ERR_SUCCESS;
}

err_code_t as7341_get_optimized_gain(uint16_t maximum_adc, uint16_t highest_adc, uint8_t lower_gain_limit,
                                     uint8_t upper_gain_limit, uint8_t *p_gain, uint8_t *p_saturation)
{
    uint32_t gain_change;

    M_CHECK_NULL_POINTER(p_gain);
    M_CHECK_NULL_POINTER(p_saturation);

    if (highest_adc == 0) {
        highest_adc = 1;
    }

    if (highest_adc >= maximum_adc) {
        /* saturation detected */
        if (*p_gain > LOW_AUTO_GAIN_VALUE) {
            *p_gain /= AUTO_GAIN_DIVIDER;
        } else {
            *p_gain = lower_gain_limit;
        }
        *p_saturation = IS_SATURATION;
    } else {
        /* value too low, increase the gain */
        gain_change =
            (SATURATION_LOW_PERCENT * (uint32_t)maximum_adc) / (SATURATION_HIGH_PERCENT * (uint32_t)highest_adc);
        if (gain_change == 0 && *p_gain != 0) {
            (*p_gain)--;
        } else {
            gain_change = find_highest_bit(gain_change);
            if (((uint32_t)(*p_gain) + gain_change) > upper_gain_limit) {
                *p_gain = upper_gain_limit;
            } else {
                *p_gain += (uint8_t)gain_change;
            }
        }
        *p_saturation = !IS_SATURATION;
    }

    if (lower_gain_limit > *p_gain) {
        *p_gain = lower_gain_limit;
    }

    return ERR_SUCCESS;
}

err_code_t as7341_open(osal_id_t osal_id)
{
    err_code_t result;
    uint8_t part_id;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    memset(&g_device_config[osal_id.dev], 0, sizeof(struct device_config));

    /* check if AS7341 is available */
    result = as7341_get_part_id(osal_id, &part_id);
    if (ERR_SUCCESS == result) {
        if (PART_NUM_ID != part_id) {
            result = ERR_IDENTIFICATION;
        }
    }

    /* switch to lower register set */
    if (ERR_SUCCESS == result) {
        result = switch_to_memory_bank(osal_id, FALSE);
    }

    /* disable and enable chip power for reset */
    if (ERR_SUCCESS == result) {
        result = set_power_off(osal_id);
    }
    if (ERR_SUCCESS == result) {
        result = set_power_on(osal_id);
    }

    /* disable all interrupts */
    if (ERR_SUCCESS == result) {
        result = as7341_activate_interrupt(osal_id, INTERRUPT_NONE);
    }

    /* configure LED */
    if (ERR_SUCCESS == result) {
        result = as7341_set_led(osal_id, DEFAULT_LED_CONF);
        if (ERR_SUCCESS == result) {
            result = set_led_pin(osal_id);
        }
    }

    /* set autozero to default */
    if (ERR_SUCCESS == result) {
        result = as7341_set_autozero(osal_id, DEFAULT_AUTOZERO_CONF);
    }

    /* set channels */
    if (ERR_SUCCESS == result) {
        result = as7341_set_channel_config(osal_id, (uint8_t *)g_default_channels, sizeof(g_default_channels));
    }

    /* set integration time */
    if (ERR_SUCCESS == result) {
        result = as7341_set_atime(osal_id, DEFAULT_ATIME);
    }
    if (ERR_SUCCESS == result) {
        result = as7341_set_astep(osal_id, DEFAULT_ASTEP);
    }

    /* set gain */
    if (ERR_SUCCESS == result) {
        result = as7341_set_gain(osal_id, DEFAULT_GAIN);
    }

    /* set wtime */
    if (ERR_SUCCESS == result) {
        result = as7341_set_wait_time(osal_id, DEFAULT_WTIME_REG_VALUE, DEFAULT_WTIME_ENABLE_BIT,
                                      DEFAULT_LONG_WTIME_ENABLE_BIT);
    }

    /* register_gpio_2 */
    if (ERR_SUCCESS == result) {
        result = as7341_set_oc_output_low(osal_id, DEFAULT_OUTPUT_LOW_STATE);
    }

    /* disable sync mode */
    if (ERR_SUCCESS == result) {
        result = as7341_set_sync_mode(osal_id, FALSE);
    }

    /* set LED */
    if (ERR_SUCCESS == result) {
        result = as7341_set_led(osal_id, DEFAULT_LED_REG_VALUE);
    }

    /* configure flicker */
    if (ERR_SUCCESS == result) {
        result = as7341_configure_flicker(osal_id);
    }
    if (ERR_SUCCESS == result) {
        result = as7341_set_fgain(osal_id, DEFAULT_FD_GAIN);
    }
    if (ERR_SUCCESS == result) {
        result = as7341_set_ftime(osal_id, DEFAULT_FD_TIME);
    }
    if (ERR_SUCCESS == result) {
        result = as7341_set_fchannels(osal_id, DEFAULT_FCHANNELS);
    }

    return result;
}

err_code_t as7341_close(osal_id_t osal_id)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    /* disable LED */
    result = as7341_set_led(osal_id, DEFAULT_LED_CONF);

    /* go to low power mode */
    if (ERR_SUCCESS == result) {
        result = set_power_off(osal_id);
    }

    return result;
}

err_code_t as7341_get_part_id(osal_id_t osal_id, uint8_t *p_part_id)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_part_id);

    result = read_register(osal_id, AS7341_REGADDR_ID, p_part_id);
    if (result == ERR_SUCCESS) {
        *p_part_id = *p_part_id >> REG_BIT_PART_ID_OFFSET;
    }

    return result;
}

err_code_t as7341_set_atime(osal_id_t osal_id, uint8_t atime)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    result = write_register(osal_id, AS7341_REGADDR_ATIME, atime);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].atime = atime;
    }

    return result;
}

err_code_t as7341_get_atime(osal_id_t osal_id, uint8_t *p_atime)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_atime);

    result = read_register(osal_id, AS7341_REGADDR_ATIME, p_atime);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].atime = *p_atime;
    }

    return result;
}

err_code_t as7341_set_astep(osal_id_t osal_id, uint16_t astep)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    /* ASTEP and ATIME must not be 0 at same time. Therefore, check it here */
    /* ASTEP must not be 65535 */
    if (MIN_ASTEP > astep || MAX_ASTEP < astep) {
        return ERR_ARGUMENT;
    }

    result = write_register_16bit(osal_id, AS7341_REGADDR_ASTEP, astep);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].astep = astep;
    }

    return result;
}

err_code_t as7341_get_astep(osal_id_t osal_id, uint16_t *p_astep)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_astep);

    result = read_register_16bit(osal_id, AS7341_REGADDR_ASTEP, p_astep);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].astep = *p_astep;
    }

    return result;
}

err_code_t as7341_set_integration_time_us(const osal_id_t osal_id, uint32_t time_us)
{
    err_code_t result;
    int64_t time;
    uint8_t atime = 0;
    uint16_t astep = 0xFFFF / 2;
    int64_t astep_i64;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (MIN_ITIME_US > time_us || MAX_ITIME_US < time_us) {
        return ERR_ARGUMENT;
    }

    time = DIV64_S64((int64_t)time_us * INTEGRATION_TIME_STEP_US_DIVIDER, INTEGRATION_TIME_STEP_US_FACTOR);
    time = DIV64_S64(time, ((int64_t)astep + 1));
    time -= 1;

    if (0 > time) {
        atime = 0;
    } else if (255 < time) {
        atime = 255;
    } else {
        atime = (uint8_t)time;
    }

    astep_i64 = DIV64_S64((int64_t)time_us * INTEGRATION_TIME_STEP_US_DIVIDER * 10, INTEGRATION_TIME_STEP_US_FACTOR);
    astep_i64 = DIV64_S64(astep_i64, ((int64_t)atime + 1)) + 5;
    astep_i64 = DIV64_S64(astep_i64, 10);
    astep_i64 -= 1;

    if (MIN_ASTEP > astep_i64 || MAX_ASTEP < astep_i64) {
        return ERR_ARGUMENT;
    } else {
        astep = (uint16_t)astep_i64;
    }

    result = as7341_set_astep(osal_id, astep);

    if (ERR_SUCCESS == result) {
        result = as7341_set_atime(osal_id, atime);
    }

    return result;
}

err_code_t as7341_get_integration_time_us(osal_id_t osal_id, uint32_t *p_time_us)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_time_us);

    *p_time_us = (uint32_t)DIV64_U64(
        (DIV64_U64(((uint64_t)g_device_config[osal_id.dev].atime + 1) *
                       ((uint64_t)g_device_config[osal_id.dev].astep + 1) * INTEGRATION_TIME_STEP_US_FACTOR * 10,
                   INTEGRATION_TIME_STEP_US_DIVIDER) +
         5),
        10);

    return ERR_SUCCESS;
}

err_code_t as7341_get_maximum_spectral_adc(osal_id_t osal_id, uint16_t *p_max_adc)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_max_adc);

    uint32_t value =
        ((uint32_t)g_device_config[osal_id.dev].astep + 1) * ((uint32_t)g_device_config[osal_id.dev].atime + 1);
    if (MAX_ADC_COUNT < value) {
        value = MAX_ADC_COUNT;
    }

    *p_max_adc = (uint16_t)value;

    return ERR_SUCCESS;
}

err_code_t as7341_set_wait_time(osal_id_t osal_id, uint8_t wtime, uint8_t enable, uint8_t long_time)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    /* switch between short and long wait time */
    g_device_config[osal_id.dev].long_wait_time = long_time != 0;
    result = switch_to_memory_bank(osal_id, 0);

    /* Set wait time value */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_WTIME, wtime);
    }

    /* Enable/disable wait time */
    if (ERR_SUCCESS == result) {
        if (0 != enable) {
            g_device_config[osal_id.dev].register_enable |= REG_ENABLE_BIT_WEN;
        } else {
            g_device_config[osal_id.dev].register_enable &= ~REG_ENABLE_BIT_WEN;
        }
        result = write_register(osal_id, AS7341_REGADDR_ENABLE, g_device_config[osal_id.dev].register_enable);
    }

    return result;
}

err_code_t as7341_get_wait_time(osal_id_t osal_id, uint8_t *p_wtime, uint8_t *p_enable, uint8_t *p_long_time)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_wtime);
    M_CHECK_NULL_POINTER(p_enable);
    M_CHECK_NULL_POINTER(p_long_time);

    *p_enable = !!(g_device_config[osal_id.dev].register_enable & REG_ENABLE_BIT_WEN);
    *p_long_time = g_device_config[osal_id.dev].long_wait_time;

    return read_register(osal_id, AS7341_REGADDR_WTIME, p_wtime);
}

err_code_t as7341_set_gain(osal_id_t osal_id, uint8_t gain)
{
    err_code_t result = ERR_SUCCESS;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(gain, MAX_GAIN_INDEX);

    result = write_register(osal_id, AS7341_REGADDR_CFG1, gain);
    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].again = gain;
    }

    return result;
}

err_code_t as7341_get_gain(osal_id_t osal_id, uint8_t *p_gain)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_gain);

    result = read_register(osal_id, AS7341_REGADDR_CFG1, p_gain);
    *p_gain &= REG_BIT_CFG1_AGAIN_MSK;
    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].again = *p_gain;
    }

    return result;
}

err_code_t as7341_get_saved_gain(osal_id_t osal_id, uint8_t *p_gain)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_gain);

    *p_gain = g_device_config[osal_id.dev].again;
    return ERR_SUCCESS;
}

err_code_t as7341_start(osal_id_t osal_id, enum AS7341_MEASURE_TYPE type)
{
    err_code_t result = ERR_SUCCESS;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (MEAS_TYPE_SPECTRAL & type) {
        /* Enable spectral measurement */
        g_device_config[osal_id.dev].register_enable |= REG_ENABLE_BIT_SP_EN;
    }

    if (MEAS_TYPE_FIFO & type) {
        /* Clear FIFO buffer */
        result = write_register(osal_id, AS7341_REGADDR_CONTROL, REG_BIT_CONTROL_FIFO_CLR_MSK);
        g_device_config[osal_id.dev].register_enable |= REG_ENABLE_BIT_FDEN;
    }

    /* Enable measurement */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_ENABLE, g_device_config[osal_id.dev].register_enable);
    }

    return result;
}

err_code_t as7341_stop(osal_id_t osal_id, enum AS7341_MEASURE_TYPE type)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (MEAS_TYPE_FIFO & type) {
        g_device_config[osal_id.dev].register_enable &= ~REG_ENABLE_BIT_FDEN;
    }
    if (MEAS_TYPE_SPECTRAL & type) {
        g_device_config[osal_id.dev].register_enable &= ~REG_ENABLE_BIT_SP_EN;
    }

    return write_register(osal_id, AS7341_REGADDR_ENABLE, g_device_config[osal_id.dev].register_enable);
}

err_code_t as7341_get_channel_data(osal_id_t osal_id, uint16_t *p_channel_data, uint8_t size)
{
    uint8_t reg_addr = AS7341_REGADDR_CH0_DATA;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_channel_data);
    M_CHECK_SIZE(NUM_OF_ADC_CHANNELS * sizeof(*p_channel_data), size);

    return spectral_osal_transfer_data(osal_id, &reg_addr, sizeof(reg_addr), (uint8_t *)p_channel_data,
                                       NUM_OF_ADC_CHANNELS * sizeof(*p_channel_data));
}

err_code_t as7341_switch_channels(osal_id_t osal_id, uint8_t block)
{
    err_code_t result = ERR_SUCCESS;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER(block, MAX_SUPPORTED_CHANNEL_BLOCKS);

    result = set_smux_config(osal_id, g_device_config[osal_id.dev].smux_config[block],
                             sizeof(g_device_config[osal_id.dev].smux_config[block]));

    return result;
}

err_code_t as7341_is_data_ready(osal_id_t osal_id, uint8_t *p_state)
{
    uint8_t value;
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_state);

    result = read_register(osal_id, AS7341_REGADDR_STATUS2, &value);

    if (ERR_SUCCESS == result) {
        if (value & REG_BIT_STATUS_2_AVALID_MSK) {
            *p_state = TRUE;
        } else {
            *p_state = FALSE;
        }
    }

    return result;
}

err_code_t as7341_set_channel_config(osal_id_t osal_id, uint8_t *p_channel_conf, uint8_t size)
{
    uint8_t smux_value;
    uint8_t i, j;
    uint8_t pixel;
    uint8_t offset = 1; /* jump over register address */
    uint8_t channel;
    uint8_t second_smux = 0;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_channel_conf);
    M_CHECK_SIZE(CHANNEL_NUMBER, size);

    memset(g_device_config[osal_id.dev].smux_config, 0, sizeof(g_device_config[osal_id.dev].smux_config));

    for (i = 1; i <= CHANNEL_NUMBER; i++) {
        if ((CHANNEL_NUMBER / 2) < i) {
            offset = SIZE_OF_SMUX_BUFFER + 1; /* jump over register address */
        }
        channel = ((i - 1) % NUM_OF_ADC_CHANNELS) + 1;

        for (j = 0; j < MAX_SUPPORTED_CHANNEL_BLOCKS; j++) {

            pixel = (g_channel_settings[p_channel_conf[i - 1]] >> (j * 8)) & 0xFF;

            if (AS7341_SMUX_DISABLE != pixel) {
                if (pixel > AS7341_SMUX_FLICKER) {
                    /* illegal range */
                    return ERR_ARGUMENT;
                }

                smux_value = g_device_config[osal_id.dev].smux_config[0][offset + (pixel / 2)];

                if ((pixel % 2) > 0) {
                    if (smux_value & 0xF0) {
                        return ERR_ARGUMENT;
                    }
                    smux_value |= channel << 4; /* write channel order to high half-byte */
                } else {
                    if (smux_value & 0x0F) {
                        return ERR_ARGUMENT;
                    }
                    smux_value |= channel; /* write channel order to low half-byte */
                }
                if ((0 != smux_value) && (SIZE_OF_SMUX_BUFFER < offset)) {
                    second_smux = 1;
                }
                g_device_config[osal_id.dev].smux_config[0][offset + (pixel / 2)] = smux_value;
            }
        }
    }

    /* save the data for user readout */
    memcpy(g_device_config[osal_id.dev].channels, p_channel_conf, sizeof(g_device_config[osal_id.dev].channels));
    g_device_config[osal_id.dev].second_smux_config_available = second_smux;

    return ERR_SUCCESS;
}

err_code_t as7341_get_channel_config(osal_id_t osal_id, uint8_t *p_channel_conf, uint8_t size)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_channel_conf);
    M_CHECK_SIZE(CHANNEL_NUMBER, size);

    memcpy(p_channel_conf, g_device_config[osal_id.dev].channels, sizeof(g_device_config[osal_id.dev].channels));
    return ERR_SUCCESS;
}

err_code_t as7341_get_serial(osal_id_t osal_id, uint32_t *p_timestamp, uint32_t *p_tester_id)
{
    uint8_t address = AS7341_REGADDR_CHIP_ID;
    uint8_t data[5];
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_timestamp);
    M_CHECK_NULL_POINTER(p_tester_id);

    result = spectral_osal_transfer_data(osal_id, &address, 1, data, sizeof(data));
    if (ERR_SUCCESS == result) {
        memcpy(p_timestamp, data, sizeof(*p_timestamp));
        *p_tester_id = (uint32_t)data[4];
    }
    return result;
}

err_code_t as7341_set_autozero(osal_id_t osal_id, uint8_t autozero)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    result = write_register(osal_id, AS7341_REGADDR_AZCONFIG, autozero);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].auto_zero = autozero;
    }

    return result;
}

err_code_t as7341_get_autozero(osal_id_t osal_id, uint8_t *p_autozero)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_autozero);

    result = read_register(osal_id, AS7341_REGADDR_AZCONFIG, p_autozero);

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].auto_zero = *p_autozero;
    }

    return result;
}

err_code_t as7341_get_internal_autozero(osal_id_t osal_id, uint8_t *p_autozero)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_autozero);

    *p_autozero = g_device_config[osal_id.dev].auto_zero;
    return ERR_SUCCESS;
}

err_code_t as7341_set_led(osal_id_t osal_id, uint8_t config)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    return write_register(osal_id, AS7341_REGADDR_LED, config);
}

err_code_t as7341_get_led(osal_id_t osal_id, uint8_t *p_config)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_config);

    return read_register(osal_id, AS7341_REGADDR_LED, p_config);
}

err_code_t as7341_set_sync_mode(osal_id_t osal_id, uint8_t enable)
{
    err_code_t result;
    uint8_t reg_val;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(enable, 1);

    result = read_register(osal_id, AS7341_REGADDR_CONFIG, &reg_val);
    if (ERR_SUCCESS == result) {
        reg_val &= ~REG_BIT_CONFIG_INT_MODE_MSK;
        if (enable) {
            reg_val |= REG_BIT_CONFIG_INT_MODE_SYNS_MSK;
        }
        result = write_register(osal_id, AS7341_REGADDR_CONFIG, reg_val);
    }

    if (ERR_SUCCESS == result) {
        if (enable) {
            g_device_config[osal_id.dev].register_gpio_2 |= REG_BIT_GPIO_2_GPIO_IN_EN_MSK;
        } else {
            g_device_config[osal_id.dev].register_gpio_2 &= ~REG_BIT_GPIO_2_GPIO_IN_EN_MSK;
        }
        result = write_register(osal_id, AS7341_REGADDR_GPIO2, g_device_config[osal_id.dev].register_gpio_2);
    }

    return result;
}

err_code_t as7341_get_sync_mode(osal_id_t osal_id, uint8_t *p_enable)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_enable);

    result = read_register(osal_id, AS7341_REGADDR_CONFIG, p_enable);
    if (ERR_SUCCESS == result) {
        if (0 == (*p_enable & REG_BIT_CONFIG_INT_MODE_MSK)) {
            *p_enable = FALSE;
        } else {
            *p_enable = TRUE;
        }
    }

    return result;
}

err_code_t as7341_set_oc_output_low(osal_id_t osal_id, uint8_t is_low)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (is_low) {
        g_device_config[osal_id.dev].register_gpio_2 &= ~REG_BIT_GPIO_2_GPIO_OUT_MSK;
    } else {
        g_device_config[osal_id.dev].register_gpio_2 |= REG_BIT_GPIO_2_GPIO_OUT_MSK;
    }

    return write_register(osal_id, AS7341_REGADDR_GPIO2, g_device_config[osal_id.dev].register_gpio_2);
}

err_code_t as7341_get_oc_output_low(osal_id_t osal_id, uint8_t *p_is_low)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_is_low);

    result = read_register(osal_id, AS7341_REGADDR_GPIO2, p_is_low);
    if (ERR_SUCCESS == result) {
        if (REG_BIT_GPIO_2_GPIO_OUT_MSK & (*p_is_low)) {
            *p_is_low = FALSE;
        } else {
            *p_is_low = TRUE;
        }
    }

    return result;
}

err_code_t as7341_activate_interrupt(osal_id_t osal_id, uint8_t interrupt)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    return write_register(osal_id, AS7341_REGADDR_INTENAB, interrupt);
}

err_code_t as7341_reset_interrupt(osal_id_t osal_id, uint8_t interrupt)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    return write_register(osal_id, AS7341_REGADDR_STATUS, interrupt);
}

err_code_t as7341_is_second_smux_conf_available(osal_id_t osal_id, uint8_t *p_state)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_state);

    *p_state = g_device_config[osal_id.dev].second_smux_config_available;

    return ERR_SUCCESS;
}

err_code_t as7341_configure_flicker(osal_id_t osal_id)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    /* disable flicker */
    result = as7341_stop(osal_id, MEAS_TYPE_FIFO);

    /* disable interrupts */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_CFG9, 0x00);
    }

    /* Enable FIFO */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_FD_CFG0, REG_BIT_FIFO_CFG_0_FIFO_WRITE_FD_MSK);
    }

    /* Clear FIFO mapping */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_FIFO_MAP, 0);
    }

    /* Set FIFO level to 16 for interrupt signaling and disable sensor auto gain
     */
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_CFG8, REG_BIT_CFG8_FIFO_TH_MSK);
    }

    return result;
}

err_code_t as7341_get_flicker_data(osal_id_t osal_id, uint8_t *p_flicker_data, uint8_t *p_size)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t status;
    uint8_t fifo_level;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_flicker_data);
    M_CHECK_NULL_POINTER(p_size);

    if ((FIFO_THRESHOLD * sizeof(uint16_t)) > *p_size) {
        return ERR_ARGUMENT;
    }

    /* readout FIFO status */
    result = read_register(osal_id, AS7341_REGADDR_STATUS6, &status);
    if (ERR_SUCCESS == result) {
        /* read FIFO data */
        result = read_register(osal_id, AS7341_REGADDR_FIFO_LVL, &fifo_level);
    }
    if (ERR_SUCCESS == result) {
        if (FIFO_THRESHOLD > fifo_level) {
            /* do nothing, too less data */
            *p_size = 0;
        } else {
            /* byte number of flicker data must be an even number */
            if (*p_size % sizeof(uint16_t)) {
                (*p_size)--;
            }
            /* if FIFO data are less than buffer size, read only FIFO data size */
            if ((fifo_level * sizeof(uint16_t)) < (*p_size)) {
                *p_size = fifo_level * sizeof(uint16_t);
            }
            result = spectral_osal_transfer_data(osal_id, NULL, 0, p_flicker_data, *p_size);
        }
    } else {
        *p_size = 0;
    }

    /* check FIFO status */
    if (ERR_SUCCESS == result) {
        if (REG_BIT_STATUS_6_FD_TRIG_MSK & status) {
            result = ERR_FIFO;
        } else if (REG_BIT_STATUS_6_OVTEMP_MSK & status) {
            result = ERR_OVER_TEMP;
        } else if (REG_BIT_STATUS_6_FIFO_OV_MSK & status) {
            result = ERR_OVERFLOW;
        } else if (FIFO_SIZE_ERROR < fifo_level) {
            result = ERR_OVERFLOW;
        }
    }

    return result;
}

err_code_t as7341_set_ftime(osal_id_t osal_id, uint16_t ftime)
{
    err_code_t result;
    uint8_t reg_val;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(ftime, MAX_FD_TIME);

    result = read_register(osal_id, AS7341_REGADDR_FD_TIME_H, &reg_val);
    if (ERR_SUCCESS == result) {
        reg_val &= ~REG_BIT_FD_TIME_2_FD_TIME_MSK;
        reg_val |= (ftime >> BYTE_SHIFT) & REG_BIT_FD_TIME_2_FD_TIME_MSK;
        result = write_register(osal_id, AS7341_REGADDR_FD_TIME_H, reg_val);
    }
    if (ERR_SUCCESS == result) {
        result = write_register(osal_id, AS7341_REGADDR_FD_TIME_L, ftime & BYTE_MSK);
    }

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].ftime = ftime;
    }

    return result;
}

err_code_t as7341_get_ftime(osal_id_t osal_id, uint16_t *p_ftime)
{
    err_code_t result;
    uint8_t reg_val;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_ftime);

    result = read_register(osal_id, AS7341_REGADDR_FD_TIME_H, &reg_val);
    if (ERR_SUCCESS == result) {
        *p_ftime = (reg_val & REG_BIT_FD_TIME_2_FD_TIME_MSK) << BYTE_SHIFT;
        result = read_register(osal_id, AS7341_REGADDR_FD_TIME_L, &reg_val);
        if (ERR_SUCCESS == result) {
            *p_ftime |= reg_val;
        }
    }

    return result;
}

err_code_t as7341_get_saved_ftime(osal_id_t osal_id, uint16_t *p_ftime)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_ftime);

    *p_ftime = g_device_config[osal_id.dev].ftime;

    return ERR_SUCCESS;
}

err_code_t as7341_set_fifo_integration_time_us(const osal_id_t osal_id, uint32_t time_us)
{
    err_code_t result;
    uint16_t ftime = 0;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (MIN_FTIME_US > time_us || (MAX_FTIME_US < time_us)) {
        return ERR_ARGUMENT;
    }

    ftime = (uint16_t)(
        DIV64_U64(
            (DIV64_U64((uint64_t)time_us * INTEGRATION_TIME_STEP_US_DIVIDER * 10, INTEGRATION_TIME_STEP_US_FACTOR) + 5),
            10) -
        1);

    result = as7341_set_ftime(osal_id, ftime);
    return result;
}

err_code_t as7341_get_fifo_integration_time_us(osal_id_t osal_id, uint32_t *p_time_us)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_time_us);

    *p_time_us = ((((uint32_t)g_device_config[osal_id.dev].ftime + 1) * INTEGRATION_TIME_STEP_US_FACTOR * 10 /
                   INTEGRATION_TIME_STEP_US_DIVIDER) +
                  5) /
                 10;

    return ERR_SUCCESS;
}

err_code_t as7341_get_maximum_fifo_adc(osal_id_t osal_id, uint16_t *p_max_adc)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_max_adc);

    *p_max_adc = g_device_config[osal_id.dev].ftime + 1;

    return ERR_SUCCESS;
}

err_code_t as7341_set_fgain(osal_id_t osal_id, uint8_t fgain)
{
    err_code_t result;
    uint8_t reg_val;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER_EQUAL(fgain, MAX_GAIN_INDEX);

    result = read_register(osal_id, AS7341_REGADDR_FD_TIME_H, &reg_val);
    if (ERR_SUCCESS == result) {
        reg_val &= REG_BIT_FD_TIME_2_FD_TIME_MSK;
        reg_val |= fgain << FD_GAIN_REG_OFFSET;
        result = write_register(osal_id, AS7341_REGADDR_FD_TIME_H, reg_val);
    }

    if (ERR_SUCCESS == result) {
        g_device_config[osal_id.dev].fgain = fgain;
    }

    return result;
}

err_code_t as7341_get_fgain(osal_id_t osal_id, uint8_t *p_fgain)
{
    err_code_t result;
    uint8_t reg_val;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_fgain);

    result = read_register(osal_id, AS7341_REGADDR_FD_TIME_H, &reg_val);
    if (ERR_SUCCESS == result) {
        *p_fgain = reg_val >> FD_GAIN_REG_OFFSET;
    }

    return result;
}

err_code_t as7341_get_saved_fgain(osal_id_t osal_id, uint8_t *p_fgain)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_fgain);

    *p_fgain = g_device_config[osal_id.dev].fgain;

    return ERR_SUCCESS;
}

err_code_t as7341_set_fchannels(osal_id_t osal_id, uint32_t fchannels)
{
    uint8_t smux_value;
    uint32_t i;
    const uint8_t offset = 1; /* jump over register address */
    const uint8_t adc_num = 6;
    uint8_t channel;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER(fchannels, 1 << sizeof(g_fifo_channels));

    memset(g_device_config[osal_id.dev].fsmux_config, 0, SIZE_OF_SMUX_BUFFER);
    g_device_config[osal_id.dev].fchannels = fchannels;

    for (i = 0; i < sizeof(g_fifo_channels); i++) {
        if (0 == ((1 << i) & fchannels)) {
            continue;
        }

        channel = g_fifo_channels[i];
        smux_value = g_device_config[osal_id.dev].fsmux_config[offset + (channel / 2)];

        if ((channel % 2) > 0) {
            smux_value |= adc_num << 4;
        } else {
            smux_value |= adc_num & 0x0F;
        }
        g_device_config[osal_id.dev].fsmux_config[offset + (channel / 2)] = smux_value;
    }

    return ERR_SUCCESS;
}

err_code_t as7341_get_fchannels(osal_id_t osal_id, uint32_t *p_fchannels)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_fchannels);

    *p_fchannels = g_device_config[osal_id.dev].fchannels;

    return ERR_SUCCESS;
}

err_code_t as7341_set_fsmux(osal_id_t osal_id)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    return set_smux_config(osal_id, g_device_config[osal_id.dev].fsmux_config,
                           sizeof(g_device_config[osal_id.dev].fsmux_config));
}

/* USER_CODE END GLOBAL_FUNCTIONS */
