/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#include "as7341_stdinc.h"

#include "as7341_typedefs.h"
#include "chiplib/as7341_configuration.h"
#include "chiplib/as7341_interface.h"
#include "chiplib/as7341_measurement.h"
#include "chiplib/as7341_version.h"
#include "error_codes.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

/* USER_CODE END DEFINITIONS */

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

/* USER_CODE BEGIN GLOBALS */

static uint8_t g_item_sizes[ITEM_ID_MAX] = {
    ITEM_SIZE_RESERVED,     ITEM_SIZE_ASTEP,         ITEM_SIZE_ATIME,         ITEM_SIZE_ITIME,
    ITEM_SIZE_AGAIN,        ITEM_SIZE_MEAS_TYPE,     ITEM_SIZE_BREAK,         ITEM_SIZE_CHANNELS,
    ITEM_SIZE_VERSION,      ITEM_SIZE_SERIAL,        ITEM_SIZE_AUTOZERO,      ITEM_SIZE_MEAS_COUNT,
    ITEM_SIZE_LED_PATTERN,  ITEM_SIZE_LED_WAIT_TIME, ITEM_SIZE_INTERRUPT_PIN, ITEM_SIZE_LED_INTERN,
    ITEM_SIZE_LED_EXT_0,    ITEM_SIZE_LED_EXT_1,     ITEM_SIZE_LED_EXT_2,     ITEM_SIZE_LED_EXT_3,
    ITEM_SIZE_LED_EXT_4,    ITEM_SIZE_LED_EXT_5,     ITEM_SIZE_OUTPUT,        ITEM_SIZE_TEMP_EXT_0,
    ITEM_SIZE_TEMP_EXT_1,   ITEM_SIZE_TEMP_EXT_2,    ITEM_SIZE_TEMP_EXT_3,    ITEM_SIZE_TEMP_EXT_4,
    ITEM_SIZE_TEMP_EXT_5,   ITEM_SIZE_MEASURE_ITEMS, ITEM_SIZE_FGAIN,         ITEM_SIZE_FTIME,
    ITEM_SIZE_FTIME_US,     ITEM_SIZE_FCHANNELS,     ITEM_SIZE_TIMESTAMP,     ITEM_SIZE_AUTO_GAIN_RANGE,
    ITEM_SIZE_GAIN_FACTORS, ITEM_SIZE_SYNC_MODE};

/* USER_CODE END GLOBALS */

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

/* USER_CODE BEGIN LOCAL_FUNCTIONS */

static err_code_t config_func_set_atime(const osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ATIME, size);
    M_UNUSED_PARAM(index);
    return as7341_set_atime(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_get_atime(const osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ATIME, size);
    M_UNUSED_PARAM(index);
    return as7341_get_atime(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_astep(const osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ASTEP, size);
    M_UNUSED_PARAM(index);
    return as7341_set_astep(osal_id, *(uint16_t *)p_data);
}

static err_code_t config_func_get_astep(const osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ASTEP, size);
    M_UNUSED_PARAM(index);
    return as7341_get_astep(osal_id, (uint16_t *)p_data);
}

static err_code_t config_func_set_break_time(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_BREAK, size);
    M_UNUSED_PARAM(index);
    return measure_set_break_time_us(osal_id, *(uint32_t *)p_data);
}

static err_code_t config_func_get_break_time(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_BREAK, size);
    M_UNUSED_PARAM(index);
    return measure_get_break_time_us(osal_id, (uint32_t *)p_data);
}

static err_code_t config_func_set_itime_us(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ITIME, size);
    M_UNUSED_PARAM(index);
    return as7341_set_integration_time_us(osal_id, *(uint32_t *)p_data);
}

static err_code_t config_func_get_itime_us(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ITIME, size);
    M_UNUSED_PARAM(index);
    return as7341_get_integration_time_us(osal_id, (uint32_t *)p_data);
}

static err_code_t config_func_set_meas_type(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEAS_TYPE, size);
    M_UNUSED_PARAM(index);
    return measure_set_measurement_type(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_get_meas_type(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEAS_TYPE, size);
    M_UNUSED_PARAM(index);
    return measure_get_measurement_type(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_again(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AGAIN, size);
    M_UNUSED_PARAM(index);
    return as7341_set_gain(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_get_again(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AGAIN, size);
    M_UNUSED_PARAM(index);
    return as7341_get_saved_gain(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_channels(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_CHANNELS, size);
    M_UNUSED_PARAM(index);
    return as7341_set_channel_config(osal_id, (uint8_t *)p_data, size);
}

static err_code_t config_func_get_channels(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_CHANNELS, size);
    M_UNUSED_PARAM(index);
    return as7341_get_channel_config(osal_id, (uint8_t *)p_data, size);
}

static err_code_t config_func_get_lib_version(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    struct as7341_version *p_version = (struct as7341_version *)p_data;

    M_CHECK_SIZE(ITEM_SIZE_VERSION, size);
    M_UNUSED_PARAM(index);
    M_UNUSED_PARAM(osal_id);

    p_version->major = VER_MAJOR;
    p_version->minor = VER_MINOR;
    p_version->patch = VER_PATCH;
    p_version->build = VER_BUILD;
    return ERR_SUCCESS;
}

static err_code_t config_func_get_serial(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    struct as7341_serial *p_serial = (struct as7341_serial *)p_data;
    M_CHECK_SIZE(ITEM_SIZE_SERIAL, size);
    M_UNUSED_PARAM(index);
    return as7341_get_serial(osal_id, &(p_serial->timestamp), &(p_serial->id));
}

static err_code_t config_func_set_auto_zero(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AUTOZERO, size);
    M_UNUSED_PARAM(index);
    return as7341_set_autozero(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_get_auto_zero(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AUTOZERO, size);
    M_UNUSED_PARAM(index);
    return as7341_get_autozero(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_meas_count(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEAS_COUNT, size);
    M_UNUSED_PARAM(index);
    return measure_set_measurement_count(osal_id, *(uint16_t *)p_data);
}

static err_code_t config_func_get_meas_count(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEAS_COUNT, size);
    M_UNUSED_PARAM(index);
    return measure_get_measurement_count(osal_id, (uint16_t *)p_data);
}

static err_code_t config_func_set_led_wait_time(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_LED_WAIT_TIME, size);
    M_UNUSED_PARAM(index);
    return measure_set_led_wait_time(osal_id, *(uint32_t *)p_data);
}

static err_code_t config_func_get_led_wait_time(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_LED_WAIT_TIME, size);
    M_UNUSED_PARAM(index);
    return measure_get_led_wait_time(osal_id, (uint32_t *)p_data);
}

static err_code_t config_func_set_led_pattern(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_LED_PATTERN, size);
    M_UNUSED_PARAM(index);
    return measure_set_led_pattern(osal_id, (uint16_t *)p_data, size / sizeof(uint16_t));
}

static err_code_t config_func_get_led_pattern(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_LED_PATTERN, size);
    M_UNUSED_PARAM(index);
    return measure_get_led_pattern(osal_id, (uint16_t *)p_data, size / sizeof(uint16_t));
}

static err_code_t config_func_enable_int_pin(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_INTERRUPT_PIN, size);
    M_UNUSED_PARAM(index);
    return measure_enable_interrupt_pin(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_is_int_pin_enabled(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_INTERRUPT_PIN, size);
    M_UNUSED_PARAM(index);
    return measure_is_interrupt_pin_enabled(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_led(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    struct as7341_led_config *p_led_config = (struct as7341_led_config *)p_data;
    M_CHECK_SIZE(ITEM_SIZE_LED_INTERN, size);
    return measure_set_led(osal_id, index, !!(p_led_config->enable), p_led_config->brightness);
}

static err_code_t config_func_get_led(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    struct as7341_led_config *p_led_config = (struct as7341_led_config *)p_data;
    uint8_t enable;
    err_code_t result;

    M_CHECK_SIZE(ITEM_SIZE_LED_INTERN, size);

    p_led_config->enable = 0;
    result = measure_get_led(osal_id, index, &enable, &(p_led_config->brightness));
    if (ERR_SUCCESS == result) {
        p_led_config->enable = (uint16_t)enable;
    }

    return result;
}

static err_code_t config_func_set_output(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    uint16_t brightness = 0;
    M_CHECK_SIZE(ITEM_SIZE_OUTPUT, size);
    M_UNUSED_PARAM(index);
    return measure_set_led(osal_id, LED_ID_OUTPUT, ((uint8_t *)p_data)[0], brightness);
}

static err_code_t config_func_get_output(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    uint16_t brightness = 0;
    M_CHECK_SIZE(ITEM_SIZE_OUTPUT, size);
    M_UNUSED_PARAM(index);
    return measure_get_led(osal_id, LED_ID_OUTPUT, (uint8_t *)p_data, &brightness);
}

static err_code_t config_func_get_temperature(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_TEMP_EXT_0, size);
    return spectral_osal_get_temperature(osal_id, index, (int32_t *)p_data);
}

static err_code_t config_func_set_measure_items(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEASURE_ITEMS, size);
    M_UNUSED_PARAM(index);
    return measure_set_items(osal_id, (uint8_t *)p_data, size);
}

static err_code_t config_func_get_measure_items(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_MEASURE_ITEMS, size);
    M_UNUSED_PARAM(index);
    return measure_get_items(osal_id, (uint8_t *)p_data, size);
}

static err_code_t config_func_set_fgain(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FGAIN, size);
    M_UNUSED_PARAM(index);
    return as7341_set_fgain(osal_id, *(uint8_t *)p_data);
}

static err_code_t config_func_get_fgain(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FGAIN, size);
    M_UNUSED_PARAM(index);
    return as7341_get_saved_fgain(osal_id, (uint8_t *)p_data);
}

static err_code_t config_func_set_ftime(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FTIME, size);
    M_UNUSED_PARAM(index);
    return as7341_set_ftime(osal_id, *((uint16_t *)p_data));
}

static err_code_t config_func_get_ftime(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FTIME, size);
    M_UNUSED_PARAM(index);
    return as7341_get_saved_ftime(osal_id, (uint16_t *)p_data);
}

static err_code_t config_func_set_ftime_us(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ITIME, size);
    M_UNUSED_PARAM(index);
    return as7341_set_fifo_integration_time_us(osal_id, *(uint32_t *)p_data);
}

static err_code_t config_func_get_ftime_us(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_ITIME, size);
    M_UNUSED_PARAM(index);
    return as7341_get_fifo_integration_time_us(osal_id, (uint32_t *)p_data);
}

static err_code_t config_func_set_fchannels(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FCHANNELS, size);
    M_UNUSED_PARAM(index);
    return as7341_set_fchannels(osal_id, *((uint32_t *)p_data));
}

static err_code_t config_func_get_fchannels(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_FCHANNELS, size);
    M_UNUSED_PARAM(index);
    return as7341_get_fchannels(osal_id, (uint32_t *)p_data);
}

static err_code_t config_func_get_timestamp(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    uint32_t *p_timestamp = (uint32_t *)p_data;
    M_CHECK_SIZE(ITEM_SIZE_TIMESTAMP, size);
    M_UNUSED_PARAM(index);
    return measure_get_timestamp(osal_id, p_timestamp, p_timestamp + 1);
}

static err_code_t config_func_set_auto_gain(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AUTO_GAIN_RANGE, size);
    M_UNUSED_PARAM(index);
    return measure_set_auto_gain(osal_id, ((uint8_t *)p_data)[0], ((uint8_t *)p_data)[1]);
}

static err_code_t config_func_get_auto_gain(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_AUTO_GAIN_RANGE, size);
    M_UNUSED_PARAM(index);
    return measure_get_auto_gain(osal_id, (uint8_t *)p_data, (uint8_t *)p_data + 1);
}

static err_code_t config_func_set_gain_factor(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_GAIN_FACTORS, size);
    M_UNUSED_PARAM(index);
    return measure_set_gain_factors(osal_id, (uint16_t *)p_data, size / sizeof(uint16_t));
}

static err_code_t config_func_get_gain_factor(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_GAIN_FACTORS, size);
    M_UNUSED_PARAM(index);
    return measure_get_gain_factors(osal_id, (uint16_t *)p_data, size / sizeof(uint16_t));
}

static err_code_t config_func_set_sync_mode(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_SYNC_MODE, size);
    M_UNUSED_PARAM(index);
    return as7341_set_sync_mode(osal_id, ((uint8_t *)p_data)[0]);
}

static err_code_t config_func_get_sync_mode(osal_id_t osal_id, uint8_t index, void *p_data, uint8_t size)
{
    M_CHECK_SIZE(ITEM_SIZE_SYNC_MODE, size);
    M_UNUSED_PARAM(index);
    return as7341_get_sync_mode(osal_id, (uint8_t *)p_data);
}

/* USER_CODE END LOCAL_FUNCTIONS */

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

/* USER_CODE BEGIN GLOBAL_FUNCTIONS */

/*!
 * \brief Command table
 */
static const struct config_item_entry g_item_table[] = {
    /* COMMAND_ID   |   PAYLOAD_SIZE    |    SET_FUNCTION_POINTER   |   GET_FUNCTION_POINTER */
    {ITEM_ID_ASTEP, ITEM_SIZE_ASTEP, config_func_set_astep, config_func_get_astep, NO_INDEX_USED},
    {ITEM_ID_ATIME, ITEM_SIZE_ATIME, config_func_set_atime, config_func_get_atime, NO_INDEX_USED},
    {ITEM_ID_BREAK, ITEM_SIZE_BREAK, config_func_set_break_time, config_func_get_break_time, NO_INDEX_USED},
    {ITEM_ID_ITIME, ITEM_SIZE_ITIME, config_func_set_itime_us, config_func_get_itime_us, NO_INDEX_USED},
    {ITEM_ID_MEAS_TYPE, ITEM_SIZE_MEAS_TYPE, config_func_set_meas_type, config_func_get_meas_type, NO_INDEX_USED},
    {ITEM_ID_AGAIN, ITEM_SIZE_AGAIN, config_func_set_again, config_func_get_again, NO_INDEX_USED},
    {ITEM_ID_CHANNELS, ITEM_SIZE_CHANNELS, config_func_set_channels, config_func_get_channels, NO_INDEX_USED},
    {ITEM_ID_VERSION, ITEM_SIZE_VERSION, NULL, config_func_get_lib_version, NO_INDEX_USED},
    {ITEM_ID_SERIAL, ITEM_SIZE_SERIAL, NULL, config_func_get_serial, NO_INDEX_USED},
    {ITEM_ID_AUTOZERO, ITEM_SIZE_AUTOZERO, config_func_set_auto_zero, config_func_get_auto_zero, NO_INDEX_USED},
    {ITEM_ID_MEAS_COUNT, ITEM_SIZE_MEAS_COUNT, config_func_set_meas_count, config_func_get_meas_count, NO_INDEX_USED},
    {ITEM_ID_LED_PATTERN, ITEM_SIZE_LED_PATTERN, config_func_set_led_pattern, config_func_get_led_pattern,
     NO_INDEX_USED},
    {ITEM_ID_LED_WAIT_TIME, ITEM_SIZE_LED_WAIT_TIME, config_func_set_led_wait_time, config_func_get_led_wait_time,
     NO_INDEX_USED},
    {ITEM_ID_INTERRUPT_PIN, ITEM_SIZE_INTERRUPT_PIN, config_func_enable_int_pin, config_func_is_int_pin_enabled,
     NO_INDEX_USED},
    {ITEM_ID_LED_INTERN, ITEM_SIZE_LED_INTERN, config_func_set_led, config_func_get_led, LED_ID_INTERN},
    {ITEM_ID_LED_EXT_0, ITEM_SIZE_LED_EXT_0, config_func_set_led, config_func_get_led, LED_ID_EXT_0},
    {ITEM_ID_LED_EXT_1, ITEM_SIZE_LED_EXT_1, config_func_set_led, config_func_get_led, LED_ID_EXT_1},
    {ITEM_ID_LED_EXT_2, ITEM_SIZE_LED_EXT_2, config_func_set_led, config_func_get_led, LED_ID_EXT_2},
    {ITEM_ID_LED_EXT_3, ITEM_SIZE_LED_EXT_3, config_func_set_led, config_func_get_led, LED_ID_EXT_3},
    {ITEM_ID_LED_EXT_4, ITEM_SIZE_LED_EXT_4, config_func_set_led, config_func_get_led, LED_ID_EXT_4},
    {ITEM_ID_LED_EXT_5, ITEM_SIZE_LED_EXT_5, config_func_set_led, config_func_get_led, LED_ID_EXT_5},
    {ITEM_ID_OUTPUT, ITEM_SIZE_OUTPUT, config_func_set_output, config_func_get_output, NO_INDEX_USED},
    {ITEM_ID_TEMP_EXT_0, ITEM_SIZE_TEMP_EXT_0, NULL, config_func_get_temperature, 0},
    {ITEM_ID_TEMP_EXT_1, ITEM_SIZE_TEMP_EXT_1, NULL, config_func_get_temperature, 1},
    {ITEM_ID_TEMP_EXT_2, ITEM_SIZE_TEMP_EXT_2, NULL, config_func_get_temperature, 2},
    {ITEM_ID_TEMP_EXT_3, ITEM_SIZE_TEMP_EXT_3, NULL, config_func_get_temperature, 3},
    {ITEM_ID_TEMP_EXT_4, ITEM_SIZE_TEMP_EXT_4, NULL, config_func_get_temperature, 4},
    {ITEM_ID_TEMP_EXT_5, ITEM_SIZE_TEMP_EXT_5, NULL, config_func_get_temperature, 5},
    {ITEM_ID_MEASURE_ITEMS, ITEM_SIZE_MEASURE_ITEMS, config_func_set_measure_items, config_func_get_measure_items,
     NO_INDEX_USED},
    {ITEM_ID_FGAIN, ITEM_SIZE_FGAIN, config_func_set_fgain, config_func_get_fgain, NO_INDEX_USED},
    {ITEM_ID_FTIME, ITEM_SIZE_FTIME, config_func_set_ftime, config_func_get_ftime, NO_INDEX_USED},
    {ITEM_ID_FTIME_US, ITEM_SIZE_FTIME_US, config_func_set_ftime_us, config_func_get_ftime_us, NO_INDEX_USED},
    {ITEM_ID_FCHANNELS, ITEM_SIZE_FCHANNELS, config_func_set_fchannels, config_func_get_fchannels, NO_INDEX_USED},
    {ITEM_ID_TIMESTAMP, ITEM_SIZE_TIMESTAMP, NULL, config_func_get_timestamp, NO_INDEX_USED},
    {ITEM_ID_AUTO_GAIN_RANGE, ITEM_SIZE_AUTO_GAIN_RANGE, config_func_set_auto_gain, config_func_get_auto_gain,
     NO_INDEX_USED},
    {ITEM_ID_GAIN_FACTORS, ITEM_SIZE_GAIN_FACTORS, config_func_set_gain_factor, config_func_get_gain_factor,
     NO_INDEX_USED},
    {ITEM_ID_SYNC_MODE, ITEM_SIZE_SYNC_MODE, config_func_set_sync_mode, config_func_get_sync_mode, NO_INDEX_USED}};

err_code_t config_initialize(osal_id_t osal_id)
{
    return as7341_open(osal_id);
}

err_code_t config_shutdown(osal_id_t osal_id)
{
    return as7341_close(osal_id);
}

err_code_t config_get_item_table(osal_id_t osal_id, struct config_item_entry **pp_item_table,
                                 uint32_t *p_num_of_entries)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(pp_item_table);
    M_CHECK_NULL_POINTER(p_num_of_entries);

    *pp_item_table = (struct config_item_entry *)g_item_table;
    *p_num_of_entries = sizeof(g_item_table) / sizeof(struct config_item_entry);

    return ERR_SUCCESS;
}

err_code_t config_get_item_size(osal_id_t osal_id, uint8_t item_id, uint8_t *p_item_size)
{
    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_item_size);
    M_CHECK_ARGUMENT_LOWER(item_id, ITEM_ID_MAX);

    *p_item_size = g_item_sizes[item_id];
    return ERR_SUCCESS;
}

/* USER_CODE END GLOBAL_FUNCTIONS */
