/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "board_1to1.h"
#include "error_codes.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#define PORT_EXPANDER_I2C_ADDRESS 0x41
#define I2C_MUX_ADDRESS 0x70
#define TEMP_SENSOR_ADDRESS 0x48

#define NOT_SUPPORTED 0xFF
#define MAX_TEMP_SENSORS 4

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static uint8_t g_io_expander_output = NOT_SUPPORTED;
static uint8_t g_temperature_sensors_available = 0;
i2c_transfer_callback gp_i2c_transfer = NULL;
void *gp_callback_param = NULL;

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

err_code_t switch_i2c_multiplexer(uint8_t configuration)
{
    uint8_t send_data[1];
    err_code_t result = ERR_SUCCESS;

    if (NULL == gp_i2c_transfer) {
        return ERR_ACCESS;
    }

    if (configuration > 7) {
        return ERR_ARGUMENT;
    }

    send_data[0] = 0x04 | configuration;
    if (ERR_SUCCESS != gp_i2c_transfer(gp_callback_param, I2C_MUX_ADDRESS, send_data, sizeof(send_data), NULL, 0)) {
        result = ERR_DATA_TRANSFER;
    }

    return result;
}

err_code_t get_internal_temperature(uint8_t id, int32_t *p_millidegree)
{
    uint8_t send_data[1];
    uint8_t recv_data[2];
    err_code_t result = ERR_SUCCESS;
    int16_t temperature;

    M_CHECK_NULL_POINTER(p_millidegree);

    if (NULL == gp_i2c_transfer) {
        return ERR_ACCESS;
    }

    if (1 < id) {
        return ERR_ARGUMENT;
    }

    send_data[0] = 0x00;
    if (ERR_SUCCESS != gp_i2c_transfer(gp_callback_param, TEMP_SENSOR_ADDRESS + id, send_data, sizeof(send_data),
                                       recv_data, sizeof(recv_data))) {
        result = ERR_DATA_TRANSFER;
    }

    if (ERR_SUCCESS == result) {
        temperature = (int16_t)((recv_data[0] << 4) | (recv_data[1] >> 4));
        if ((temperature & 0x0800) == 0x0800) {
            temperature--;
            temperature = (short)((~(int)temperature) & 0x0FFF);
            *p_millidegree = 0 - ((uint32_t)temperature * 625 / 10);
        } else {
            *p_millidegree = (int32_t)temperature * 625 / 10;
        }
    }
    return result;
}

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

err_code_t bon_initialize(i2c_transfer_callback p_i2c_transfer, void *p_callback_param)
{
    uint8_t send_data[2];
    uint8_t i;
    int32_t temperature;

    if (NULL == p_i2c_transfer) {
        return ERR_POINTER;
    }

    gp_i2c_transfer = p_i2c_transfer;
    gp_callback_param = p_callback_param;

    /* ********************** */
    /* Initialize io expander */

    /* Set ouputs to zero */
    g_io_expander_output = NOT_SUPPORTED;
    send_data[0] = 1;
    send_data[1] = 0;
    if (ERR_SUCCESS ==
        gp_i2c_transfer(gp_callback_param, PORT_EXPANDER_I2C_ADDRESS, send_data, sizeof(send_data), NULL, 0)) {
        /* Set direction to outputs */
        send_data[0] = 3;
        send_data[1] = 0;
        if (ERR_SUCCESS ==
            gp_i2c_transfer(gp_callback_param, PORT_EXPANDER_I2C_ADDRESS, send_data, sizeof(send_data), NULL, 0)) {
            g_io_expander_output = 0;
        }
    }

    /* ****************************** */
    /* Initialize temperature sensors */
    g_temperature_sensors_available = 0x0F;

    for (i = 0; i < MAX_TEMP_SENSORS; i++) {
        if (ERR_SUCCESS != bon_get_temperature(i, &temperature)) {
            g_temperature_sensors_available &= ~(1 << i);
        }
    }

    return ERR_SUCCESS;
}

err_code_t bon_get_temperature(uint8_t id, int32_t *p_millidegree)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t internal_id;

    M_CHECK_NULL_POINTER(p_millidegree);

    if (NULL == gp_i2c_transfer) {
        return ERR_ACCESS;
    }

    switch (id) {
    case ID_TOP:
        internal_id = 3;
        break;
    case ID_BOT:
        internal_id = 1;
        break;
    case ID_LEFT:
        internal_id = 2;
        break;
    case ID_EXT:
        internal_id = 0;
        break;
    default:
        return ERR_ARGUMENT;
    }

    if (g_temperature_sensors_available & (1 << internal_id)) {
        result = switch_i2c_multiplexer(internal_id > 1);
        if (ERR_SUCCESS == result) {
            result = get_internal_temperature(internal_id % 2, p_millidegree);
        }
        if (ERR_SUCCESS == result) {
            result = switch_i2c_multiplexer(2);
        }
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}

err_code_t bon_set_led(uint8_t id, uint8_t enable)
{
    err_code_t result = ERR_SUCCESS;
    uint8_t send_data[2];

    if (NULL == gp_i2c_transfer) {
        return ERR_ACCESS;
    }

    if (NOT_SUPPORTED != g_io_expander_output) {
        switch (id) {
        case ID_LEFT:
            if (enable) {
                g_io_expander_output |= 0x08;
            } else {
                g_io_expander_output &= ~0x08;
            }
            break;
        case ID_TOP:
            if (enable) {
                g_io_expander_output |= 0x02;
            } else {
                g_io_expander_output &= ~0x02;
            }
            break;
        case ID_BOT:
            if (enable) {
                g_io_expander_output |= 0x04;
            } else {
                g_io_expander_output &= ~0x04;
            }
            break;
        case ID_EXT:
            if (enable) {
                g_io_expander_output |= 0x01;
            } else {
                g_io_expander_output &= ~0x01;
            }
            break;
        default:
            result = ERR_ARGUMENT;
        }

        if (ERR_SUCCESS == result) {
            send_data[0] = 1;
            send_data[1] = g_io_expander_output;
            if (0 !=
                gp_i2c_transfer(gp_callback_param, PORT_EXPANDER_I2C_ADDRESS, send_data, sizeof(send_data), NULL, 0)) {
                result = ERR_DATA_TRANSFER;
            }
        }
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}
