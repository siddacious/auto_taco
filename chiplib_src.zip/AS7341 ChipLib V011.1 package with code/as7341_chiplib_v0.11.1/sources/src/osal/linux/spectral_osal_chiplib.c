/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "error_codes.h"
#include "osal/board_1to1.h"
#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#define TIMER_COUNT 8
#define LED_COUNT 3
#define TEMP_SENSOR_COUNT 2
#define TIME_US 1000000
#define HALF_DATA 2

#define MAX_BRIGHTNESS 1000

#define OSAL_MODULE_NAME "OSAL"

#define PIPE_READ_TMO_US 1
#define PIPE_READ_FD 0
#define PIPE_WRITE_FD 1

/*!
 * \brief Structure holds necessary hardware information of the connected sensor
 *
 * The global object g_device_config stores the necessary sensor hardware
 * information and shall be fullfilled by the implementer of the spectral osal
 * layer. This implementation of OSAL expects that the target system is
 * configured in a proper way. So, sensor shall be connected to the I2C
 * bus number and device address. Furthermore, the configured GPIO must
 * be known by the system and exported to the sysfs filesystem.
 * The implementation expects the configured GPIO at the sysfs path
 * /sys/class/gpio/gpio<GPIO_NR>.
 *
 * \note The following members shall be configured by the implementer:
 * - i2c_bus
 * - i2c_address
 * - gpio
 */
struct device_config {
    const int i2c_bus;                 /*!< number of the I2C bus the sensor is connected to */
    const int i2c_address;             /*!< I2C device address of the sensor */
    const int gpio;                    /*!< the gpio number for the INT line of the sensor */
    int i2c_fd;                        /*!< used internally to hold the file descriptor to an opened sensor */
    int gpio_fd;                       /*!< used internally to hold the file descriptor to an opened gpio*/
    int msgPipe[2];                    /*!< used internally to cancel a blocking read*/
    struct timeval timer[TIMER_COUNT]; /*!< used internally to support timer functionality*/
    uint8_t old_interrupt_state; /*!< used internally to ensure pending interrupt behavior (shall be initialized to 1*/
    osal_id_t osal_id;
};

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static struct device_config g_device_config[NUM_SUPPORTED_DEVICES] = {
    {
        .i2c_bus = 1,
        .i2c_address = 0x39,
        .gpio = 22,
        .i2c_fd = -1,
        .gpio_fd = -1,
        .msgPipe = {0},
        .timer = {{0}},
        .old_interrupt_state = 1,
        .osal_id = {0},
    },
};

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

static err_code_t as7341_open(osal_id_t osal_id)
{
    const int i2c_bus = g_device_config[osal_id.dev].i2c_bus;
    err_code_t result = ERR_SUCCESS;
    char filename[64];

    if (g_device_config[osal_id.dev].i2c_fd > 0) {
        result = ERR_ACCESS;
    } else {

        sprintf(filename, "/dev/i2c/%d", i2c_bus);
        g_device_config[osal_id.dev].i2c_fd = open(filename, O_RDWR);

        if (g_device_config[osal_id.dev].i2c_fd < 0 && (errno == ENOENT || errno == ENOTDIR)) {
            sprintf(filename, "/dev/i2c-%d", i2c_bus);
            g_device_config[osal_id.dev].i2c_fd = open(filename, O_RDWR);
        }

        if (g_device_config[osal_id.dev].i2c_fd < 0) {
            log_fatal(osal_id, OSAL_MODULE_NAME, "Error: Could not open file '%s': %s\n", filename, strerror(errno));
            if (errno == EACCES) {
                log_fatal(osal_id, OSAL_MODULE_NAME, "Run as root?\n");
            }
            result = ERR_COM_INTERFACE;
        }
    }

    if (g_device_config[osal_id.dev].gpio >= 0) {
        if (g_device_config[osal_id.dev].gpio_fd > 0) {
            result = ERR_ACCESS;
        } else {
            sprintf(filename, "/sys/class/gpio/gpio%d/value", g_device_config[osal_id.dev].gpio);
            g_device_config[osal_id.dev].gpio_fd = open(filename, O_RDONLY);

            if (g_device_config[osal_id.dev].gpio_fd < 0) {
                log_fatal(osal_id, OSAL_MODULE_NAME, "Error: Could not open file '%s': %s\n", filename,
                          strerror(errno));
                if (errno == EACCES) {
                    log_fatal(osal_id, OSAL_MODULE_NAME, "Run as root?\n");
                }
                result = ERR_COM_INTERFACE;
            }
        }
    }

    return result;
}

static err_code_t as7341_close(osal_id_t osal_id)
{
    if (g_device_config[osal_id.dev].i2c_fd) {
        close(g_device_config[osal_id.dev].i2c_fd);
        g_device_config[osal_id.dev].i2c_fd = -1;
    }

    if (g_device_config[osal_id.dev].gpio_fd) {
        close(g_device_config[osal_id.dev].gpio_fd);
        g_device_config[osal_id.dev].gpio_fd = -1;
    }

    return ERR_SUCCESS;
}

static err_code_t as7341_read_irq(osal_id_t osal_id, uint8_t *pIrqState)
{
    char value[2];
    ssize_t bytes = 0;
    err_code_t result = ERR_SUCCESS;

    if (g_device_config[osal_id.dev].gpio_fd > 0) {

        bytes = pread(g_device_config[osal_id.dev].gpio_fd, &value, sizeof(value), 0);
        if (bytes < 0) {
            result = ERR_INTERRUPT;
        }

        sscanf(value, "%hhu", pIrqState);
    } else {
        *pIrqState = 1;
    }

    return result;
}

static err_code_t check_interrupt_pin(osal_id_t osal_id)
{
    uint8_t interrupt;
    err_code_t result = ERR_SUCCESS;

    result = as7341_read_irq(osal_id, &interrupt);
    if (ERR_SUCCESS != result) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error code while reading interrupt pin status: %d", result);
        result = ERR_INTERRUPT;
    } else {
        if ((0 == interrupt) && (1 == g_device_config[osal_id.dev].old_interrupt_state)) {
            result = spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
        }
        g_device_config[osal_id.dev].old_interrupt_state = interrupt;
    }

    return result;
}

static err_code_t check_timer(osal_id_t osal_id)
{
    uint8_t i;
    struct timeval actual_time;
    err_code_t result = ERR_SUCCESS;

    if (gettimeofday(&actual_time, NULL) != 0) {
        result = ERR_TIMER_ACCESS;
    } else {
        for (i = 0; (ERR_SUCCESS == result) && (i < TIMER_COUNT); i++) {
            if (timerisset(&(g_device_config[osal_id.dev].timer[i]))) {
                if (0 > (float)(g_device_config[osal_id.dev].timer[i].tv_sec - actual_time.tv_sec) * 1000.0f +
                            (float)(g_device_config[osal_id.dev].timer[i].tv_usec - actual_time.tv_usec) / 1000.0f) {
                    log_debug(osal_id, OSAL_MODULE_NAME, "Expire timer: %d: %dus", i,
                              g_device_config[osal_id.dev].timer[i].tv_usec);
                    result = spectral_osal_set_event(osal_id, EVENT_TIMER_MEASUREMENT + i, 0);
                    timerclear(&(g_device_config[osal_id.dev].timer[i]));
                }
            }
        }
    }
    return result;
}

static err_code_t linux_i2c_transfer(struct device_config *p_device_config, uint8_t dev_addr, uint8_t *p_send_data,
                                     uint8_t send_len, uint8_t *p_recv_data, uint8_t recv_len)
{
    int sysErr;
    int fd;
    struct i2c_msg as7341_msg[2];
    struct i2c_rdwr_ioctl_data ioctlData = {as7341_msg, 1};
    err_code_t result = ERR_SUCCESS;

    M_CHECK_NULL_POINTER(p_device_config);
    fd = p_device_config->i2c_fd;
    ioctlData.nmsgs = 0;

    if (fd < 0) {
        result = ERR_ACCESS;
    } else {
        if (send_len > 0) {
            as7341_msg[ioctlData.nmsgs].addr = dev_addr;
            as7341_msg[ioctlData.nmsgs].buf = p_send_data;
            as7341_msg[ioctlData.nmsgs].flags = 0;
            as7341_msg[ioctlData.nmsgs++].len = send_len;
        }

        if (recv_len > 0) {
            as7341_msg[ioctlData.nmsgs].addr = dev_addr;
            as7341_msg[ioctlData.nmsgs].buf = p_recv_data;
            as7341_msg[ioctlData.nmsgs].flags = I2C_M_RD;
            as7341_msg[ioctlData.nmsgs++].len = recv_len;
        }

        sysErr = ioctl(fd, I2C_RDWR, &ioctlData);
        if (sysErr < 0) {
            sysErr = errno;
            log_fatal(p_device_config->osal_id, OSAL_MODULE_NAME,
                      "Error (%d) during I2C transfer. %s. Data to receive: %d", sysErr, strerror(sysErr), recv_len);
            result = ERR_DATA_TRANSFER;
        }
    }

    return result;
}

static err_code_t i2c_transfer(void *p_param, uint8_t dev_addr, uint8_t *p_send_data, uint8_t send_len,
                               uint8_t *p_recv_data, uint8_t recv_len)
{
    struct device_config *p_device_config = (struct device_config *)p_param;
    return linux_i2c_transfer(p_device_config, dev_addr, p_send_data, send_len, p_recv_data, recv_len);
}

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/
err_code_t spectral_osal_transfer_data(osal_id_t osal_id, uint8_t *p_send_data, uint8_t send_data_size,
                                       uint8_t *p_receive_data, uint8_t receive_data_size)
{
    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);
    return linux_i2c_transfer(&g_device_config[osal_id.dev], g_device_config[osal_id.dev].i2c_address, p_send_data,
                              send_data_size, p_receive_data, receive_data_size);
}

err_code_t spectral_osal_set_event(osal_id_t osal_id, uint16_t event, uint16_t payload)
{
    ssize_t bytes;
    err_code_t result = ERR_SUCCESS;
    uint32_t item = payload << 16 | event;

    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (g_device_config[osal_id.dev].msgPipe[PIPE_WRITE_FD] > 0) {
        bytes = write(g_device_config[osal_id.dev].msgPipe[PIPE_WRITE_FD], &item, sizeof(item));
        if (bytes < 0) {
            log_fatal(osal_id, OSAL_MODULE_NAME, "Writing to FIFO failed! (%d - )", bytes, strerror(errno));
            result = ERR_FIFO;
        }
    } else {
        result = ERR_FIFO;
    }

    return result;
}

err_code_t spectral_osal_wait_for_event(osal_id_t osal_id, uint16_t *p_event, uint16_t *p_payload)
{
    int nfds, err;
    fd_set set;
    uint32_t item;
    struct timeval tmo = {0};
    err_code_t result = ERR_SUCCESS;

    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_event);
    M_CHECK_NULL_POINTER(p_payload);
    *p_event = EVENT_NONE;

    result = check_interrupt_pin(osal_id);
    if (ERR_SUCCESS == result) {
        result = check_timer(osal_id);
    }

    if (ERR_SUCCESS == result) {
        FD_ZERO(&set);
        FD_SET(g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD], &set);
        nfds = g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD] + 1;
        tmo.tv_usec = PIPE_READ_TMO_US;
        err = select(nfds, &set, NULL, NULL, &tmo);
        if (err == -1) {
            log_fatal(osal_id, OSAL_MODULE_NAME, "Waiting for FIFO data failed! (%d - )", result, strerror(errno));
            result = ERR_FIFO;
        } else if (err > 0) {
            if (FD_ISSET(g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD], &set)) {
                err = read(g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD], &item, sizeof(item));
                if (err == -1) {
                    log_fatal(osal_id, OSAL_MODULE_NAME, "Reading from FIFO failed! (%d - )", result, strerror(errno));
                    result = ERR_FIFO;
                } else {
                    *p_event = item & 0xFFFF;
                    *p_payload = item >> 16;
                    result = ERR_SUCCESS;
                }
            }
        } else {
            // no need to handle timeout
            result = ERR_SUCCESS;
        }
    }
    return result;
}

err_code_t spectral_osal_check_pending_interrupt(osal_id_t osal_id)
{
    uint8_t interrupt;
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);

    result = as7341_read_irq(osal_id, &interrupt);
    if (ERR_SUCCESS != result) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error while reading interrupt pin status: %d", result);
        result = ERR_INTERRUPT;
    } else {
        if (0 == interrupt) {
            result = spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
        } else {
            result = ERR_SUCCESS;
        }
        g_device_config[osal_id.dev].old_interrupt_state = interrupt;
    }

    return result;
}

err_code_t spectral_osal_configure_timer(osal_id_t osal_id, uint8_t timer_id, uint32_t timer_us)
{
    uint32_t us = timer_us % TIME_US;
    uint32_t s = timer_us / TIME_US;

    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (TIMER_COUNT <= timer_id) {
        return ERR_ARGUMENT;
    }

    gettimeofday(&(g_device_config[osal_id.dev].timer[timer_id]), 0);
    log_debug(osal_id, OSAL_MODULE_NAME, "Set timer: %d: %dus (%dus)", timer_id, timer_us,
              g_device_config[osal_id.dev].timer[timer_id].tv_usec);
    if ((g_device_config[osal_id.dev].timer[timer_id].tv_usec + us) > TIME_US) {
        s++;
    }
    g_device_config[osal_id.dev].timer[timer_id].tv_usec =
        (g_device_config[osal_id.dev].timer[timer_id].tv_usec + us) % TIME_US;
    g_device_config[osal_id.dev].timer[timer_id].tv_sec += s;
    return ERR_SUCCESS;
}

err_code_t spectral_osal_set_led(osal_id_t osal_id, uint8_t led_id, uint16_t brightness)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (0 == led_id) {
        result = ERR_NOT_SUPPORTED;
    } else if (5 > led_id) {
        result = bon_set_led(led_id - 1, 0 != brightness);
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}

err_code_t spectral_osal_get_temperature(osal_id_t osal_id, uint8_t temp_id, int32_t *p_temperature)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_temperature);

    if (0 == temp_id) {
        result = ERR_NOT_SUPPORTED;
    } else if (5 > temp_id) {
        result = bon_get_temperature(temp_id - 1, p_temperature);
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}

err_code_t spectral_osal_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us_l, uint32_t *p_timestamp_us_h)
{
    struct timeval time;
    uint64_t timestamp;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_timestamp_us_l);
    M_CHECK_NULL_POINTER(p_timestamp_us_h);

    gettimeofday(&time, 0);
    timestamp = (time.tv_sec * 1000000) + time.tv_usec;

    *p_timestamp_us_l = timestamp & 0xFFFFFFFF;
    *p_timestamp_us_h = timestamp >> 32;

    return ERR_SUCCESS;
}

err_code_t spectral_osal_initialize(const osal_id_t osal_id, const char *p_interface_desc)
{
    int sysErr;
    err_code_t result = ERR_SUCCESS;

    M_UNUSED_PARAM(p_interface_desc);
    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);

    g_device_config[osal_id.dev].old_interrupt_state = 1;

    sysErr = pipe(g_device_config[osal_id.dev].msgPipe);
    if (sysErr < 0) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Creating FIFO failed (%d - %s)", sysErr, strerror(errno));
        result = ERR_SYSTEM_CONFIG;
    }

    if (ERR_SUCCESS == result) {
        sysErr = fcntl(g_device_config[osal_id.dev].msgPipe[PIPE_WRITE_FD], F_SETFL, O_NONBLOCK);
        if (sysErr < 0) {
            log_fatal(osal_id, OSAL_MODULE_NAME, "Controlling FIFO failed (%d - %s)", sysErr, strerror(errno));
            result = ERR_SYSTEM_CONFIG;
        }
    }

    if (ERR_SUCCESS == result) {
        result = as7341_open(osal_id);
    }

    g_device_config[osal_id.dev].osal_id = osal_id;

    /* try to initialize external temperature sensors and IO expander for LED selection */
    bon_initialize(i2c_transfer, &g_device_config[osal_id.dev]);

    return result;
}

err_code_t spectral_osal_shutdown(osal_id_t osal_id)
{
    err_code_t result = ERR_SUCCESS;
    M_CHECK_ARGUMENT_LOWER_EQUAL(osal_id.dev, NUM_SUPPORTED_DEVICES);

    g_device_config[osal_id.dev].old_interrupt_state = 1;

    if (g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD]) {
        close(g_device_config[osal_id.dev].msgPipe[PIPE_READ_FD]);
    }

    if (g_device_config[osal_id.dev].msgPipe[PIPE_WRITE_FD]) {
        close(g_device_config[osal_id.dev].msgPipe[PIPE_WRITE_FD]);
    }

    result = as7341_close(osal_id);
    return result;
}

void spectral_osal_logging(osal_id_t osal_id, uint8_t level, const char *module_name, const char *fmt, ...)
{
    static const char *level_names[] = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"};
    uint8_t log_level_index;

    enum { LOG_TRACE = 0, LOG_DEBUG = 20, LOG_INFO = 40, LOG_WARN = 60, LOG_ERROR = 80, LOG_FATAL = 100 };

    /* Get current time */
    struct timeval tv;
    time_t t = time(NULL);
    struct tm *lt = localtime(&t);
    long milliseconds;
    va_list args;
    char buf[32];

    if ((LOG_DEBUG - 10) > level) {
        log_level_index = 0;
    } else if ((LOG_INFO - 10) > level) {
        log_level_index = 1;
    } else if ((LOG_WARN - 10) > level) {
        log_level_index = 2;
    } else if ((LOG_ERROR - 10) > level) {
        log_level_index = 3;
    } else if ((LOG_FATAL - 10) > level) {
        log_level_index = 4;
    } else {
        log_level_index = 5;
    }

    gettimeofday(&tv, NULL);
    milliseconds = tv.tv_usec / 1000;

    /* Log to stderr */
    buf[strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)] = '\0';
    fprintf(stderr, "[%s:%03ld] %-5s <%s%d>: ", buf, milliseconds, level_names[log_level_index], module_name,
            osal_id.dev);
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n");
    fflush(stderr);
}
