/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#include "error_codes.h"
#include "fifo.h"
#include "osal/board_1to1.h"
#include "osal/ftdi/ftdi_i2c.h"
#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#define TIMER_COUNT 8
#define LED_COUNT 3
#define TEMP_SENSOR_COUNT 2
#define TIME_US 1000000
#define HALF_DATA 2

#define MAX_BRIGHTNESS 1000

#define OSAL_MODULE_NAME "OSAL"

#define FIFO_SIZE 40
#define REMOTE_KEY_WORD "FTDI:"

struct device_config {
    FT_HANDLE p_devHandle;
    struct timeval timer[TIMER_COUNT];
    fifo_t fifo;
    uint32_t fifo_buffer[FIFO_SIZE + 1];
    uint8_t old_interrupt_state;
};

/******************************************************************************
 *                                  GLOBALS                                   *
 ******************************************************************************/

static const uint8_t g_i2c_address = 0x39;

static struct device_config g_device_config[NUM_SUPPORTED_DEVICES] = {{0}};

/******************************************************************************
 *                               LOCAL FUNCTIONS                              *
 ******************************************************************************/

static err_code_t check_interrupt_pin(osal_id_t osal_id)
{
    int8_t status;
    err_code_t result = ERR_SUCCESS;
    uint8_t interrupt;

    status = ftdiReadInterruptPin(g_device_config[osal_id.dev].p_devHandle, &interrupt);
    if (FT_OK != status) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error code while reading interrupt pin status: %d", status);
        result = ERR_INTERRUPT;
    } else {
        if ((0 == interrupt) && (1 == g_device_config[osal_id.dev].old_interrupt_state)) {
            result = spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
        }
        g_device_config[osal_id.dev].old_interrupt_state = interrupt;
    }

    return result;
}

static err_code_t check_timer(osal_id_t osal_id)
{
    uint8_t i;
    struct timeval actual_time;
    err_code_t result = ERR_SUCCESS;

    gettimeofday(&actual_time, NULL);

    for (i = 0; (ERR_SUCCESS == result) && (i < TIMER_COUNT); i++) {
        if (timerisset(&(g_device_config[osal_id.dev].timer[i]))) {
            if (0 > (float)(g_device_config[osal_id.dev].timer[i].tv_sec - actual_time.tv_sec) * 1000.0f +
                        (float)(g_device_config[osal_id.dev].timer[i].tv_usec - actual_time.tv_usec) / 1000.0f) {
                log_debug(osal_id, OSAL_MODULE_NAME, "Expire timer: %d: %dus", i,
                          g_device_config[osal_id.dev].timer[i].tv_usec);
                result = spectral_osal_set_event(osal_id, EVENT_TIMER_MEASUREMENT + i, 0);
                timerclear(&(g_device_config[osal_id.dev].timer[i]));
            }
        }
    }

    return result;
}

static err_code_t i2c_transfer(void *p_param, uint8_t dev_addr, uint8_t *p_send_data, uint8_t send_len,
                               uint8_t *p_recv_data, uint8_t recv_len)
{
    int8_t status;
    struct device_config *p_device_config = (struct device_config *)p_param;

    status = ftdiTransferData(p_device_config->p_devHandle, dev_addr, p_send_data, send_len, p_recv_data, recv_len);
    if (FT_OK != status) {
        return ERR_DATA_TRANSFER;
    }
    return ERR_SUCCESS;
}

/******************************************************************************
 *                             GLOBAL FUNCTIONS                               *
 ******************************************************************************/

err_code_t spectral_osal_transfer_data(osal_id_t osal_id, uint8_t *p_send_data, uint8_t send_data_size,
                                       uint8_t *p_receive_data, uint8_t receive_data_size)
{
    int8_t status;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    status = ftdiTransferData(g_device_config[osal_id.dev].p_devHandle, g_i2c_address, p_send_data, send_data_size,
                              p_receive_data, receive_data_size);
    if (FT_OK != status) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error while transferring data: %d", status);
        return ERR_DATA_TRANSFER;
    }
    return ERR_SUCCESS;
}

err_code_t spectral_osal_set_event(osal_id_t osal_id, uint16_t event, uint16_t payload)
{
    uint32_t item = payload << 16 | event;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (0 != FIFO_Put(&(g_device_config[osal_id.dev].fifo), (void *)&item)) {
        return ERR_EVENT;
    }
    return ERR_SUCCESS;
}

err_code_t spectral_osal_wait_for_event(osal_id_t osal_id, uint16_t *p_event, uint16_t *p_payload)
{
    err_code_t result;
    uint32_t item;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_event);
    M_CHECK_NULL_POINTER(p_payload);

    result = check_interrupt_pin(osal_id);

    if (ERR_SUCCESS == result) {
        result = check_timer(osal_id);
    }

    if (ERR_SUCCESS == result) {
        if (0 != FIFO_Get(&(g_device_config[osal_id.dev].fifo), (void *)&item)) {
            *p_event = EVENT_NONE;
        } else {
            *p_event = item & 0xFFFF;
            *p_payload = item >> 16;
        }
    }
    return ERR_SUCCESS;
}

err_code_t spectral_osal_check_pending_interrupt(osal_id_t osal_id)
{
    int8_t status;
    uint8_t interrupt;
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    status = ftdiReadInterruptPin(g_device_config[osal_id.dev].p_devHandle, &interrupt);
    if (FT_OK != status) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error while reading interrupt pin status: %d", status);
        result = ERR_INTERRUPT;
    } else {
        if (0 == interrupt) {
            result = spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
        } else {
            result = ERR_SUCCESS;
        }
        g_device_config[osal_id.dev].old_interrupt_state = interrupt;
    }

    return result;
}

err_code_t spectral_osal_configure_timer(osal_id_t osal_id, uint8_t timer_id, uint32_t timer_us)
{
    uint32_t us = timer_us % TIME_US;
    uint32_t s = timer_us / TIME_US;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_ARGUMENT_LOWER(timer_id, TIMER_COUNT);

    gettimeofday(&(g_device_config[osal_id.dev].timer[timer_id]), 0);
    log_debug(osal_id, OSAL_MODULE_NAME, "Set timer: %d: %dus (%dus)", timer_id, timer_us,
              g_device_config[osal_id.dev].timer[timer_id].tv_usec);
    if ((g_device_config[osal_id.dev].timer[timer_id].tv_usec + us) > TIME_US) {
        s++;
    }
    g_device_config[osal_id.dev].timer[timer_id].tv_usec =
        (g_device_config[osal_id.dev].timer[timer_id].tv_usec + us) % TIME_US;
    g_device_config[osal_id.dev].timer[timer_id].tv_sec += s;
    return ERR_SUCCESS;
}

err_code_t spectral_osal_set_led(osal_id_t osal_id, uint8_t led_id, uint16_t brightness)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (0 == led_id) {
        result = ERR_NOT_SUPPORTED;
    } else if (5 > led_id) {
        result = bon_set_led(led_id - 1, 0 != brightness);
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}

err_code_t spectral_osal_get_temperature(osal_id_t osal_id, uint8_t temp_id, int32_t *p_temperature)
{
    err_code_t result;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_temperature);

    if (0 == temp_id) {
        result = ERR_NOT_SUPPORTED;
    } else if (5 > temp_id) {
        result = bon_get_temperature(temp_id - 1, p_temperature);
    } else {
        result = ERR_NOT_SUPPORTED;
    }

    return result;
}

err_code_t spectral_osal_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us_l, uint32_t *p_timestamp_us_h)
{
    struct timeval time;
    uint64_t timestamp;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);
    M_CHECK_NULL_POINTER(p_timestamp_us_l);
    M_CHECK_NULL_POINTER(p_timestamp_us_h);

    gettimeofday(&time, 0);
    timestamp = (time.tv_sec * 1000000) + time.tv_usec;

    *p_timestamp_us_l = timestamp & 0xFFFFFFFF;
    *p_timestamp_us_h = timestamp >> 32;

    return ERR_SUCCESS;
}

err_code_t spectral_osal_initialize(osal_id_t osal_id, const char *p_interface_desc)
{
    int8_t status;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    if (NULL == p_interface_desc) {
        /* call 3.3V variant */
        status = ftdiOpenByDescription("C232HM-DDHSL-0", &g_device_config[osal_id.dev].p_devHandle);
        if (FT_OK != status) {
            /* call 5V variant */
            status = ftdiOpenByDescription("C232HM-EDHSL-0", &g_device_config[osal_id.dev].p_devHandle);
        }
    } else if (0 == memcmp(REMOTE_KEY_WORD, p_interface_desc, sizeof(REMOTE_KEY_WORD) - 1)) {
        status = ftdiOpenBySerialNumber((char *)p_interface_desc + sizeof(REMOTE_KEY_WORD) - 1,
                                        &g_device_config[osal_id.dev].p_devHandle);
    } else {
        return ERR_COM_INTERFACE;
    }

    if (FT_OK != status) {
        g_device_config[osal_id.dev].p_devHandle = NULL;
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error while opening ftdi driver: %d", status);
        return ERR_COM_INTERFACE;
    }

    g_device_config[osal_id.dev].old_interrupt_state = 1;

    /* initialization of FIFO data */
    g_device_config[osal_id.dev].fifo.itemsize = sizeof(g_device_config[osal_id.dev].fifo_buffer[0]);
    g_device_config[osal_id.dev].fifo.capacity = FIFO_SIZE + 1;
    g_device_config[osal_id.dev].fifo.in = 0;
    g_device_config[osal_id.dev].fifo.out = 0;
    g_device_config[osal_id.dev].fifo.data = g_device_config[osal_id.dev].fifo_buffer;

    /* try to initialize external temperature sensors and IO expander for LED selection */
    bon_initialize(i2c_transfer, &g_device_config[osal_id.dev]);

    return ERR_SUCCESS;
}

err_code_t spectral_osal_shutdown(osal_id_t osal_id)
{
    int8_t status;

    M_CHECK_ARGUMENT_LOWER(osal_id.dev, NUM_SUPPORTED_DEVICES);

    status = ftdiClose(g_device_config[osal_id.dev].p_devHandle);
    if (FT_OK != status) {
        log_fatal(osal_id, OSAL_MODULE_NAME, "Error while closing ftdi driver: %d", status);
        return ERR_COM_INTERFACE;
    }
    return ERR_SUCCESS;
}

void spectral_osal_logging(osal_id_t osal_id, uint8_t level, const char *module_name, const char *fmt, ...)
{
    static const char *level_names[] = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"};
    uint8_t log_level_index;

    enum { LOG_TRACE = 0, LOG_DEBUG = 20, LOG_INFO = 40, LOG_WARN = 60, LOG_ERROR = 80, LOG_FATAL = 100 };

    /* Get current time */
    struct timeval tv;
    time_t t = time(NULL);
    struct tm *lt = localtime(&t);
    long milliseconds;
    va_list args;
    char buf[32];

    if ((LOG_DEBUG - 10) > level) {
        log_level_index = 0;
    } else if ((LOG_INFO - 10) > level) {
        log_level_index = 1;
    } else if ((LOG_WARN - 10) > level) {
        log_level_index = 2;
    } else if ((LOG_ERROR - 10) > level) {
        log_level_index = 3;
    } else if ((LOG_FATAL - 10) > level) {
        log_level_index = 4;
    } else {
        log_level_index = 5;
    }

    gettimeofday(&tv, NULL);
    milliseconds = tv.tv_usec / 1000;

    /* Log to stderr */
    buf[strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)] = '\0';
    fprintf(stderr, "[%s:%03ld] %-5s <%s%d>: ", buf, milliseconds, level_names[log_level_index], module_name,
            osal_id.dev);
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n");
    fflush(stderr);
}
