/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#include "osal/ftdi/ftdi_i2c.h"
#include "osal/ftdi/ftd2xx.h"

/*****************************************************************************
 *                                 DEFINITIONS                                *
 *****************************************************************************/

#define I2C_DIRECTION_READ 1
#define I2C_DIRECTION_WRITE 0
#define FTDI_RW_TIMEOUT 200 // I2C read/write timeout in ms

/*****************************************************************************
 *                                   GLOBALS                                  *
 *****************************************************************************/

static uint8_t FTDI_outBuffer[256];
static uint8_t FTDI_inBuffer[256];
static uint32_t FTDI_numBytesSent = 0;

/*****************************************************************************
 *                               LOCAL FUNCTIONS                              *
 *****************************************************************************/

// @brief put FT232H device in idle mode
// @returns - API error code
static int8_t ftdiSetI2CIdle(FT_HANDLE p_devHandle)
{
    FT_STATUS status;
    uint32_t FTDI_numBytesWr = 0;
    // Set the idle states for the AD lines
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction and data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0xFF; // Set all 8 lines to high level
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x0B; // Bits 0,1 and 3 output
              // IDLE line states are ...
              // AD0 (SCL) is output high (open drain, pulled up externally)
              // AD1 (DATA OUT) is output high (open drain, pulled up externally)
              // AD2 (DATA IN) is input (therefore the output value specified is ignored)
              // AD3 to AD7 are inputs (not used in this application)
              // Set the idle states for the AC lines
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x82; // Command to set ACbus direction and data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0xFF; // Set all 8 lines to high level
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x40; // Only bit 6 is output
                                              // IDLE line states are ...
                                              // AC6 (LED) is output driving high
                                              // AC0/1/2/3/4/5/7 are inputs (not used in this application)
    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands

    return (int8_t)status;
}

// @brief Setup device for MPSSE I2C mode
// @returns - API error code
static int8_t ftdiSetupMpsse(FT_HANDLE p_devHandle)
{
    uint32_t FTDI_numBytesWr = 0;
    FT_STATUS status;
    /* int clockDivisor = 0x00C8; // for I2C 100kHz */
    int clockDivisor = 0x0032; // for I2C 400kHz

    // Configure the MPSSE settings
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x8A; // Disable clock divide-by-5 for 60Mhz master clock
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x97; // Ensure adaptive clocking is off
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x8C; // Enable 3 phase data clocking, data valid on both clock edges for I2C
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x9E; // Enable drive-zero mode on the lines used for I2C ...
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x07; // ... on the bits AD0, 1 and 2 of the lower port...
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // ...not required on the upper port AC 0-7
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x85; // Ensure internal loopback is off
    status = FT_Write(p_devHandle, (LPVOID)FTDI_outBuffer, (DWORD)FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent);

    if (FT_OK == status) {
        // Now configure the dividers to set the SCLK frequency which we will use
        // The SCLK clock frequency can be worked out by the algorithm (when divide-by-5 is off
        FTDI_numBytesWr = 0;

        FTDI_outBuffer[FTDI_numBytesWr++] = 0x86;                                  // Command to set clock divisor
        FTDI_outBuffer[FTDI_numBytesWr++] = (uint8_t)(clockDivisor & 0xFF);        // Set 0xValueL of clock divisor
        FTDI_outBuffer[FTDI_numBytesWr++] = (uint8_t)((clockDivisor >> 8) & 0xFF); // Set 0xValueH of clock divisor
        status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands
        if (status != FT_OK) {
            return (int8_t)status;
        }
    }

    if (FT_OK == status) {
        status = ftdiSetI2CIdle(p_devHandle);
    }

    return (int8_t)status;
}

// @brief Send I2C start condition, device address and r/w direction
// @returns - API error code
static int8_t ftdiSendStartAndAddr(FT_HANDLE p_devHandle, uint8_t address, uint8_t read)
{
    uint32_t numBytesRead = 0;
    uint32_t FTDI_numBytesWr = 0;
    FT_STATUS status;
    uint8_t combinedAddrRW;
    int count;

    if (read == I2C_DIRECTION_READ) {
        combinedAddrRW = (uint8_t)((address << 1) | 0x01);
    } else {
        combinedAddrRW = (uint8_t)((address << 1) & 0xfe);
    }

    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the start setup time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/ data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFF; // Bring data line and clock line high
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }

    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the start hold time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/ data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFD; // Bring data out low (bit 1)
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }

    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the start setup time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/ data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFC; // Bring clock line low too
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }

    FTDI_outBuffer[FTDI_numBytesWr++] = 0x11; // command: clock bytes out MSB first on
                                              // clock falling edge
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; //
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // Data length of 0x0000 means clock out 1 byte
    FTDI_outBuffer[FTDI_numBytesWr++] =
        combinedAddrRW; // Actual byte to clock out
                        // Put I2C line back to idle (during transfer) state... Clock line low, Data line high
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/ data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0xFE; // Set the value of the pins
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x0B; // Bit 1 and 3 output
              // AD0 (SCL) is output driven low
              // AD1 (DATA OUT) is output high (open drain)
              // AD2 (DATA IN) is input (therefore the output value specified is ignored)
              // AD3 to AD7 are inputs driven high (not used in this application)
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x22; // Command to clock in bits MSB first
                                              // on rising edge
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x00; // Length of 0x00 means to scan in 1 bit
              // This command then tells the MPSSE to send any results gathered back immediately
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x87; // Send answer back immediate command

    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands

    /* Read result and check acknowledge */
    if (FT_OK == status) {
        status = FT_Read(p_devHandle, FTDI_inBuffer, 1, (LPDWORD)&numBytesRead);

        if (FT_OK == status) {
            if (numBytesRead != 1) {
                status = FT_APPL_ERR_READ_BYTE_SIZE;
            }
        }

        if (FT_OK == status) {
            if (((FTDI_inBuffer[0] & 0x01) != 0x00)) {
                status = FT_APPL_ERR_ACKNOWLEDGE;
            }
        }
    }

    return (int8_t)status;
}

// @brief Send I2C stop condition
// @returns - API error code
static int8_t ftdiSetI2CStop(FT_HANDLE p_devHandle)
{
    FT_STATUS status;
    uint32_t FTDI_numBytesWr = 0;
    int count;

    // Initial condition for the I2C Stop - Pull data low (Clock will already be low and is kept low)
    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the stop setup time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFC; // put data and clock low
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }
    // Clock now goes high (open drain)
    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the stop setup time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFD; // put data low, clock remains high
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }

    // Data now goes high too (both clock and data now high / open drain)
    for (count = 0; count < 4; count++) // Repeat commands to ensure the minimum period
                                        // of the stop hold time is achieved
    {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/data
        FTDI_outBuffer[FTDI_numBytesWr++] = 0xFF; // both clock and data now high
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x0B; // Bit 1 and 3 output
    }

    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands

    return (int8_t)status;
}

// @brief Write I2C byte
// @returns - API error code
static int8_t ftdiSendByte(FT_HANDLE p_devHandle, uint8_t dataSend)
{
    uint32_t numBytesRead = 0;
    FT_STATUS status;
    uint32_t FTDI_numBytesWr = 0;

    FTDI_outBuffer[FTDI_numBytesWr++] = 0x11; // command: clock bytes out MSB first on
                                              // clock falling edge
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; //
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // Data length of 0x0000 means clock out 1 byte
    FTDI_outBuffer[FTDI_numBytesWr++] =
        dataSend; // Actual byte to clock out
                  // Put I2C line back to idle (during transfer) state... Clock line low, Data line high
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction/ data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0xFE; // Set the value of the pins
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x0B; // Bit 1 and 3 output
              // AD0 (SCL) is output driven low
              // AD1 (DATA OUT) is output high (open drain)
              // AD2 (DATA IN) is input (therefore the output value specified is ignored)
              // AD3 to AD7 are inputs driven high (not used in this application)
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x22; // Command to clock in bits MSB first
                                              // on rising edge
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x00; // Length of 0x00 means to scan in 1 bit
              // This command then tells the MPSSE to send any results gathered back immediately
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x87; // Send answer back immediate command
    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands

    /* Read result and check acknowledge */
    if (FT_OK == status) {
        status = FT_Read(p_devHandle, FTDI_inBuffer, 1, (LPDWORD)&numBytesRead);

        if (FT_OK == status) {
            if (numBytesRead != 1) {
                status = FT_APPL_ERR_READ_BYTE_SIZE;
            }
        }

        if (FT_OK == status) {
            if (((FTDI_inBuffer[0] & 0x01) != 0x00)) {
                status = FT_APPL_ERR_ACKNOWLEDGE;
            }
        }
    }

    return (int8_t)status;
}

// @brief Read I2C byte
// @returns - API error code
static int8_t ftdiReadByte(FT_HANDLE p_devHandle, uint8_t *rxData, uint8_t sendAck)
{
    FT_STATUS status;
    uint32_t numBytesRead = 0;
    uint32_t FTDI_numBytesWr = 0;

    *rxData = 0xff;

    // Clock one byte of data in...
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x20; // Command: clock data byte in on clk rising edge
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // Length
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x00; // Length 0x0000 means clock ONE byte in
              // Now clock out one bit (ACK/NAK). This bit has value '1' to send a NAK to the I2C Slave
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x13; // Command: clock data bits out on clk falling edge
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // Length of 0x00 means clock out ONE bit
    if (sendAck == 1) {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x00; // Command will send bit 7 of this byte (= �0�)
    } else {
        FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command will send bit 7 of this byte (= �1�)
    }
    // Put I2C line back to idle (during transfer) state... Clock line low, Data line high
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x80; // Command to set ADbus direction data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0xFE; // Set the value of the pins
    FTDI_outBuffer[FTDI_numBytesWr++] =
        0x0B; // Bit 1 and 3 output
              // AD0 (SCL) is output driven low
              // AD1 (DATA OUT) is output high (open drain)
              // AD2 (DATA IN) is input (therefore the output value specified is ignored)
              // AD3 to AD7 are inputs driven high (not used in this application)
              // This command then tells the MPSSE to send any results gathered back immediately
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x87; // Send answer back immediate command
                                              // Send off the commands to the FT232H
    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands

    /* Read result and check acknowledge */
    if (FT_OK == status) {
        status = FT_Read(p_devHandle, FTDI_inBuffer, 1, (LPDWORD)&numBytesRead);

        if (FT_OK == status) {
            if (numBytesRead != 1) {
                status = FT_APPL_ERR_READ_BYTE_SIZE;
            }

            if (FT_OK == status) {
                *rxData = FTDI_inBuffer[0];
            }
        }
    }

    return (int8_t)status;
}

// @brief Init the the device, configure I2C mode and open a channel
// @param channel - the channel to open (default: 0)
// @returns - API error code
int8_t ftdiConfiguration(FT_HANDLE p_devHandle)
{
    FT_STATUS status;

    /* reset device */
    status = FT_ResetDevice(p_devHandle);

    /* purge Rx and Tx buffers */
    if (FT_OK == status) {
        status = FT_Purge(p_devHandle, FT_PURGE_RX | FT_PURGE_TX);
    }

    /* disable special event and error characters */
    if (FT_OK == status) {
        status = FT_SetChars(p_devHandle, 0, 0, 0, 0);
    }

    /* set r/w timeouts */
    if (FT_OK == status) {
        status = FT_SetTimeouts(p_devHandle, (uint32_t)FTDI_RW_TIMEOUT, (uint32_t)FTDI_RW_TIMEOUT);
    }

    /* set bitmode, select MPSSE mode */
    if (FT_OK == status) {
        status = FT_SetBitMode(p_devHandle, 0x00, 0x02);
    }

    if (FT_OK == status) {
        ftdiSetupMpsse(p_devHandle);
    }

    return (int8_t)status;
}

/*****************************************************************************
 *                              GLOBAL FUNCTIONS                              *
 *****************************************************************************/

// @brief Init the the device, configure I2C mode and open a channel
// @param channel - the channel to open (default: 0)
// @returns - API error code
int8_t ftdiOpenByDeviceNumber(int channel, FT_HANDLE *pp_devHandle)
{
    FT_STATUS status;

    /* try to open device on given channel */
    status = FT_Open(channel, pp_devHandle);

    if (FT_OK == status) {
        status = ftdiConfiguration(*pp_devHandle);
    }

    return (int8_t)status;
}

// @brief Init the FTDI-device with the help of the device description
// @param p_description Pointer to device description like "C232HM-DDHSL-0"
// @param  pp_devHandler Pointer to a pointer where device handle can be saved
// @returns - API error code
int8_t ftdiOpenByDescription(char *p_description, FT_HANDLE *pp_devHandle)
{
    FT_STATUS status;

    /* try to open device on given channel */
    status = FT_OpenEx(p_description, FT_OPEN_BY_DESCRIPTION, pp_devHandle);

    if (FT_OK == status) {
        status = ftdiConfiguration(*pp_devHandle);
    }

    return (int8_t)status;
}

// @brief Init the FTDI-device with the help of the serial number
// @param p_serial Serial string of the device
// @param  pp_devHandler Pointer to a pointer where device handle can be saved
// @returns - API error code
int8_t ftdiOpenBySerialNumber(char *p_serial, FT_HANDLE *pp_devHandle)
{
    FT_STATUS status;

    /* try to open device on given channel */
    status = FT_OpenEx(p_serial, FT_OPEN_BY_SERIAL_NUMBER, pp_devHandle);

    if (FT_OK == status) {
        status = ftdiConfiguration(*pp_devHandle);
    }

    return (int8_t)status;
}

// @brief Close FTDI device
int8_t ftdiClose(FT_HANDLE p_devHandle)
{
    return (int8_t)FT_Close(p_devHandle);
}

// @brief Write single byte to I2C mem address
// @param devAddr - i2c device address
// @param command - memory address towrite to
// @param regData - pointer to buffer for byte to send
// @returns - API error code
int8_t ftdiWriteSingleReg(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t regData)
{
    FT_STATUS status;

    status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_WRITE);

    if (FT_OK == status) {
        status = ftdiSendByte(p_devHandle, command);
    }

    if (FT_OK == status) {
        status = ftdiSendByte(p_devHandle, regData);
    }

    /* set always an I2C stop */
    ftdiSetI2CStop(p_devHandle);

    return (int8_t)status;
}

int8_t ftdiTransferData(FT_HANDLE p_devHandle, uint8_t dev_addr, uint8_t *p_send_data, uint8_t send_size,
                        uint8_t *p_receive_data, uint8_t receive_size)
{
    FT_STATUS status = FT_OK;
    uint8_t i;
    uint8_t sendAck;

    if (0 < send_size) {
        status = ftdiSendStartAndAddr(p_devHandle, dev_addr, I2C_DIRECTION_WRITE);
        for (i = 0; (FT_OK == status) && (i < send_size); i++) {
            status = ftdiSendByte(p_devHandle, p_send_data[i]);
        }
    }

    if (0 < receive_size && (FT_OK == status)) {
        status = ftdiSendStartAndAddr(p_devHandle, dev_addr, I2C_DIRECTION_READ);
        for (i = 0; (FT_OK == status) && (i < receive_size); i++) {
            sendAck = (i < (receive_size - 1)); // ack if not the last byte to read, else nack
            status = ftdiReadByte(p_devHandle, p_receive_data + i, sendAck);
        }
    }

    /* set always an I2C stop */
    ftdiSetI2CStop(p_devHandle);

    return (int8_t)status;
}

// @brief Write multiple bytes to I2C mem address
// @param devAddr - i2c device address
// @param command - memory address to write to
// @param buf - pointer to buffer for bytes to send
// @param numBytesWr - number of bytes to write
// @returns - API error code
int8_t ftdiSendFromBuffer(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *buf, uint32_t numBytesWr)
{
    uint32_t count;
    FT_STATUS status;

    status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_WRITE);

    if (FT_OK == status) {
        status = ftdiSendByte(p_devHandle, command);
    }

    for (count = 0; (FT_OK == status) && (count < numBytesWr); count++) {
        status = ftdiSendByte(p_devHandle, buf[count]);
    }

    /* set always an I2C stop */
    ftdiSetI2CStop(p_devHandle);

    return (int8_t)status;
}

// @brief Read single byte from I2C mem address
// @param devAddr - i2c device address
// @param command - memory address to read from
// @param regData - pointer to buffer for received byte
// @returns - API error code
int8_t ftdiReadSingleReg(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *regData)
{
    FT_STATUS status;

    status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_WRITE);

    if (FT_OK == status) {
        status = ftdiSendByte(p_devHandle, command);
    }

    if (FT_OK == status) {
        status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_READ);
    }

    if (FT_OK == status) {
        status = ftdiReadByte(p_devHandle, regData, 0);
    }

    /* set always an I2C stop */
    ftdiSetI2CStop(p_devHandle);

    return (int8_t)status;
}

// @brief Read multiple bytes from I2C mem address
// @param devAddr - i2c device address
// @param command - memory address to read from
// @param buf - pointer to buffer for received bytes
// @param numBytesRd - number of bytes to read
// @returns - API error code
int8_t ftdiReadToBuffer(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *buf, uint32_t numBytesRd)
{
    uint32_t count;
    uint8_t regData;
    uint8_t sendAck;
    FT_STATUS status;

    status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_WRITE);

    if (FT_OK == status) {
        status = ftdiSendByte(p_devHandle, command);
    }

    if (FT_OK == status) {
        status = ftdiSendStartAndAddr(p_devHandle, devAddr, I2C_DIRECTION_READ);
    }

    for (count = 0; (FT_OK == status) && (count < numBytesRd); count++) {
        sendAck = 0;
        regData = 0xff;
        if (count < (numBytesRd - 1)) {
            // ack if not the last byte to read, else nack
            sendAck = 1;
        }
        status = ftdiReadByte(p_devHandle, &regData, sendAck);

        buf[count] = regData;
    }

    /* set always an I2C stop */
    ftdiSetI2CStop(p_devHandle);

    return (int8_t)status;
}

// Reads the state of the INT pin (ADBUS4 == GPIOL0 == Gray wire)
// @param p_pin_level - 0 - pin is Low, 1 - pin is High
// @returns - API error code
int8_t ftdiReadInterruptPin(FT_HANDLE p_devHandle, uint8_t *p_pin_level)
{
    uint32_t numBytesRead = 0;
    FT_STATUS status;
    int ReadTimeoutCounter;
    uint32_t rxBytes = 0;
    uint32_t FTDI_numBytesWr = 0;

    // Set the idle states for the AD lines
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x81; // Command to read ADbus data
    FTDI_outBuffer[FTDI_numBytesWr++] = 0x87; // Send answer back immediate command

    status = FT_Write(p_devHandle, FTDI_outBuffer, FTDI_numBytesWr, (LPDWORD)&FTDI_numBytesSent); // send commands
    if (status == FT_OK) {
        // ===============================================================
        // Now wait for the byte which we read to come back to the host PC
        // ===============================================================
        ReadTimeoutCounter = 0;
        status = FT_GetQueueStatus(p_devHandle, (DWORD *)&rxBytes);

        while ((rxBytes < 1) && (status == FT_OK) && (ReadTimeoutCounter < 500)) {
            // Sit in this loop until
            // (1) we receive the one byte expected
            // or (2) a hardware error occurs causing the GetQueueStatus to return an error code
            // or (3) we have checked 500 times and the expected byte is not coming
            status = FT_GetQueueStatus(p_devHandle, (DWORD *)&rxBytes);
            ReadTimeoutCounter++;
        }
        // If loop above exited due to the byte coming back (not an error code and not a timeout)
        // then read the byte available and return True to indicate success
        if ((status == FT_OK) && (ReadTimeoutCounter < 1000)) {
            status = FT_Read(p_devHandle, FTDI_inBuffer, rxBytes, (LPDWORD)&numBytesRead);
            if (FT_OK == status) {
                if (0 == numBytesRead) {
                    status = FT_APPL_ERR_READ_BYTE_SIZE;
                }

                if (FT_OK == status) {
                    *p_pin_level = (FTDI_inBuffer[0] & 0x10) == 0x10;
                }
            }
        }
    }

    return (int8_t)status;
}
