/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __SPECTRAL_OSAL_LOGGING_H__
#define __SPECTRAL_OSAL_LOGGING_H__

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

enum { LOG_TRACE = 0, LOG_DEBUG = 20, LOG_INFO = 40, LOG_WARN = 60, LOG_ERROR = 80, LOG_FATAL = 100 };

#ifndef LOG_LEVEL

#define log_trace(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#define log_debug(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#define log_info(device, module, ...)                                                                                  \
    do {                                                                                                               \
    } while (0)
#define log_warn(device, module, ...)                                                                                  \
    do {                                                                                                               \
    } while (0)
#define log_error(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#define log_fatal(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#define log_user(level, device, module, ...)                                                                           \
    do {                                                                                                               \
    } while (0)

#else

void spectral_osal_logging(const osal_id_t dev_id, uint8_t level, const char *module_name, const char *fmt, ...);

#if (LOG_LEVEL <= 0)
#define log_trace(device, module, ...) spectral_osal_logging(device, LOG_TRACE, module, __VA_ARGS__)
#else
#define log_trace(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#endif

#if (LOG_LEVEL <= 20)
#define log_debug(device, module, ...) spectral_osal_logging(device, LOG_DEBUG, module, __VA_ARGS__)
#else
#define log_debug(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#endif

#if (LOG_LEVEL <= 40)
#define log_info(device, module, ...) spectral_osal_logging(device, LOG_INFO, module, __VA_ARGS__)
#else
#define log_info(device, module, ...)                                                                                  \
    do {                                                                                                               \
    } while (0)
#endif

#if (LOG_LEVEL <= 60)
#define log_warn(device, module, ...) spectral_osal_logging(device, LOG_WARN, module, __VA_ARGS__)
#else
#define log_warn(device, module, ...)                                                                                  \
    do {                                                                                                               \
    } while (0)
#endif

#if (LOG_LEVEL <= 80)
#define log_error(device, module, ...) spectral_osal_logging(device, LOG_ERROR, module, __VA_ARGS__)
#else
#define log_error(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#endif

#if (LOG_LEVEL <= 100)
#define log_fatal(device, module, ...) spectral_osal_logging(device, LOG_FATAL, module, __VA_ARGS__)
#else
#define log_fatal(device, module, ...)                                                                                 \
    do {                                                                                                               \
    } while (0)
#endif

#define log_user(level, device, module, ...) spectral_osal_logging(device, level, module, __VA_ARGS__)

#endif

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* __SPECTRAL_OSAL_LOGGING_H__ */
