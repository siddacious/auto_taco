/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_CHIP_LIB_HAL_H__
#define __AS7341_CHIP_LIB_HAL_H__

/*!
 * \file      spectral_osal_chiplib.h
 * \authors   ARIT
 * \copyright ams
 * \addtogroup osal_group
 *
 * \brief This is the abstraction layer for the chip library.
 *
 * The functions has dependencies to the operatation system.
 * So the function must be implemented application specific.
 * Following function groups must be implemented:
 * - initialize/shutdown
 * - I2C-transfers
 * - message event handler
 * - timer control
 *
 * Following functions are application specific and optional:
 * - temperature readout
 * - external LED control
 * - interrupt handler
 * - timestamp reading
 *
 * @{
 */

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"
#include "error_codes.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/*! Event types for measurement state machine */
enum EVENT_TYPES {
    EVENT_NONE = 0,      /*!< No event, will be used if no event is active. */
    EVENT_NEW_STATE = 1, /*!< Will be used internally to jump between different states. A second parameter keeps the new
                        state. */
    EVENT_ERROR = 2,     /*!< Signals an error state. A second parameter keeps the error code. */
    EVENT_START = 3,     /*!< A measurement shall be started. */
    EVENT_ABORT = 4,     /*!< A running measurement shall be aborted. */
    EVENT_INTERRUPT = 5, /*!< Interrupt pin is low. */
    EVENT_TIMER_MEASUREMENT = 6, /*!< The measurement timer is expired. */
    EVENT_TIMER_TIMEOUT = 7,     /*!< The timeout timer is expired. */
    EVENT_TIMER_LED = 8,         /*!< The LED switch timer is expired. */
    EVENT_TIMER_3 = 9,           /*!< Not used. Reserved for future applications. */
    EVENT_TIMER_4 = 10,          /*!< Not used. Reserved for future applications. */
    EVENT_TIMER_5 = 11,          /*!< Not used. Reserved for future applications. */
    EVENT_TIMER_6 = 12,          /*!< Not used. Reserved for future applications. */
    EVENT_TIMER_7 = 13,          /*!< Not used. Reserved for future applications. */
};

/*! Specifies the device type and id to link to the right driver. */
typedef struct spectral_osal_id {
    uint16_t chip; /*!< The numeric description of the used sensor, e.g. AS1234 -> chip = 1234. */
    uint8_t dev;   /*!< Defines which number of device shall be used [0 .. NUM_SUPPORTED_DEVICES-1]. */
} osal_id_t;

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/*!
 * \brief Initialization of the hardware abstraction layer.
 *
 * - Initialization of global parameters.
 * - Open the interface to the sensor.
 * - Initialization of all external peripheries.
 *
 * \note This function must be called at first!
 *
 * Pseudo code for implementation example:
 * \n
 * \code
 *
 * check_osal_chip_id();
 * check_device_osal_device_id();
 *
 * // initialize mandatory components
 * initialize_i2c_interface();
 * initialize_event_handler();
 * initialize_timer_control();
 *
 * // initialize optional components
 * initialize_interrupt_handler();
 * initialize_temperature_sensors();
 * initialize_led_drivers();
 *
 * \endcode
 *
 * \param[in] osal_id               Handle to the device.
 * \param[in] p_interface_desc      Can be used to transfer special initialization data like interface description.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_COM_INTERFACE      The interface to the sensor is faulty.
 */
err_code_t spectral_osal_initialize(const osal_id_t osal_id, const char *p_interface_desc);

/*!
 * \brief Shutdown of the hardware abstraction layer
 *
 * - Closes the interface to the sensor
 * - Power down of all external peripheries
 *
 * \note This function must be called for cleanup
 *
 * \param[in] osal_id handle to the device
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_COM_INTERFACE      The interface to the sensor is faulty
 */
err_code_t spectral_osal_shutdown(const osal_id_t osal_id);

/*!
 * \brief Write and read data in one transfer
 *
 * This function is a abstraction layer for normal I2C-transfers.
 * All kinds of different modes are possible
 * - register access
 * - single register write
 * - single register read
 * - burst write
 * - burst read
 *
 * Pseudo code for implementation example:
 * \n
 * \code
 *
 * check_osal_chip_id();
 * check_device_osal_device_id();
 *
 * if (0 < send_data_size) {
 *     write_i2c_data(i2c_address, p_send_data, send_data_size)
 * };
 *
 * if (0 < receive_data_size) {
 *     read_i2c_data(i2c_address, p_receive_data, receive_data_size)
 * };
 *
 * \endcode
 *
 * \param[in] osal_id               Handle to the device.
 * \param[in] p_send_data           Pointer to data which shall be sent.
 * \param[in] send_data_size        Size of send data in bytes.
 * \param[out] p_receive_data       Pointer to memory, where received data can be saved.
 * \param[in] receive_data_size     Number of data, which shall be read.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_POINTER            If buffer size is unequal 0 and buffer address is zero.
 * \retval ::ERR_COM_INTERFACE      The interface to the sensor is faulty.
 * \retval ::ERR_DATA_TRANSFER      Data transfer error, like bus error or timeout.
 */
err_code_t spectral_osal_transfer_data(const osal_id_t osal_id, uint8_t *p_send_data, const uint8_t send_data_size,
                                       uint8_t *p_receive_data, const uint8_t receive_data_size);

/*!
 * \brief Pushes an event into the event queue.
 *
 * \note Must be return immediately.
 *
 * \param[in] osal_id               Handle to the device.
 * \param[in] event                 Event type, see enum ::EVENT_TYPES.
 * \param[in] payload               Optional parameter of event, type specific.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted or the event is not supported.
 * \retval ::ERR_EVENT              Error during event registration (e.g. overflow)
 */
err_code_t spectral_osal_set_event(const osal_id_t osal_id, const uint16_t event, const uint16_t payload);

/*!
 * \brief Waits for an event / Checks if an event is active.
 *
 * \note In non-blocking mode, the event parameter returns ::EVENT_NONE on empty queue.
 *
 * Pseudo code for implementation example:
 * \n
 * \code
 *
 * check_osal_chip_id();
 * check_device_osal_device_id();
 *
 * // optional on non-blocking interface,
 * // if interrupt event will not be handled in an interrupt service routine.
 * if (interrupt_pin_low()) {
 *     spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
 * }
 *
 * // optional on non-blocking interface,
 * // if a configured timer is expired
 * if (timer_is_expired(&timer_id)) {
 *     spectral_osal_set_event(osal_id, EVENT_TIMER_MEASUREMENT + timer_id, 0);
 * }
 *
 * if (blocking_mode) {
 *     wait_for_new_event(p_event, p_payload);
 * } else {
 *     // return immediately
 *     check_for_new_event(p_event, p_payload);
 * }
 *
 * \endcode
 *
 * \param[in] osal_id               Handle to the device.
 * \param[out] p_event              Event type, see enum ::EVENT_TYPES.
 * \param[out] p_payload            Optional parameter of event, type specific, otherwise zero.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_EVENT              Error during event handling (e.g. overflow).
 * \retval ::ERR_POINTER            If one of the pointers are zero.
 * \retval ::ERR_INTERRUPT:         If checking interrupt failed (optional, if not handled in separate thread)
 * \retval ::ERR_TIMER_ACCESS:      If checking timer expiration failed (optional, if not handled in separate thread)
 */
err_code_t spectral_osal_wait_for_event(const osal_id_t osal_id, uint16_t *p_event, uint16_t *p_payload);

/*!
 * \brief Retriggers the EVENT_INTERRUPT-event, if the interrupt pin is still low.
 *
 * It is not mandatory to implement this function, because ChipLib uses timer interface at default.
 * If this function will not be used, return error code ::ERR_NOT_SUPPORTED.
 *
 * \note This is necessary because sometimes the measurement state machine is to slow to get the event on right time.
 *
 * Pseudo code for implementation example:
 * \n
 * \code
 *
 * check_osal_chip_id();
 * check_device_osal_device_id();
 *
 * if (interrupt_pin_low()) {
 *     spectral_osal_set_event(osal_id, EVENT_INTERRUPT, 0);
 * }
 *
 * \endcode
 *
 * \param[in] osal_id               Handle to the device.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_INTERRUPT:         If checking interrupt failed.
 * \retval ::ERR_NOT_SUPPORTED:     If function is not supported.
 */
err_code_t spectral_osal_check_pending_interrupt(const osal_id_t osal_id);

/*!
 * \brief Triggers the start of a timer.
 *
 * - Up to 8 timers will be supported.
 * - The corresponding events are ::EVENT_TIMER_MEASUREMENT until ::EVENT_TIMER_7.
 *
 * \param[in] osal_id               Handle to the device.
 * \param[in] timer_id              Supports up to 8 timer. [0 - 7]
 * \param[in] timer_us              Set the timeoffset in microseconds.
 *                                  After this time the corresponding event will be fired
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted or the timer id is out of range.
 * \retval ::ERR_TIMER_ACCESS:      If timer configuration failed.
 */
err_code_t spectral_osal_configure_timer(const osal_id_t osal_id, const uint8_t timer_id, const uint32_t timer_us);

/*!
 * \brief Configures an external LED.
 *
 * \note Optional function: If not used, return ::ERR_NOT_SUPPORTED.
 *
 * \param[in] osal_id               Handle to the device.
 * \param[in] led_id                Supports up to 6 LEDs. [0 - 5].
 * \param[in] brightness            Brightness of the LED in per mile [0 - 1000].
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted or the led id/brightness is out of range.
 * \retval ::ERR_LED_ACCESS:        If led configuration failed.
 * \retval ::ERR_NOT_SUPPORTED:     If function is not supported.
 */
err_code_t spectral_osal_set_led(const osal_id_t osal_id, const uint8_t led_id, const uint16_t brightness);

/*!
 * \brief Reads temperature of an external temperature sensor.
 *
 * \note Optional function: if not used, return ::ERR_NOT_SUPPORTED.
 *
 * \param[in] osal_id                   Handle to the device.
 * \param[in] temp_id                   Supports up to 6 external temperature sensors. [0 - 5].
 * \param[out] p_temperature            Temperature in millidegree Celsius.
 *
 * \retval ::ERR_SUCCESS                Function returns without error.
 * \retval ::ERR_ARGUMENT               If the osal_id was not fitted or the temp id is out of range.
 * \retval ::ERR_POINTER                If the pointer is zero.
 * \retval ::ERR_TEMP_SENSOR_ACCESS:    If temperature readout failed.
 * \retval ::ERR_NOT_SUPPORTED:         If function is not supported.
 */
err_code_t spectral_osal_get_temperature(const osal_id_t osal_id, const uint8_t temp_id, int32_t *p_temperature);

/*!
 * \brief Reads timestamp of the system in microseconds.
 *
 * \note Optional function: if not used, return ::ERR_NOT_SUPPORTED.
 *
 * \attention The 32bit timestamp can only handle a time range of round about 1hour.
 *            Afterwards, is jumps back to zero.
 *
 * \param[in] osal_id               Handle to the device.
 * \param[out] p_timestamp_us_l     Lower 32bit of timestamp in microseconds.
 * \param[out] p_timestamp_us_h     Higher 32bit of timestamp in microseconds.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           If the osal_id was not fitted.
 * \retval ::ERR_POINTER            If the pointer is zero.
 * \retval ::ERR_NOT_SUPPORTED:     If function is not supported.
 */
err_code_t spectral_osal_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us_l, uint32_t *p_timestamp_us_h);

#ifdef __cplusplus
}
#endif // __cplusplus

/*! @} */

#endif /* __AS7341_CHIP_LIB_HAL_H__ */
