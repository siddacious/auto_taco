/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __BOARD_1TO1_H__
#define __BOARD_1TO1_H__

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "error_codes.h"
#include <stdint.h>

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

enum IDs { ID_TOP = 0, ID_BOT = 1, ID_LEFT = 2, ID_EXT = 3 };

/*!
 * \brief Callback function to transfers a I2C sequence to a specific i2c address
 *
 * \param[in] p_param       optional pointer to application context
 * \param[in] dev_addr      I2C device address
 * \param[in] p_send_data   pointer to send data buffer
 * \param[in] send_len      number of bytes to send
 * \param[out] p_recv_data  pointer to receive data buffer
 * \param[in] recv_len      number of bytes to read
 * \retval  ::ERR_SUCCESS or error code
 */
typedef err_code_t (*i2c_transfer_callback)(void *p_param, uint8_t dev_addr, uint8_t *p_send_data, uint8_t send_len,
                                            uint8_t *p_recv_data, uint8_t recv_len);

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

err_code_t bon_initialize(i2c_transfer_callback p_i2c_transfer, void *p_callback_param);
err_code_t bon_get_temperature(uint8_t id, int32_t *p_millidegree);
err_code_t bon_set_led(uint8_t id, uint8_t enable);

#endif /* __BOARD_1TO1_H__ */
