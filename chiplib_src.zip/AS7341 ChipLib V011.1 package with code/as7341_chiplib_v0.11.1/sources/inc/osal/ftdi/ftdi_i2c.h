/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef FTDI_I2C_H_
#define FTDI_I2C_H_

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "ftd2xx.h"
#include <stdint.h>

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

enum FTDI_APPL_ERROR {
    FT_APPL_ERR_READ_BYTE_SIZE = 100,
    FT_APPL_ERR_ACKNOWLEDGE = 101,
};

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

int8_t ftdiOpenByDeviceNumber(int channel, FT_HANDLE *pp_devHandle);
int8_t ftdiOpenByDescription(char *p_description, FT_HANDLE *pp_devHandle);
int8_t ftdiOpenBySerialNumber(char *p_serial, FT_HANDLE *pp_devHandle);
int8_t ftdiClose(FT_HANDLE p_devHandle);

int8_t ftdiSendSingleReg(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t regData);
int8_t ftdiSendFromBuffer(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *buf, uint32_t numBytesWr);

int8_t ftdiReadSingleReg(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *regData);
int8_t ftdiReadToBuffer(FT_HANDLE p_devHandle, uint8_t devAddr, uint8_t command, uint8_t *buf, uint32_t numBytesRd);

int8_t ftdiReadInterruptPin(FT_HANDLE p_devHandle, uint8_t *p_pin_level);

int8_t ftdiTransferData(FT_HANDLE p_devHandle, uint8_t dev_addr, uint8_t *p_send_data, uint8_t send_size,
                        uint8_t *p_receive_data, uint8_t receive_size);

#endif // FTDI_I2C_H_
