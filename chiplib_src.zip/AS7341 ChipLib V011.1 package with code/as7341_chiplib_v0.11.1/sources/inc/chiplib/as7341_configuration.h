/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_CONFIGURATION_H__
#define __AS7341_CONFIGURATION_H__

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"
#include "error_codes.h"
#include "spectral_osal_chiplib.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

/* USER_CODE END DEFINITIONS */

#define ITEM_NO_LENGTH_CHECK 255 /*!< set this value if item handler does not check item sizes */
#define NO_INDEX_USED 255        /*!< set this value if item handler don't need to support items */

struct config_item_entry {
    uint8_t item_id; /*!< item id */
    uint8_t size;    /*!< size */
    err_code_t (*set_fct_pnt)(const osal_id_t osal_id, uint8_t index, void *p_data,
                              uint8_t size); /*!< pointer to set command */
    err_code_t (*get_fct_pnt)(const osal_id_t osal_id, uint8_t index, void *p_data,
                              uint8_t size); /*!< pointer to get command */
    uint8_t index;                           /*!< index for subroutines, eg LED_0, LED_1 or TEMP_0, TEMP_1 */
};

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/* USER_CODE BEGIN FUNCTIONS */

/* USER_CODE END FUNCTIONS */

err_code_t config_get_item_table(const osal_id_t osal_id, struct config_item_entry **pp_item_entry,
                                 uint32_t *p_num_of_entries);
err_code_t config_get_item_size(const osal_id_t osal_id, const uint8_t item_id, uint8_t *p_item_size);

err_code_t config_initialize(const osal_id_t osal_id);
err_code_t config_shutdown(const osal_id_t osal_id);

#endif /* __AS7341_CONFIGURATION_H__ */
