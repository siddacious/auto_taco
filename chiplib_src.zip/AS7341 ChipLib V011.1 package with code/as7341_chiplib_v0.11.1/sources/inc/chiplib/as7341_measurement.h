/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_MEASUREMENT_H__
#define __AS7341_MEASUREMENT_H__

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"
#include "as7341_typedefs.h"
#include "error_codes.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

enum led_ids {
    LED_ID_INTERN = 0,
    LED_ID_EXT_0 = 1,
    LED_ID_EXT_1 = 2,
    LED_ID_EXT_2 = 3,
    LED_ID_EXT_3 = 4,
    LED_ID_EXT_4 = 5,
    LED_ID_EXT_5 = 6,
    LED_ID_OUTPUT = 7,
    LED_ID_MAX = 8
};

/*! state machine states of the measurement engine */
enum FSM_STATES {
    FSM_STATE_UNKNOWN = 0,      /*!< measurement engine is not initialized */
    FSM_STATE_IDLE = 1,         /*!< measurement engine does nothing and waits for start */
    FSM_STATE_INIT = 2,         /*!< initialization of the measurement engine */
    FSM_STATE_CONF_BLOCK_0 = 3, /*!< configuration of the first 6 spectral channels */
    FSM_STATE_CONF_BLOCK_1 = 4, /*!< configuration of the second 6 spectral channels */
    FSM_STATE_WAIT_BLOCK_0 = 5, /*!< wait for external event that measurement has finished */
    FSM_STATE_WAIT_BLOCK_1 = 6, /*!< wait for external event that measurement has finished */
    FSM_STATE_READ_BLOCK_0 = 7, /*!< reads the first 6 spectral channels from sensor device */
    FSM_STATE_READ_BLOCK_1 = 8, /*!< reads the second 6 spectral channels from sensor device */
    FSM_POST_PROCESS = 9,       /*!< send measurement result and append meta data */
    FSM_STATE_RETRY = 10,       /*!< checks if the measurement has finished or further measurements are configured */
    FSM_STATE_ABORT = 11,       /*!< Handles the abort of a running measurement */
    FSM_STATE_ERROR = 12,       /*!< Handles errors during measurement and informs the application */
    FSM_STATE_WAIT_FOR_LED_INIT_TIMER = 13, /*!< waits for the warm up time of the LED */
    FSM_STATE_WAIT_FOR_LED_MEAS_TIMER = 14, /*!< handles synchronisation of LED-disable and measurement */
    FSM_STATE_RESTART = 15,                 /*!< restarts the measurement */
    FSM_STATE_CHECK_BLOCK_0_FINISHED = 16,  /*!< checks if the measurement of sensor values has finished */
    FSM_STATE_CHECK_BLOCK_1_FINISHED = 17,  /*!< checks if the measurement of sensor values has finished */

    FSM_STATE_FIFO_READ = 18,    /*!< cyclic read of FIFO data */
    FSM_STATE_FIFO_RESTART = 19, /*!< restarts FIFO measurement after auto gain */

    FSM_STATE_ALL = 255 /*!< special state for transition table: marks, that an event will be handled in every state  */
};

/* USER_CODE END DEFINITIONS */

/*! parameter of each transistion function */
struct transitions {
    enum FSM_STATES
        current_state;         /*!< the transistion is only possible, if the current fsm state is equal to this one */
    enum EVENT_TYPES event;    /*!< defines with event will be handled in the current state */
    enum FSM_STATES new_state; /*!< defines the new FSM state after successful transition */
    err_code_t (*func)(const osal_id_t osal_id,
                       enum FSM_STATES state); /*!< function which will be called on transition to the new state */
};

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/* USER_CODE BEGIN FUNCTIONS */

err_code_t measure_set_measurement_type(const osal_id_t osal_id, uint8_t type);
err_code_t measure_get_measurement_type(const osal_id_t osal_id, uint8_t *p_type);

err_code_t measure_set_measurement_count(const osal_id_t osal_id, uint16_t count);
err_code_t measure_get_measurement_count(const osal_id_t osal_id, uint16_t *p_count);

err_code_t measure_enable_interrupt_pin(const osal_id_t osal_id, uint8_t enable);
err_code_t measure_is_interrupt_pin_enabled(const osal_id_t osal_id, uint8_t *p_enabled);

err_code_t measure_set_led_wait_time(const osal_id_t osal_id, uint32_t wait_time_us);
err_code_t measure_get_led_wait_time(const osal_id_t osal_id, uint32_t *p_wait_time_us);

err_code_t measure_set_led_pattern(const osal_id_t osal_id, uint16_t *p_led_pattern, uint8_t size);
err_code_t measure_get_led_pattern(const osal_id_t osal_id, uint16_t *p_led_pattern, uint8_t size);

err_code_t measure_set_led(const osal_id_t osal_id, uint8_t led_id, uint8_t enable, uint16_t led_brightness);
err_code_t measure_get_led(const osal_id_t osal_id, uint8_t led_id, uint8_t *p_enable, uint16_t *p_led_brightness);

err_code_t measure_set_items(const osal_id_t osal_id, uint8_t *p_data, uint8_t size);
err_code_t measure_get_items(const osal_id_t osal_id, uint8_t *p_data, uint8_t size);

err_code_t measure_set_break_time_us(const osal_id_t osal_id, uint32_t break_time_us);
err_code_t measure_get_break_time_us(const osal_id_t osal_id, uint32_t *p_break_time_us);

err_code_t measure_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us_l, uint32_t *p_timestamp_us_h);

err_code_t measure_set_auto_gain(const osal_id_t osal_id, uint8_t lower_limit, uint8_t upper_limit);
err_code_t measure_get_auto_gain(const osal_id_t osal_id, uint8_t *p_lower_limit, uint8_t *p_upper_limit);

err_code_t measure_set_gain_factors(const osal_id_t osal_id, uint16_t *p_data, uint8_t length);
err_code_t measure_get_gain_factors(const osal_id_t osal_id, uint16_t *p_data, uint8_t length);

/* USER_CODE END FUNCTIONS */

err_code_t measure_initialize(const osal_id_t osal_id, as7341_callback_t p_callback, const void *p_callback_parameter);
err_code_t measure_shutdown(const osal_id_t osal_id);
err_code_t measure_get_transition_table(const osal_id_t osal_id, struct transitions **pp_transition_table,
                                        uint32_t *p_num_transitions);
err_code_t measure_set_fsm_error(const osal_id_t osal_id, err_code_t error_code);

#endif /* __AS7341_MEASUREMENT_H__ */
