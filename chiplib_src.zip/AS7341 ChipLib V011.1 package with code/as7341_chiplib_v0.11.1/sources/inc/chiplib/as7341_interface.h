/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_INTERFACE_H__
#define __AS7341_INTERFACE_H__

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"
#include "error_codes.h"
#include "spectral_osal_chiplib.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

#define MAX_SUPPORTED_CHANNEL_BLOCKS 2
#define NUM_OF_ADC_CHANNELS 6
#define MAX_LED_DRIVING_STRENGTH 258
#define REG_BIT_LED_LED_ACT_MSK 0x80
#define MAX_WAIT_TIME_US 11376000
#define MAX_WAIT_TIME_US_WITHOUT_WLONG 711000
#define WAIT_TIME_WLONG_FACTOR 16
#define CONVERSION_FACTOR_MS_TO_US 1000

#define INTEGRATION_TIME_STEP_US_FACTOR 2000
#define INTEGRATION_TIME_STEP_US_DIVIDER 720

enum AS7341_INTERRUPT { INTERRUPT_NONE = 0x00, INTERRUPT_SPECTRAL = 0x08, INTERRUPT_FIFO = 0x04 };

enum AS7341_AUTOZERO {
    AS7341_AUTOZERO_NONE = 0,
    AS7341_AUTOZERO_ALWAYS = 1,
    AS7341_AUTOZERO_MAX_CYCLES = 254,
    AS7341_AUTOZERO_ONE = 255
};

/*!
 * \brief Measurement types
 */
enum AS7341_MEASURE_TYPE {
    MEAS_TYPE_ALL = 0x03,
    MEAS_TYPE_SPECTRAL = 0x01, /*!< spectral measurement*/
    MEAS_TYPE_FIFO = 0x02,     /*!< FIFO measurement*/
};

enum AS7341_REGADDR {
    AS7341_REGADDR_CHIP_ID = 0x0B,

    AS7341_REGADDR_CONFIG = 0x70,
    AS7341_REGADDR_STAT = 0x71,
    AS7341_REGADDR_EDGE = 0x72,
    AS7341_REGADDR_GPIO = 0x73,
    AS7341_REGADDR_LED = 0x74,
    AS7341_REGADDR_ENABLE = 0x80,
    AS7341_REGADDR_ITIME = 0x63,
    AS7341_REGADDR_ATIME = 0x81,
    AS7341_REGADDR_WTIME = 0x83,

    AS7341_REGADDR_AUXID = 0x90,
    AS7341_REGADDR_REVID = 0x91,
    AS7341_REGADDR_ID = 0x92,

    AS7341_REGADDR_STATUS = 0x93,
    AS7341_REGADDR_CH0_DATA = 0x95,
    AS7341_REGADDR_STATUS2 = 0xA3,
    AS7341_REGADDR_STATUS6 = 0xA7,

    AS7341_REGADDR_CFG0 = 0xA9,
    AS7341_REGADDR_CFG1 = 0xAA,
    AS7341_REGADDR_CFG3 = 0xAC,
    AS7341_REGADDR_CFG4 = 0xAD,
    AS7341_REGADDR_CFG6 = 0xAF,
    AS7341_REGADDR_CFG8 = 0xB1,
    AS7341_REGADDR_CFG9 = 0xB2,
    AS7341_REGADDR_CFG10 = 0xB3,
    AS7341_REGADDR_CFG12 = 0xB5,

    AS7341_REGADDR_GPIO2 = 0xBE,

    AS7341_REGADDR_ASTEP = 0xCA,
    AS7341_REGADDR_AGC_GAIN_MAX = 0xCF,

    AS7341_REGADDR_AZCONFIG = 0xD6,
    AS7341_REGADDR_FD_CFG0 = 0xD7,
    AS7341_REGADDR_FD_TIME_L = 0xD8,
    AS7341_REGADDR_FD_TIME_H = 0xDA,

    AS7341_REGADDR_INTENAB = 0xF9,
    AS7341_REGADDR_CONTROL = 0xFA,
    AS7341_REGADDR_FIFO_MAP = 0xFC,
    AS7341_REGADDR_FIFO_LVL = 0xFD,
    AS7341_REGADDR_FDATA_L = 0xFE,
    AS7341_REGADDR_FDATA_H = 0xFF
};

/* SMUX configurations
 *  The diodes are arranged on the chip as following:
 *
 *  |------FLICKER-------|
 *  F1_1  F3_1  F5_2  F7_2
 *  F6_1  F8_1  F2_2  F4_2
 *  F4_1  F2_1  F8_2  F6_2
 *  F7_1  F5_1  F3_2  F1_2
 *  CLR_1    NIR     CLR_2
 *  DARK
 *
 *  - the values below represent the index in the memory map for the SMUX (index of half-bytes, there are only 20 bytes
 *    in the SMUX conf)
 *  - if both diodes of one filter are selected, the indexes will be combined into a 16-Bit word
 *     where the low byte is the index of the first pixel, the high byte is the second pixel
 * */

enum AS7341_SMUX {
    AS7341_SMUX_DISABLE = 0, /*0x00*/

    AS7341_SMUX_F1_1 = 2,     /* Filter F1 Pixel 1 */
    AS7341_SMUX_F1_2 = 32,    /* Filter F1 Pixel 2 */
    AS7341_SMUX_F2_1 = 10,    /* Filter F2 Pixel 1 */
    AS7341_SMUX_F2_2 = 25,    /* Filter F2 Pixel 2 */
    AS7341_SMUX_F3_1 = 1,     /* Filter F3 Pixel 1 */
    AS7341_SMUX_F3_2 = 31,    /* Filter F3 Pixel 2 */
    AS7341_SMUX_F4_1 = 11,    /* Filter F4 Pixel 1 */
    AS7341_SMUX_F4_2 = 26,    /* Filter F4 Pixel 2 */
    AS7341_SMUX_F5_1 = 13,    /* Filter F5 Pixel 1 */
    AS7341_SMUX_F5_2 = 19,    /* Filter F5 Pixel 2 */
    AS7341_SMUX_F6_1 = 8,     /* Filter F6 Pixel 1 */
    AS7341_SMUX_F6_2 = 29,    /* Filter F6 Pixel 2 */
    AS7341_SMUX_F7_1 = 14,    /* Filter F7 Pixel 1 */
    AS7341_SMUX_F7_2 = 20,    /* Filter F7 Pixel 2 */
    AS7341_SMUX_F8_1 = 7,     /* Filter F8 Pixel 1 */
    AS7341_SMUX_F8_2 = 28,    /* Filter F8 Pixel 2 */
    AS7341_SMUX_CLEAR_1 = 17, /* CLEAR Diode Pixel 1 */
    AS7341_SMUX_CLEAR_2 = 35, /* CLEAR Diode Pixel 2 */
    AS7341_SMUX_NIR = 38,     /* NIR Diode  */
    AS7341_SMUX_FLICKER = 39, /* FLICKER Diode */

    AS7341_SMUX_F1 = ((AS7341_SMUX_F1_2 << 8) | AS7341_SMUX_F1_1),          /* Filter F1 both pixels combined */
    AS7341_SMUX_F2 = ((AS7341_SMUX_F2_2 << 8) | AS7341_SMUX_F2_1),          /* Filter F2 both pixels combined */
    AS7341_SMUX_F3 = ((AS7341_SMUX_F3_2 << 8) | AS7341_SMUX_F3_1),          /* Filter F3 both pixels combined */
    AS7341_SMUX_F4 = ((AS7341_SMUX_F4_2 << 8) | AS7341_SMUX_F4_1),          /* Filter F4 both pixels combined */
    AS7341_SMUX_F5 = ((AS7341_SMUX_F5_2 << 8) | AS7341_SMUX_F5_1),          /* Filter F5 both pixels combined */
    AS7341_SMUX_F6 = ((AS7341_SMUX_F6_2 << 8) | AS7341_SMUX_F6_1),          /* Filter F6 both pixels combined */
    AS7341_SMUX_F7 = ((AS7341_SMUX_F7_2 << 8) | AS7341_SMUX_F7_1),          /* Filter F7 both pixels combined */
    AS7341_SMUX_F8 = ((AS7341_SMUX_F8_2 << 8) | AS7341_SMUX_F8_1),          /* Filter F8 both pixels combined */
    AS7341_SMUX_CLEAR = ((AS7341_SMUX_CLEAR_2 << 8) | AS7341_SMUX_CLEAR_1), /* CLEAR Diode both pixels combined */
};

/* USER_CODE END DEFINITIONS */

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/* USER_CODE BEGIN FUNCTIONS */

err_code_t as7341_get_highest_value(uint16_t *p_data, uint32_t number, uint16_t *p_highest);
err_code_t as7341_get_optimized_gain(uint16_t maximum_adc, uint16_t highest_adc, uint8_t lower_gain_limit,
                                     uint8_t upper_gain_limit, uint8_t *p_gain, uint8_t *p_saturation);

err_code_t as7341_open(const osal_id_t osal_id);
err_code_t as7341_close(const osal_id_t osal_id);

err_code_t as7341_get_part_id(const osal_id_t osal_id, uint8_t *p_part_id);

err_code_t as7341_set_atime(const osal_id_t osal_id, uint8_t atime);
err_code_t as7341_get_atime(const osal_id_t osal_id, uint8_t *p_atime);
err_code_t as7341_set_astep(const osal_id_t osal_id, uint16_t astep);
err_code_t as7341_get_astep(const osal_id_t osal_id, uint16_t *p_astep);
err_code_t as7341_set_integration_time_us(const osal_id_t osal_id, uint32_t time_us);
err_code_t as7341_get_integration_time_us(const osal_id_t osal_id, uint32_t *p_time_us);
err_code_t as7341_get_maximum_spectral_adc(osal_id_t osal_id, uint16_t *p_max_adc);

err_code_t as7341_set_wait_time(const osal_id_t osal_id, uint8_t wtime, uint8_t enable, uint8_t long_time);
err_code_t as7341_get_wait_time(const osal_id_t osal_id, uint8_t *p_wtime, uint8_t *p_enable, uint8_t *p_long_time);

err_code_t as7341_set_gain(const osal_id_t osal_id, uint8_t gain);
err_code_t as7341_get_gain(const osal_id_t osal_id, uint8_t *p_gain);
err_code_t as7341_get_saved_gain(osal_id_t osal_id, uint8_t *p_gain);

err_code_t as7341_start(const osal_id_t osal_id, enum AS7341_MEASURE_TYPE type);
err_code_t as7341_stop(const osal_id_t osal_id, enum AS7341_MEASURE_TYPE type);

err_code_t as7341_set_channel_config(const osal_id_t osal_id, uint8_t *p_channel_conf, uint8_t size);
err_code_t as7341_get_channel_config(const osal_id_t osal_id, uint8_t *p_channel_conf, uint8_t size);

err_code_t as7341_switch_channels(const osal_id_t osal_id, uint8_t block);
err_code_t as7341_get_channel_data(const osal_id_t osal_id, uint16_t *p_channel_data, uint8_t size);
err_code_t as7341_is_data_ready(const osal_id_t osal_id, uint8_t *p_state);

err_code_t as7341_get_serial(const osal_id_t osal_id, uint32_t *p_timestamp, uint32_t *p_tester_id);

err_code_t as7341_set_autozero(const osal_id_t osal_id, uint8_t autozero);
err_code_t as7341_get_autozero(const osal_id_t osal_id, uint8_t *p_autozero);
err_code_t as7341_get_internal_autozero(const osal_id_t osal_id, uint8_t *p_autozero);

err_code_t as7341_set_led(const osal_id_t osal_id, uint8_t config);
err_code_t as7341_get_led(const osal_id_t osal_id, uint8_t *p_config);

err_code_t as7341_set_sync_mode(osal_id_t osal_id, uint8_t enable);
err_code_t as7341_get_sync_mode(osal_id_t osal_id, uint8_t *p_enable);

err_code_t as7341_set_oc_output_low(const osal_id_t osal_id, uint8_t is_low);
err_code_t as7341_get_oc_output_low(const osal_id_t osal_id, uint8_t *p_is_low);

err_code_t as7341_activate_interrupt(const osal_id_t osal_id, uint8_t interrupt);
err_code_t as7341_reset_interrupt(const osal_id_t osal_id, uint8_t interrupt);

err_code_t as7341_is_second_smux_conf_available(const osal_id_t osal_id, uint8_t *p_state);

err_code_t as7341_configure_flicker(osal_id_t osal_id);
err_code_t as7341_get_flicker_data(osal_id_t osal_id, uint8_t *p_flicker_data, uint8_t *p_size);

err_code_t as7341_set_ftime(osal_id_t osal_id, uint16_t ftime);
err_code_t as7341_get_ftime(osal_id_t osal_id, uint16_t *p_ftime);
err_code_t as7341_get_saved_ftime(osal_id_t osal_id, uint16_t *p_ftime);
err_code_t as7341_set_fifo_integration_time_us(osal_id_t osal_id, uint32_t time_us);
err_code_t as7341_get_fifo_integration_time_us(osal_id_t osal_id, uint32_t *p_time_us);
err_code_t as7341_get_maximum_fifo_adc(osal_id_t osal_id, uint16_t *p_max_adc);
err_code_t as7341_set_fgain(osal_id_t osal_id, uint8_t fgain);
err_code_t as7341_get_fgain(osal_id_t osal_id, uint8_t *p_fgain);
err_code_t as7341_get_saved_fgain(osal_id_t osal_id, uint8_t *p_fgain);

err_code_t as7341_set_fchannels(osal_id_t osal_id, uint32_t fchannels);
err_code_t as7341_get_fchannels(osal_id_t osal_id, uint32_t *p_fchannels);
err_code_t as7341_set_fsmux(osal_id_t osal_id);

/* USER_CODE END FUNCTIONS */

#endif /* __AS7341_INTERFACE_H__ */
