/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_TYPEDEFS_H__
#define __AS7341_TYPEDEFS_H__

/*!
 * \file      as7341_typedefs.h
 * \authors   ARIT
 * \copyright ams
 * \addtogroup definition_group
 *
 * \brief Description of the used data types.
 *
 * These are the type definitions used by AS7341 chip library.
 *
 *  @{
 */

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"
#include "spectral_osal_chiplib.h"

/* USER_CODE BEGIN INCLUDES */

/* USER_CODE END INCLUDES */

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

/* USER_CODE BEGIN DEFINITIONS */

/*! ChipLib identification */
#define CHIP_LIB_IDENT 7341

/*! Number of supported LED pattern configuration */
#define AS7341_LED_PATTERN_NUM 10

/*! Maximum size in bytes of additional item buffer in callback function */
#define AS7341_MAX_ITEM_BUFFER_SIZE 80

/*! Maximum size in bytes of data buffer in callback function */
#define AS7341_MAX_DATA_BUFFER_SIZE 256

/*! Number of supported gains */
#define AS7341_GAIN_FACTOR_NUM 11

/*! Measured ADC value is saturated */
#define AS7341_SATURATED 65535

/*! List of supported measurement types for  ::ITEM_ID_MEAS_TYPE */
enum as7341_measurement_types {
    MEASUREMENT_TYPE_SPECTRAL = 0, /*!< Spectral measurement: Measures six chanels in parallel, otherwise you can
                                      measure 12 channels in two blocks a 6 chanels (twice integration time!). */
    MEASUREMENT_TYPE_FIFO = 1, /*!< FIFO measurement: Measures with one ADC only in fast FIFO mode: It is possible to
                                  map more than one channel to this ADC. */

    MEASUREMENT_TYPE_NUM = 2 /*!< Maximum supported measurement types. */
};

/*! Supported channel types for spectral channels. Used to ::ITEM_ID_CHANNELS. */
enum as7341_channels {
    CHANNEL_DISABLED = 0, /*!< place holder for unused channels */
    CHANNEL_F1 = 1,       /*!< channel F1 */
    CHANNEL_F2 = 2,       /*!< channel F2 */
    CHANNEL_F3 = 3,       /*!< channel F3 */
    CHANNEL_F4 = 4,       /*!< channel F4 */
    CHANNEL_F5 = 5,       /*!< channel F5 */
    CHANNEL_F6 = 6,       /*!< channel F6 */
    CHANNEL_F7 = 7,       /*!< channel F7 */
    CHANNEL_F8 = 8,       /*!< channel F8 */
    CHANNEL_NIR = 9,      /*!< channel NIR */
    CHANNEL_CLEAR = 10,   /*!< channel CLEAR */
    CHANNEL_FLICKER = 11, /*!< channel FLICKER */

    CHANNEL_NUMBER = 12 /*!< maximum number of supported channel types */
};

/*! Supported gains for items ::ITEM_ID_AGAIN and ::ITEM_ID_FGAIN to set the spectral sensitivity. */
enum as7341_gain {
    GAIN_0_5X = 0,  /*!< gain of 0.5x */
    GAIN_1X = 1,    /*!< gain of 1x */
    GAIN_2X = 2,    /*!< gain of 2x */
    GAIN_4X = 3,    /*!< gain of 4x */
    GAIN_8X = 4,    /*!< gain of 8x */
    GAIN_16X = 5,   /*!< gain of 16x */
    GAIN_32X = 6,   /*!< gain of 32x */
    GAIN_64X = 7,   /*!< gain of 64x */
    GAIN_128X = 8,  /*!< gain of 128x*/
    GAIN_256X = 9,  /*!< gain of 256x */
    GAIN_512X = 10, /*!< gain of 512x */
};

/*! This masks will be used to configure the FIFO channel. More than one can be configured on the same time. \see
 * ::ITEM_ID_FCHANNELS */
enum as7341_fifo_channels {
    FCHANNEL_F1_1_MASK = (1 << 0),     /*!< Filter F1 Pixel 1 */
    FCHANNEL_F1_2_MASK = (1 << 1),     /*!< Filter F1 Pixel 2 */
    FCHANNEL_F2_1_MASK = (1 << 2),     /*!< Filter F2 Pixel 1 */
    FCHANNEL_F2_2_MASK = (1 << 3),     /*!< Filter F2 Pixel 2 */
    FCHANNEL_F3_1_MASK = (1 << 4),     /*!< Filter F3 Pixel 1 */
    FCHANNEL_F3_2_MASK = (1 << 5),     /*!< Filter F3 Pixel 2 */
    FCHANNEL_F4_1_MASK = (1 << 6),     /*!< Filter F4 Pixel 1 */
    FCHANNEL_F4_2_MASK = (1 << 7),     /*!< Filter F4 Pixel 2 */
    FCHANNEL_F5_1_MASK = (1 << 8),     /*!< Filter F5 Pixel 1 */
    FCHANNEL_F5_2_MASK = (1 << 9),     /*!< Filter F5 Pixel 2 */
    FCHANNEL_F6_1_MASK = (1 << 10),    /*!< Filter F6 Pixel 1 */
    FCHANNEL_F6_2_MASK = (1 << 11),    /*!< Filter F6 Pixel 2 */
    FCHANNEL_F7_1_MASK = (1 << 12),    /*!< Filter F7 Pixel 1 */
    FCHANNEL_F7_2_MASK = (1 << 13),    /*!< Filter F7 Pixel 2 */
    FCHANNEL_F8_1_MASK = (1 << 14),    /*!< Filter F8 Pixel 1 */
    FCHANNEL_F8_2_MASK = (1 << 15),    /*!< Filter F8 Pixel 2 */
    FCHANNEL_CLEAR_1_MASK = (1 << 16), /*!< CLEAR Diode Pixel 1 */
    FCHANNEL_CLEAR_2_MASK = (1 << 17), /*!< CLEAR Diode Pixel 2 */
    FCHANNEL_NIR_MASK = (1 << 18),     /*!< NIR Diode */
    FCHANNEL_FLICKER_MASK = (1 << 19)  /*!< FLICKER Diode */
};

/*! This bit masks will be used for configuration of the LED pattern. \see ::ITEM_ID_LED_PATTERN */
enum as7341_led_masks {
    LED_MASK_OFF = 0x00,    /*!< mask that no LED will be set */
    LED_MASK_INTERN = 0x01, /*!< mask that the internal LED will be set */
    LED_MASK_EXT_0 = 0x02,  /*!< mask that the external LED 0 will be set */
    LED_MASK_EXT_1 = 0x04,  /*!< mask that the external LED 1 will be set */
    LED_MASK_EXT_2 = 0x08,  /*!< mask that the external LED 2 will be set */
    LED_MASK_EXT_3 = 0x10,  /*!< mask that the external LED 3 will be set */
    LED_MASK_EXT_4 = 0x20,  /*!< mask that the external LED 4 will be set */
    LED_MASK_EXT_5 = 0x40,  /*!< mask that the external LED 5 will be set */
    LED_MASK_OUTPUT = 0x80, /*!< mask that the output pin will be set */
};

/*! Payload definition of item ::ITEM_ID_SERIAL */
struct as7341_serial {
    uint32_t timestamp; /*!< unix timestamp of manufacturing time */
    uint32_t id;        /*!< For parallel production, this ID makes the timestamp unique. */
};

/*! Payload definition of item ::ITEM_ID_VERSION */
struct as7341_version {
    uint8_t major; /*!< first position of version data: major version number */
    uint8_t minor; /*!< second position of version data: minor version number */
    uint8_t patch; /*!< third position of version data: patch version number */
    uint8_t build; /*!< fourth position of version data: build version number */
};

/*! Definition for ::ITEM_ID_LED_PATTERN.
This is used to switch the LEDs synchronized to the spectral measurement. During the measurement, the LED can only be
switched on or off. The current must be configured with ::as7341_led_config. */
struct as7341_led_pattern {
    uint8_t count;  /*!< Defines how often the current LED configuration will be used. */
    uint8_t config; /*!< Select the LEDs for the next measurement cycles. See ::as7341_led_masks. */
};

/*! Configuration of the LEDs with help of ::ITEM_ID_LED_INTERN, ::ITEM_ID_LED_EXT_0 ... */
struct as7341_led_config {
    uint16_t enable;     /*!< Unequal zero means that LED shall be enabled, otherwise disabled. */
    uint16_t brightness; /*!< Brightness value in per mile (0 - 1000) */
};

/*! Configuration of the auto gain algorithm */
struct as7341_auto_gain {
    uint8_t lower_limit; /*!< See enumeration ::as7341_gain */
    uint8_t upper_limit; /*!< See enumeration ::as7341_gain */
};

/*! List of all supported item IDs */
enum as7341_item_ids {
    ITEM_ID_RESERVED = 0, /*!< This ID will be used for special cases, like detection of undefined item. */

    /*!
     * This item access directly the register ASTEP 0xCA/0xCB.
     * Those registers are one of the two parts which allows the
     * user to set the integration time for spectral measurement.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_ASTEP (unsigned 16bit)
     * - <em>Parameter range:</em> 1 - 65534
     * - <em>Default value:</em> 599
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint16_t astep_set, astep_get;
     *
     * // set ASTEP-property
     * astep_set = 999;
     * as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep_set, ITEM_SIZE_ASTEP);
     *
     * // get ASTEP-property
     * as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep_get, ITEM_SIZE_ASTEP);
     *
     * \endcode
     *
     * \note If you want to set the integration time in microseconds directly, use ::ITEM_ID_ITIME.
     * Here you can find additional information as well.
     */
    ITEM_ID_ASTEP = 1,

    /*!
     * This item accesses directly the AS7341 ATIME-register 0x81.
     *
     * ATIME is the second part to calculate the integration time.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_ATIME (unsigned 8bit)
     * - <em>Parameter range:</em> 0 - 255
     * - <em>Default value:</em> 29
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t atime_set, atime_get;
     *
     * // set ATIME-property
     * atime_set = 19;
     * as7341_set_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime_set, ITEM_SIZE_ATIME);
     *
     * // get ATIME-property
     * as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime_get, ITEM_SIZE_ATIME);
     *
     * \endcode
     *
     * \note If you want to set the integration time in microseconds directly, use ::ITEM_ID_ITIME.
     * Here you can find additional information as well.
     */
    ITEM_ID_ATIME = 2,

    /*!
     * This item calculates the integration time in microseconds. Internally, the registers ATIME and ASTEP will be set.
     * Following formula describes the relationship:
     * \n
     * \n
     * \f$ t_{int} = (ATIME + 1) * (ASTEP + 1) * (2000 / 720)us \f$
     * \n
     * \n
     * The maximum possible ADC fullscale range has a width of 16bit, but is limited by the integration time:
     * \n
     * \n
     * \f$ ADC_{fullscale} = (ATIME + 1) * (ASTEP + 1) \f$
     * \n
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_ITIME (unsigned 32bit)
     * - <em>Parameter range:</em> 6 - 46602667
     * - <em>Default value:</em> 50000
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint32_t itime_set, itime_get;
     *
     * // set ITIME-property
     * itime_set = 40000;
     * as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime_set, ITEM_SIZE_ITIME);
     *
     * // get ITIME-property
     * as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime_get, ITEM_SIZE_ITIME);
     *
     * \endcode
     *
     * \attention It is normal that the value which you readback differs from the set value, because it depends on
     * the resolution of ASTEP and ATIME
     */
    ITEM_ID_ITIME = 3,

    /*!
     * This item accesses directly the AS7341 CFG_1-register (0xAA) bits AGAIN to change the spectral sensitivity.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_AGAIN (unsigned 8bit)
     * - <em>Parameter range:</em> see ::as7341_gain
     * - <em>Default value:</em> ::GAIN_256X
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t again_set, again_get;
     *
     * // set AGAIN-property
     * again_set = GAIN_16X;
     * as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&again_set, ITEM_SIZE_AGAIN);
     *
     * // get AGAIN-property
     * as7341_get_item(DEV_ID, ITEM_ID_AGAIN, (void *)&again_get, ITEM_SIZE_AGAIN);
     *
     * \endcode
     */
    ITEM_ID_AGAIN = 4,

    /*!
     * This item configures the measurement typ. (::as7341_measurement_types)
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_MEAS_TYPE (unsigned 8bit)
     * - <em>Parameter range:</em> see ::as7341_measurement_types
     * - <em>Default value:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t meas_type_set, meas_type_get;
     *
     * // set MEAS_TYPE-property
     * meas_type_set = MEASUREMENT_TYPE_FIFO;
     * as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, (void *)&meas_type_set, ITEM_SIZE_MEAS_TYPE);
     *
     * // get MEAS_TYPE-property
     * as7341_get_item(DEV_ID, ITEM_ID_MEAS_TYPE, (void *)&meas_type_get, ITEM_SIZE_MEAS_TYPE);
     *
     * \endcode
     *
     * \see ::as7341_measurement_types
     */
    ITEM_ID_MEAS_TYPE = 5,

    /*!
     * This item specifies the break between the finished measurement and the start of the next measurement.
     *
     * On default this time is disabled and not used. This time depends on the integration time of the sensor because
     * the value will be calculated by the difference of wait_time and integration_time-registers.
     *
     * If you want to readout the real configured break time, you must set integration time at first, then set break
     * time itself and afterwards read it back.
     *
     * The maximum time of integration is much higher than the maximum possible wait time registers. So, you can't set
     * the break time in all cases. To use this break time, decrease the integration time.
     *
     * \note The minimum possible break time is 2780us.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_BREAK (unsigned 32bit)
     * - <em>Parameter range:</em> 0, 2780us - 10000000us
     * - <em>Default value:</em> 0
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint32_t break_set, break_get;
     *
     * // set BREAK-property
     * break_set = 50000; 50ms
     * as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_set, ITEM_SIZE_BREAK);
     *
     * // get BREAK-property
     * as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_get, ITEM_SIZE_BREAK);
     *
     * \endcode
     */
    ITEM_ID_BREAK = 6,

    /*!
     * Configures up to twelve measurement channels, each byte for one channel.
     * If more than 6 channels are configured internally a double measurement is triggered.
     * The possible values for every byte are described in ::as7341_channels.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_CHANNELS (unsigned 12byte)
     * - <em>Parameter range:</em> ::as7341_channels
     * - <em>Default value:</em>
     * ::CHANNEL_F1,     ::CHANNEL_F2,       ::CHANNEL_F3,  ::CHANNEL_F4,
     * ::CHANNEL_CLEAR,  ::CHANNEL_FLICKER,  ::CHANNEL_F5,  ::CHANNEL_F6,
     * ::CHANNEL_F7,     ::CHANNEL_F8,       ::CHANNEL_NIR, ::CHANNEL_FLICKER
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * // configure a single measuremt with 6 channels only
     * uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1, CHANNEL_F2, CHANNEL_F3, CHANNEL_F4,
     *     CHANNEL_F5, CHANNEL_F6, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED,
     *     CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};
     *
     * // set CHANNELS-property
     * as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, (void *)channels, ITEM_SIZE_CHANNELS);
     *
     * // get CHANNELS-property
     * as7341_get_item(DEV_ID, ITEM_ID_CHANNELS, (void *)channels, ITEM_SIZE_CHANNELS);
     *
     * \endcode
     *
     * \see ::as7341_channels
     */
    ITEM_ID_CHANNELS = 7,

    /*!
     * Every byte describes one version position: MAJOR MINOR PATCH BUILD. See structure ::as7341_version.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_VERSION (unsigned 4byte)
     * - <em>Parameter range:</em> 0 - 255, 4 times
     * - <em>Default value:</em> no default
     * - <em>Direction:</em> read only
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_version version;
     *
     * as7341_get_item(DEV_ID, ITEM_ID_VERSION, (void *)&version, ITEM_SIZE_VERSION);
     *
     * \endcode
     *
     * \see ::as7341_version
     */
    ITEM_ID_VERSION = 8,

    /*!
     * Unique chip identifier. See structure ::as7341_serial.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_SERIAL, see ::as7341_serial
     * - <em>Parameter range:</em> see definition of ::as7341_serial
     * - <em>Default value:</em> no default
     * - <em>Direction:</em> read only
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_serial serial;
     *
     * as7341_get_item(DEV_ID, ITEM_ID_SERIAL, (void *)&serial, ITEM_SIZE_SERIAL);
     *
     * \endcode
     *
     * \see ::as7341_serial
     */
    ITEM_ID_SERIAL = 9,

    /*!
     * This item accesses directly the AS7341 AZ_CONFIG-register 0xD6.
     *
     * The register configures how often the spectral engine offsets are reset (auto zero) to
     * compensate for changes of the device temperature. The typical time auto zero needs to be completed
     * is 15ms.
     *
     * Parameter description:
     * - 0: Never used
     * - 1: Every integration cycle
     * - 2: Every 2 integration cycle
     * - ...
     * - 254: Every 254 cycles
     * - 255: Only before first measurement
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_AUTOZERO (unsigned 8bit)
     * - <em>Parameter range:</em> 0 - 255
     * - <em>Default value:</em> 255
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t autozero_set, autozero_get;
     *
     * // set AUTOZERO-property
     * autozero_set = 0;
     * as7341_set_item(DEV_ID, ITEM_ID_AUTOZERO, (void *)&autozero_set, ITEM_SIZE_AUTOZERO);
     *
     * // get AUTOZERO-property
     * as7341_get_item(DEV_ID, ITEM_ID_AUTOZERO, (void *)&autozero_get, ITEM_SIZE_AUTOZERO);
     *
     * \endcode
     *
     * \attention The defintion of this item is valid, if at maximum 6 channels are configured. If more than 6 channels
     * are used, auto zero will be restarted after every channel reconfiguration.
     * That means, that value 1 - 255 has the same effect: Auto zero is used on every measurement.
     */
    ITEM_ID_AUTOZERO = 10,

    /*!
     * Configured the number of measurements, 0 means continuous measurement.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL, ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_MEAS_COUNT (unsigned 16bit)
     * - <em>Parameter range:</em> 0 - 65535
     * - <em>Default value:</em> 0 (continuous measurement)
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint16_t meas_count_set, meas_count_get;
     *
     * // set MEAS_COUNT-property
     * meas_count_set = 5;
     * as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (void *)&meas_count_set, ITEM_SIZE_MEAS_COUNT);
     *
     * // get MEAS_COUNT-property
     * as7341_get_item(DEV_ID, ITEM_ID_MEAS_COUNT, (void *)&meas_count_get, ITEM_SIZE_MEAS_COUNT);
     *
     * \endcode
     */
    ITEM_ID_MEAS_COUNT = 11,

    /*!
     * With the help of the structure ::as7341_led_pattern LEDs can be switched synchronously to the measurement.
     * Inside the structure can be defined how long a specifc LED configuration shall be used.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_PATTERN (size of structure ::as7341_led_pattern, 10x)
     * - <em>Parameter range:</em> count: 0 - 255, config: see ::as7341_led_masks
     * - <em>Default value:</em> count: 0, config: LED_MASK_OFF
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {0, 0};
     *
     * // configure the LED pattern:
     * // first two measurements: LEDs off,
     * led_pattern[0].config = LED_MASK_OFF;
     * led_pattern[0].count = 2;
     * // next three measurements: internal LED activated
     * led_pattern[1].config = LED_MASK_INTERN;
     * led_pattern[1].count = 3;
     * // next four measurements: internal LED and external LED_0 are activated
     * led_pattern[2].config = LED_MASK_EXT_0 | LED_MASK_INTERN;
     * led_pattern[2].count = 4;
     *
     * // set LED_PATTERN-property
     * as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (void *)led_pattern, ITEM_SIZE_LED_PATTERN);
     *
     * // get LED_PATTERN-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_PATTERN, (void *)led_pattern, ITEM_SIZE_LED_PATTERN);
     *
     * \endcode
     */
    ITEM_ID_LED_PATTERN = 12,

    /*!
     * Set warm up time in microseconds for synchronized LED switching.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_WAIT_TIME (unsigned 32bit)
     * - <em>Parameter range:</em> 0us - 10s
     * - <em>Default value:</em> 100000 (100ms)
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint32_t warm_up_time_set, warm_up_time_get;
     *
     * // set LED_WAIT_TIME-property
     * warm_up_time_set = 0;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_WAIT_TIME, (void *)&warm_up_time_set, ITEM_SIZE_LED_WAIT_TIME);
     *
     * // get LED_WAIT_TIME-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_WAIT_TIME, (void *)&warm_up_time_get, ITEM_SIZE_LED_WAIT_TIME);
     *
     * \endcode
     */
    ITEM_ID_LED_WAIT_TIME = 13,

    /*!
     * Unequal zero means that the interrupt pin will be used, otherwise the time of integration will be calculated
     * internally.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL, ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_INTERRUPT_PIN (unsigned 8bit)
     * - <em>Parameter range:</em> 0 - 1
     * - <em>Default value:</em> 0
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t interrupt_pin_set, interrupt_pin_get;
     *
     * // set INTERRUPT_PIN-property
     * interrupt_pin_set = 1;
     * as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, (void *)&interrupt_pin_set, ITEM_SIZE_INTERRUPT_PIN);
     *
     * // get INTERRUPT_PIN-property
     * as7341_get_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, (void *)&interrupt_pin_get, ITEM_SIZE_INTERRUPT_PIN);
     *
     * \endcode
     */
    ITEM_ID_INTERRUPT_PIN = 14,

    /*!
     * Configures the internal LED with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_INTERN (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_INTERN-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&config_set, ITEM_SIZE_LED_INTERN);
     *
     * // get LED_INTERN-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&config_get, ITEM_SIZE_LED_INTERN);
     *
     * \endcode
     */
    ITEM_ID_LED_INTERN = 15,

    /*!
     * Configures the external LED 0 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_0 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_0-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_0, (void *)&config_set, ITEM_SIZE_LED_EXT_0);
     *
     * // get LED_EXT_0-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_0, (void *)&config_get, ITEM_SIZE_LED_EXT_0);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_0 = 16,

    /*!
     * Configures the external LED 1 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_1 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_1-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&config_set, ITEM_SIZE_LED_EXT_1);
     *
     * // get LED_EXT_1-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&config_get, ITEM_SIZE_LED_EXT_1);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_1 = 17,

    /*!
     * Configures the external LED 2 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_2 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_2-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_2, (void *)&config_set, ITEM_SIZE_LED_EXT_2);
     *
     * // get LED_EXT_2-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_2, (void *)&config_get, ITEM_SIZE_LED_EXT_2);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_2 = 18,

    /*!
     * Configures the external LED 3 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_3 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_3-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_3, (void *)&config_set, ITEM_SIZE_LED_EXT_3);
     *
     * // get LED_EXT_3-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_3, (void *)&config_get, ITEM_SIZE_LED_EXT_3);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_3 = 19,

    /*!
     * Configures the external LED 4 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_4 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_4-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_4, (void *)&config_set, ITEM_SIZE_LED_EXT_4);
     *
     * // get LED_EXT_4-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_4, (void *)&config_get, ITEM_SIZE_LED_EXT_4);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_4 = 20,

    /*!
     * Configures the external LED 5 with help of structure ::as7341_led_config.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_LED_EXT_5 (twice unsigned 16bit)
     * - <em>Parameter range:</em> see ::as7341_led_config
     * - <em>Default value:</em> enable: 0, brightness: 100
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_led_config config_set, config_get;
     *
     * // set LED_EXT_5-property
     * config_set.enable = 1;
     * config_set.brightness = 1000;
     * as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_5, (void *)&config_set, ITEM_SIZE_LED_EXT_5);
     *
     * // get LED_EXT_5-property
     * as7341_get_item(DEV_ID, ITEM_ID_LED_EXT_5, (void *)&config_get, ITEM_SIZE_LED_EXT_5);
     *
     * \endcode
     */
    ITEM_ID_LED_EXT_5 = 21,

    /*!
     * The output is configured as an open collector. On default the output is HI-Z and is disconnected.
     * Unequal zero means that the output pin drives low.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_OUTPUT (unsigned 8bit)
     * - <em>Parameter range:</em> 0 (HI-Z) - 1 (GND)
     * - <em>Default value:</em> 0 (HI-Z)
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t output_set, output_get;
     *
     * // set OUTPUT-property
     * output_set = 1
     * as7341_set_item(DEV_ID, ITEM_ID_OUTPUT, (void *)&output_set, ITEM_SIZE_OUTPUT);
     *
     * // get OUTPUT-property
     * as7341_get_item(DEV_ID, ITEM_ID_OUTPUT, (void *)&output_get, ITEM_SIZE_OUTPUT);
     *
     * \endcode
     */
    ITEM_ID_OUTPUT = 22,

    /*!
     * Get the temperature of an external sensor 0 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_0 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_0-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_0, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_0);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_0 = 23,

    /*!
     * Get the temperature of an external sensor 1 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_1 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_1-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_1, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_1);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_1 = 24,

    /*!
     * Get the temperature of an external sensor 2 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_2 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_2-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_2, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_2);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_2 = 25,

    /*!
     * Get the temperature of an external sensor 3 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_3 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_3-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_3, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_3);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_3 = 26,

    /*!
     * Get the temperature of an external sensor 4 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_4 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_4-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_4, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_4);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_4 = 27,

    /*!
     * Get the temperature of an external sensor 5 in millidegree.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TEMP_EXT_5 (signed 32bit)
     * - <em>Parameter range:</em> depends on OSAL implementation (typical -40000 ... 125000)
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read
     *
     * \b Example
     * \n
     * \code
     *
     * int32_t millidegree_get;
     *
     * // get TEMP_EXT_5-property
     * as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_5, (void *)&millidegree_get, ITEM_SIZE_TEMP_EXT_5);
     *
     * \endcode
     */
    ITEM_ID_TEMP_EXT_5 = 28,

    /*!
     * Item describes additional measurement data. The list can be fullfilled with any
     * item which shall be readout synchronized to the measurement. Those item content will be transferred with the
     * callback function.
     *
     * \note The maximum supported buffer size in callback function is ::AS7341_MAX_ITEM_BUFFER_SIZE.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL, ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_MEASURE_ITEMS (10x unsigned 8bit)
     * - <em>Parameter range:</em> 0 .. ::ITEM_ID_MAX - 1
     * - <em>Default value:</em> ::ITEM_ID_RESERVED (10 times)
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_RESERVED};
     *
     * // set MEASURE_ITEMS-property: added items for temperature sensor
     * // and gain to cyclic measurement data
     * measure_items[0] = ITEM_ID_TEMP_EXT_0;
     * measure_items[1] = ITEM_ID_AGAIN;
     * as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, (void *)&measure_items, ITEM_SIZE_MEASURE_ITEMS);
     *
     * // get MEASURE_ITEMS-property
     * as7341_get_item(DEV_ID, ITEM_ID_MEASURE_ITEMS (void *)&measure_items, ITEM_SIZE_MEASURE_ITEMS);
     *
     * \endcode
     */
    ITEM_ID_MEASURE_ITEMS = 29,

    /*!
     * Configures the GAIN for fast FIFO measurement mode. Internally, the register FD_TIME_2 is used.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_FGAIN (unsigned 8bit)
     * - <em>Parameter range:</em> see ::as7341_gain
     * - <em>Default value:</em> ::GAIN_16X
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t fgain_set, fgain_get;
     *
     * // set FGAIN-property
     * fgain_set = GAIN_256X;
     * as7341_set_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain_set, ITEM_SIZE_FGAIN);
     *
     * // get FGAIN-property
     * as7341_get_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain_get, ITEM_SIZE_FGAIN);
     *
     * \endcode
     */
    ITEM_ID_FGAIN = 30,

    /*!
     * Configures the integration time for fast FIFO measurement mode:
     * This parameter sets the I2C registers FD_TIME_1 and FD_TIME_2 directly.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_FTIME (unsigned 16bit)
     * - <em>Parameter range:</em> 0 - 0x07FF
     * - <em>Default value:</em> 359
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint16_t ftime_set, ftime_get;
     *
     * // set FTIME-property
     * ftime_set = 179;
     * as7341_set_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime_set, ITEM_SIZE_FTIME);
     *
     * // get FTIME-property
     * as7341_get_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime_get, ITEM_SIZE_FTIME);
     *
     * \endcode
     *
     * \see ::ITEM_ID_FTIME_US
     */
    ITEM_ID_FTIME = 31,

    /*!
     * Configures the integration time for fast FIFO measurement mode in microseconds.
     *
     * Following formula describes the relationship:
     * \n
     * \n
     * \f$ t_{int} = (FD\_TIME + 1) * (2000 / 720)us \f$
     * \n
     * \n
     * The maximum possible ADC fullscale range has a width of 16bit, but is limited by the integration time:
     * \n
     * \n
     * \f$ ADC_{fullscale} = FD\_TIME + 1 \f$
     * \n
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_FTIME_US (unsigned 32bit)
     * - <em>Parameter range:</em> 3us - 5689us
     * - <em>Default value:</em> 1000us
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint32_t ftime_us_set, ftime_us_get;
     *
     * // set FTIME_US-property
     * ftime_set = 500; // set to 500us == 2kHz
     * as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us_set, ITEM_SIZE_FTIME_US);
     *
     * // get FTIME_US-property
     * as7341_get_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us_get, ITEM_SIZE_FTIME_US);
     *
     * \endcode
     */
    ITEM_ID_FTIME_US = 32,

    /*!
     * Configures the channels for FIFO measurement mode.
     * More than one channel can be configured. In such cases all channels will be measured with one ADC.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_FCHANNELS (unsigned 32bit)
     * - <em>Parameter range:</em> see ::as7341_fifo_channels
     * - <em>Default value:</em> FCHANNEL_FLICKER_MASK
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint32_t fchannels_set, fchannels_get;
     *
     * // set FCHANNELS-property
     * fchannels_set = FCHANNEL_F5_1_MASK | FCHANNEL_F5_2_MASK | FCHANNEL_F6_1_MASK | FCHANNEL_F6_2_MASK;
     * as7341_set_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels_set, ITEM_SIZE_FCHANNELS);
     *
     * // get FCHANNELS-property
     * as7341_get_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels_get, ITEM_SIZE_FCHANNELS);
     *
     * \endcode
     */
    ITEM_ID_FCHANNELS = 33,

    /*!
     * Reads a microseconds timestamp. It can be used to get accurate time difference between to measurements.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> -
     * - <em>Payload size:</em> ::ITEM_SIZE_TIMESTAMP (unsigned 64bit)
     * - <em>Parameter range:</em> full 64bit range
     * - <em>Default value:</em> -
     * - <em>Direction:</em> read only
     *
     * \b Example
     * \n
     * \code
     *
     * uint64_t timestamp_get;
     *
     * // get TIMESTAMP-property
     * as7341_get_item(DEV_ID, ITEM_ID_TIMESTAMP, (void *)&timestamp_get, ITEM_SIZE_TIMESTAMP);
     *
     * \endcode
     */
    ITEM_ID_TIMESTAMP = 34,

    /*!
     * Enables or disables the automatic gain control, If lower and upper limit are different and the lower value is
     * lower than the upper one, auto gain is enabled. In this case the gain will be changed automatically.
     * The algorithm tries to map the highest ADC-value to 80% of the maximum.
     * The configured default gain of item ::ITEM_ID_AGAIN or ::ITEM_ID_FGAIN will be used as start value. If this value
     * is out of the configured range, then the lower limit will be used instead.
     * Dependent on the current measurement mode, the item sets ::ITEM_ID_AGAIN or ::ITEM_ID_FGAIN will be set
     * internally.
     *
     * \note It's usefull to configure the item ::ITEM_ID_MEASURE_ITEMS with ::ITEM_ID_AGAIN or ::ITEM_ID_FGAIN to
     * normalize the measured data in the application software.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL, ::MEASUREMENT_TYPE_FIFO
     * - <em>Payload size:</em> ::ITEM_SIZE_AUTO_GAIN_RANGE (see ::as7341_auto_gain)
     * - <em>Parameter range:</em> see ::as7341_gain
     * - <em>Default value:</em> ::GAIN_0_5X, ::GAIN_0_5X
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * struct as7341_auto_gain auto_gain;
     *
     * // Enable auto gain over the whole range.
     * auto_gain.lower_limit = GAIN_0_5X;
     * auto_gain.upper_limit = GAIN_512X,
     * as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE);
     *
     * \endcode
     */
    ITEM_ID_AUTO_GAIN_RANGE = 35,

    /*!
     * The sensor AS7341 has a gain error over the whole area. If the gain will be increased by one, the measured value
     * is not exact the double. To compensate this behavior, the measured values will be multiplied with a correction
     * factor. The default values are used from the datasheet but can be changed.
     *
     * The given factors will be divided by 10000 internally to get the right factor with four decimal places.
     *
     * \note The feature can be disabled by setting all factors to 10000.
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> ::ITEM_SIZE_GAIN_FACTORS (11x unsigned short)
     * - <em>Parameter range:</em> 1 - 20000
     * - <em>Default value:</em> 9770, 9770, 9770, 9620, 10000, 10000, 10000, 10000, 10000, 10130, 10320 (gain
     * ::GAIN_0_5X - ::GAIN_512X)
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint16_t gain_factors[AS7341_GAIN_FACTOR_NUM];
     *
     * // Read gain factors
     * as7341_get_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)gain_factors, ITEM_SIZE_GAIN_FACTORS);
     *
     * \endcode
     */
    ITEM_ID_GAIN_FACTORS = 36,

    /*!
     * The spectral measurement can be synchronized externally. ChipLib supports SYNS-mode. See datasheet for more
     * information. An external falling edge triggers a new measurement.
     *
     * \attention The GPIO pin can be used for multiple functions. The ChipLib supports output-pin to trigger external
     * LEDs. If this feature is used, external synchronization must not be enabled!
     *
     * \n
     * \b Properties
     * - <em>Measurement mode:</em> ::MEASUREMENT_TYPE_SPECTRAL
     * - <em>Payload size:</em> 1 (unsigned char)
     * - <em>Parameter range:</em> 0 - 1
     * - <em>Default value:</em> 0
     * - <em>Direction:</em> write/read
     *
     * \b Example
     * \n
     * \code
     *
     * uint8_t sync_enable = 1;
     *
     * // enable sync mode
     * as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&sync_enable, ITEM_SIZE_SYNC_MODE);
     *
     * \endcode
     */
    ITEM_ID_SYNC_MODE = 37,

    ITEM_ID_MAX = 38 /*!< Internal definition of maximum supported items. */
};

/*! List, which describes the supported length of every item. */
enum as7341_item_sizes {
    ITEM_SIZE_RESERVED = 0,        /*!< size in bytes of item ITEM_ID_RESERVED */
    ITEM_SIZE_ASTEP = 2,           /*!< size in bytes of item ITEM_ID_ASTEP */
    ITEM_SIZE_ATIME = 1,           /*!< size in bytes of item ITEM_ID_ATIME */
    ITEM_SIZE_ITIME = 4,           /*!< size in bytes of item ITEM_ID_ITIME */
    ITEM_SIZE_AGAIN = 1,           /*!< size in bytes of item ITEM_ID_AGAIN */
    ITEM_SIZE_MEAS_TYPE = 1,       /*!< size in bytes of item ITEM_ID_MEAS_TYPE */
    ITEM_SIZE_BREAK = 4,           /*!< size in bytes of item ITEM_ID_BREAK */
    ITEM_SIZE_CHANNELS = 12,       /*!< size in bytes of item ITEM_ID_CHANNELS */
    ITEM_SIZE_VERSION = 4,         /*!< size in bytes of item ITEM_ID_VERSION */
    ITEM_SIZE_SERIAL = 8,          /*!< size in bytes of item ITEM_ID_SERIAL */
    ITEM_SIZE_AUTOZERO = 1,        /*!< size in bytes of item ITEM_ID_AUTOZERO */
    ITEM_SIZE_MEAS_COUNT = 2,      /*!< size in bytes of item ITEM_ID_MEAS_COUNT */
    ITEM_SIZE_LED_PATTERN = 20,    /*!< size in bytes of item ITEM_ID_LED_PATTERN */
    ITEM_SIZE_LED_WAIT_TIME = 4,   /*!< size in bytes of item ITEM_ID_LED_WAIT_TIME */
    ITEM_SIZE_INTERRUPT_PIN = 1,   /*!< size in bytes of item ITEM_ID_INTERRUPT_PIN */
    ITEM_SIZE_LED_INTERN = 4,      /*!< size in bytes of item ITEM_ID_LED_INTERN */
    ITEM_SIZE_LED_EXT_0 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_0 */
    ITEM_SIZE_LED_EXT_1 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_1 */
    ITEM_SIZE_LED_EXT_2 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_2 */
    ITEM_SIZE_LED_EXT_3 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_3 */
    ITEM_SIZE_LED_EXT_4 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_4 */
    ITEM_SIZE_LED_EXT_5 = 4,       /*!< size in bytes of item ITEM_ID_LED_EXT_5 */
    ITEM_SIZE_OUTPUT = 1,          /*!< size in bytes of item ITEM_ID_OUTPUT */
    ITEM_SIZE_TEMP_EXT_0 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_0 */
    ITEM_SIZE_TEMP_EXT_1 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_1 */
    ITEM_SIZE_TEMP_EXT_2 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_2 */
    ITEM_SIZE_TEMP_EXT_3 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_3 */
    ITEM_SIZE_TEMP_EXT_4 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_4 */
    ITEM_SIZE_TEMP_EXT_5 = 4,      /*!< size in bytes of item ITEM_ID_TEMP_EXT_5 */
    ITEM_SIZE_MEASURE_ITEMS = 10,  /*!< size in bytes of item ITEM_ID_MEASURE_ITEMS */
    ITEM_SIZE_FGAIN = 1,           /*!< size in bytes of item ITEM_ID_FGAIN */
    ITEM_SIZE_FTIME = 2,           /*!< size in bytes of item ITEM_ID_FTIME */
    ITEM_SIZE_FTIME_US = 4,        /*!< size in bytes of item ITEM_ID_FTIME_US */
    ITEM_SIZE_FCHANNELS = 4,       /*!< size in bytes of item ITEM_ID_FCHANNELS */
    ITEM_SIZE_TIMESTAMP = 8,       /*!< size in bytes of item ITEM_ID_TIMESTAMP */
    ITEM_SIZE_AUTO_GAIN_RANGE = 2, /*!< size in bytes of item ITEM_ID_AUTO_GAIN */
    ITEM_SIZE_GAIN_FACTORS = 22,   /*!< size in bytes of item ITEM_ID_GAIN_FACTOR */
    ITEM_SIZE_SYNC_MODE = 1        /*!< size in bytes of item ITEM_ID_SYNC_MODE */
};

/* USER_CODE END DEFINITIONS */

/*! This enumeration describes the state of the measurement engine */
enum as7341_states {
    STATE_CONFIG = 0, /*!< No measurement is running. */
    STATE_MEASURE = 1 /*!< Measurement is active. */
};

/*!
 * \brief Callback function, which transfers the measurement results to the application.
 *
 * This callback type will be registered via the function ::as7341_initialize.
 * During the measurement, this function transfers the cyclic results.
 *
 * p_data transfers the measured sensor data. p_items transfers additional item content, if configured.
 * The content of the items is without item size and without item id. The order of the item can be readout by
 * ::ITEM_ID_MEASURE_ITEMS.
 *
 * \see \ref meas_data_sec
 *
 * \param[in] device        Handle to the device (default 0, only for multi device purposes)
 * \param[in] error         Default ::ERR_SUCCESS, otherwise an error is occurred during measurement and the
 *                          measurement. stops. See ::error_codes
 * \param[in] p_data        Pointer to the measurement data, the content depends
 *                          on configuration. See ::ITEM_ID_MEAS_TYPE.
 * \param[in] data_size     Size of measurement data in bytes.
 * \param[in] p_items       Returns an optional array with data, which can be configured with item
 *                          ::ITEM_ID_MEASURE_ITEMS.
 * \param[in] items_size    Size of item data in bytes. The maximum supported size is defined in definition
 *                          ::AS7341_MAX_ITEM_BUFFER_SIZE
 * \param[in] p_cb_param    Application parameter which was defined during call of ::as7341_initialize.
 */
typedef void (*as7341_callback_t)(uint8_t device, uint8_t error, void *p_data, uint32_t data_size, void *p_items,
                                  uint32_t items_size, void *p_cb_param);

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/*! @} */

#endif /* __AS7341_TYPEDEFS_H__ */
