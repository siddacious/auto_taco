/******************************************************************************
 * Copyright by ams AG                                                        *
 * All rights are reserved.                                                   *
 *                                                                            *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING      *
 * THE SOFTWARE.                                                              *
 *                                                                            *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT           *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,      *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT        *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE      *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.       *
 ******************************************************************************/

#ifndef __AS7341_CHIP_LIB_H__
#define __AS7341_CHIP_LIB_H__

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/*!
 * \file      as7341_chiplib.h
 * \authors   ARIT
 * \copyright ams
 * \addtogroup chiplib_group
 *
 * \brief This is the chip library for ams spectral sensor AS7341.
 *
 * @{
 */

/******************************************************************************
 *                                 INCLUDES                                   *
 ******************************************************************************/

#include "as7341_stdinc.h"

#include "as7341_typedefs.h"
#include "error_codes.h"

/******************************************************************************
 *                                DEFINITIONS                                 *
 ******************************************************************************/

#if defined POSIX
#define CHIPLIB_DECLDIR
#else
#if defined CHIPLIB_DLL_EXPORT
#define CHIPLIB_DECLDIR __declspec(dllexport)
#elif defined CHIPLIB_DLL_IMPORT
#define CHIPLIB_DECLDIR __declspec(dllimport)
#else
#define CHIPLIB_DECLDIR
#endif
#endif

/******************************************************************************
 *                                 FUNCTIONS                                  *
 ******************************************************************************/

/*!
 * \brief Initializes the library and the device.
 *
 * Following tasks will be done here:
 * - Initialize hardware abstraction layer.
 * - Set default configuration values.
 *
 * \note This function must be called at first, otherwise all other functions return with error code.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes)
 * \param[in] p_callback            Pointer to the callback function, see as7341_callback_t
 * \param[in] p_cb_param            Optional pointer to an application parameter, which will be transmitted with every
 *                                  callback.
 * \param[in] p_interface_descr     Chiplib forwards this interface description to ::spectral_osal_initialize.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_IDENTIFICATION     The specified sensor was not found.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 */
err_code_t CHIPLIB_DECLDIR as7341_initialize(const uint8_t device, const as7341_callback_t p_callback,
                                             const void *p_cb_param, const char *p_interface_descr);

/*!
 * \brief Stops all internal actions and power down the device.
 *
 * Following tasks will be done here:
 * - Stops measurement, if running.
 * - Power down the sensor device.
 * - Shutdown the hardware abstraction layer.
 * - Block calling of all other functions, but initialize.
 *
 * \param[in] device            Handle to the device (default 0, only for multi device purposes).
 *
 * \retval ::ERR_SUCCESS        Function returns without error.
 * \retval ::ERR_DATA_TRANSFER  Communication error to sensor.
 */
err_code_t CHIPLIB_DECLDIR as7341_shutdown(const uint8_t device);

/*!
 * \brief Set an item.
 *
 * This function configures the chip library or the sensor directly.
 *
 * Following tasks will be done here:
 * - Searches for the corresponding internal configuration function of this item-ID.
 * - Calls the internal set-function if available.
 *
 * \note This function can only called if ChipLib is in state configuration.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 * \param[in] id                    Identification number of an item, see ::as7341_item_ids.
 * \param[in] p_data                Pointer to the data of the item.
 * \param[in] size                  Sets the size in byte of data, see ::as7341_item_sizes.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 * \retval ::ERR_NOT_SUPPORTED      e.g. Configuration of item ::ITEM_ID_LED_EXT_0, but LED is not implemented.
 *                                  Used item-ID is not writable.
 */
err_code_t CHIPLIB_DECLDIR as7341_set_item(const uint8_t device, const enum as7341_item_ids id, void *p_data,
                                           const uint8_t size);

/*!
 * \brief Get an item
 *
 * Reads the actual settings of sensor or library items.
 *
 * Following tasks will be done here:
 * - Searches for the corresponding internal request function of this item-ID.
 * - Calls the internal request-function if available.
 *
 * \note This function can be called in state configuration or measurement.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 * \param[in] id                    Identification number of an item, see ::as7341_item_ids.
 * \param[out] p_data               Pointer, where the data of the item can be saved.
 * \param[in] size                  Size in byte of data, see ::as7341_item_sizes.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor
 * \retval ::ERR_NOT_SUPPORTED      e.g. Readout of item ::ITEM_ID_TEMP_EXT_2, but function is not implemented.
 */
err_code_t CHIPLIB_DECLDIR as7341_get_item(const uint8_t device, const enum as7341_item_ids id, void *p_data,
                                           const uint8_t size);

/*!
 * \brief Configuration of multiple sensor or library items.
 *
 * Following tasks will be done here:
 * - Searches for the corresponding internal configuration function of the given item-IDs.
 * - Calls the internal set-function if available.
 *
 * Byte sequence of data [S0][I0][D0_0 - D0_N][S1][I1][D1_0 - D1_N] ... [SM][IM][DM_0 - DM_N]
 * S = size of D in bytes, see enumeration ::as7341_item_sizes
 * I = item id, see enumeration ::as7341_item_ids
 * D = payload of the corresponding item
 *
 * \note More than one item can be string together
 * \note This function can only called if ChipLib is in state configuration.
 * \note IDs, which are readable only or not supported, will be ignored.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 * \param[in] p_data                Pointer to the data of the item.
 * \param[in] size                  Size in byte of data.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 * \retval ::ERR_NOT_SUPPORTED      e.g. Configuration of item ::ITEM_ID_LED_EXT_0, but LED is not implemented.
 *
 * \see \ref config_item_sec
 */
err_code_t CHIPLIB_DECLDIR as7341_set_configuration(const uint8_t device, uint8_t *p_data, const uint32_t size);

/*!
 * \brief Request of all supported sensor and library items
 *
 * Following tasks will be done here:
 * - Iterate over all internal item-IDs
 * - Calls the internal get-function of each item-ID, if available
 * - Saves all data in the given data buffer
 *
 * Byte sequence of data [S0][I0][D0_0 - D0_N][S1][I1][D1_0 - D1_N] ... [SM][IM][DM_0 - DM_N]
 * S = size of D in bytes, see enumeration ::as7341_item_sizes
 * I = item id, see enumeration ::as7341_item_ids
 * D = payload of the corresponding item
 *
 * \note The size of the needed data buffer can be requested by calling this function with p_data = NULL
 *       and the value of p_size must be set to zero. The size will be copied to p_size.
 *
 * \note This function can only called if ChipLib is in state configuration.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 * \param[out] p_data               Pointer, where the item data can be saved.
 * \param[inout] p_size             Size in byte of p_data. After return of this function the used size will be saved
 *                                  here.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 * \retval ::ERR_NOT_SUPPORTED      e.g. Readout of item ::ITEM_ID_TEMP_EXT_2, but function is not implemented.
 *
 * \see \ref config_item_sec
 */
err_code_t CHIPLIB_DECLDIR as7341_get_configuration(const uint8_t device, uint8_t *p_data, uint32_t *p_size);

/*!
 * \brief Starts a measurement.
 *
 * This function sets only an internal event, that the measurement starts on next state machine step.
 *
 * \note This function can only called if ChipLib is in state configuration.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 */
err_code_t CHIPLIB_DECLDIR as7341_start_measurement(const uint8_t device);

/*!
 * \brief Executes a measurement step.
 *
 * Following tasks will be done here:
 * - Checks if an internal event was set.
 * - Checks if the internal event can be handled on actual state machine state.
 * - Calls the corresponding transition-function.
 *
 * \note This function can be called after finished initialization, but does only anything if the measurement was
 * started.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 * \param[out] p_state              Pointer, where the current state can be saved, see enumeration ::as7341_states.
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid.
 * \retval ::ERR_PERMISSION         The access to the library is blocked, call ::as7341_initialize at first.
 * \retval ::ERR_DATA_TRANSFER      Communication error to sensor.
 * \retval ::ERR_NOT_SUPPORTED      e.g. readout of item ::ITEM_ID_TEMP_EXT_2, but function is not implemented.
 * \retval ::ERR_OVERFLOW           Get overflow in FIFO mode.
 * \retval ::ERR_SENSOR_CONFIG      Break time is too high.
 */
err_code_t CHIPLIB_DECLDIR as7341_execute_state_machine(const uint8_t device, enum as7341_states *p_state);

/*!
 * \brief Abort a measurement.
 *
 * This function sets only an internal event, that the measurement stops as soon as possible.
 *
 * \param[in] device                Handle to the device (default 0, only for multi device purposes).
 *
 * \retval ::ERR_SUCCESS            Function returns without error.
 * \retval ::ERR_ARGUMENT           An argument is invalid
 * \retval ::ERR_PERMISSION         Access to the library is blocked, call ::as7341_initialize at first.
 */
err_code_t CHIPLIB_DECLDIR as7341_abort_measurement(const uint8_t device);

#ifdef __cplusplus
}
#endif // __cplusplus

/*! @} */

#endif /* __AS7341_CHIP_LIB_H__ */
