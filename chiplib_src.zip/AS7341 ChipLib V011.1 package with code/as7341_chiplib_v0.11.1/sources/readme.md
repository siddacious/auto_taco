# AS7341 ChipLib

This repository provides a measurement library for AS7341. 
The library is hardware independent and can be adapted to the application 
via a specified Operating system abstraction layer (OSAL).

## How to build

### Prerequisites

Compiler:
- Clang (9.0.0)
- GCC (8.1.0)

Sub-modules
- css-sw-utilities
- google_test_framework

Build-Tool:
- CMAKE

### Build procedure

To start the build of the components, use the file CMakeLists.txt in root directory.
On default, versions for Linux and Windows x64 and x86 can be built.
A connection over FTDI-cable will be used to connect the sensor (OSAL).

## How to use

The ChipLib is a standalone library. It can be opened by the test executables.

## How to test

Three different kind of tests are implemented:
- Unit test for interface: Mockup tests for interface module
- Unit tests for ChipLib: Simple parameter tests
- Integration tests: Tests with real sensor target

## Documentation

A user documentation for the interface of ChipLib and OSAL will be provided by doxygen.
The output of doxygen is latex and can be converted to a single PDF-file.

## Notes for implementation

### Linux OSAL
The programmer shall configure the necessary system information in the file spectral_osal_chiplib.c
The programmer shall ensure, that the target system is configured in a proper way. Especially
the sensor interrupt line connected to a system GPIO is expected to be exported in the sysfs
filesystem.