/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#include "test_fixture_interface.h"

using ::testing::_;
using ::testing::DoAll;
using ::testing::Pointee;
using ::testing::Return;
using ::testing::SetArgPointee;
using ::testing::SetArrayArgument;

namespace ChipLibUnittest
{

// instantiate mocked libraries
std::unique_ptr<OSAL_MOCK> TestFixtureInterface::_osal_mock;

TestFixtureInterface::TestFixtureInterface()
{
    _osal_mock.reset(new ::testing::NiceMock<OSAL_MOCK>());
}

TestFixtureInterface::~TestFixtureInterface()
{
    _osal_mock.reset();
}

void TestFixtureInterface::SetUp()
{
}

void TestFixtureInterface::TearDown()
{
}

void TestFixtureInterface::debug_output(const std::array<s_debug_output, 3> &debug_output)
{

    std::string dbg("[DEBUG]");
    std::string ws(" ");
    std::string prex(": 0x");
    std::string sep(", ");

    int number = debug_output.size();

    std::cout << dbg << ws;
    for (int i = 0; i < number - 1; i++) {
        std::cout << debug_output[i].param_name << prex << std::hex << (int)debug_output[i].param_value << sep;
    }
    std::cout << debug_output[number - 1].param_name << prex << std::hex << (int)debug_output[number - 1].param_value
              << std::endl;
}

/*!
 * \brief Prepare mock transfer_data to read a 8-bit value from a register address
 *
 * \param[in] register_address - register address to read from
 * \param[in] register_value - value which mock should output
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is checked that this pointer points to
 * register_address. The third argument to mock is 1: 1 byte for register address. It is the size of send buffer. The
 * fourth argument to mock is the pointer to the receive buffer. This pointer is set to point to register_value. The
 * fifth argument to mock is 1: 1 byte for register_value. It is the size of receive buffer.
 *
 */
void TestFixtureInterface::expectReadRegister(uint8_t register_address, uint8_t register_value, err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock, mock_osal_transfer_data(EqOsalId(valid_osal_id), Pointee(register_address), 1, _, 1))
        .WillOnce(DoAll(SetArgPointee<3>(register_value), Return(return_code)));
}

/*!
 * \brief Prepare mock transfer_data to read 16-bit values from a register address
 *
 * \param[in] register_address - register address to read from
 * \param[in] data - pointer to values which mock should output
 * \param[in] number_of_data - number of values which mock shoud output
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is checked that this pointer points to
 * register_address. The third argument to mock is 1: 1 byte for register address. It is the size of send buffer. The
 * fourth argument to mock is the pointer to the receive buffer. This pointer is set to data. The fifth argument to mock
 * is the size of receive buffer. Here it is number_of_data * 2.
 *
 */
void TestFixtureInterface::expectReadData(uint8_t register_address, uint16_t *data, uint8_t number_of_data,
                                          err_code_t return_code)
{

    uint8_t receive_size = number_of_data * sizeof(uint16_t);

    EXPECT_CALL(*_osal_mock,
                mock_osal_transfer_data(EqOsalId(valid_osal_id), Pointee(register_address), 1, _, receive_size))
        .WillOnce(DoAll(SetArrayArgument<3>((uint8_t *)data, (uint8_t *)data + receive_size), Return(return_code)));
}

/*!
 * \brief Prepare mock transfer_data to read 8-bit values from a register address
 *
 * \param[in] register_address - register address to read from
 * \param[in] bytes - pointer to values which mock should output
 * \param[in] number_of_bytes - number of values which mock should output
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is checked that this pointer points to
 * register_address. The third argument to mock is 1: 1 byte for register address. It is the size of send buffer. The
 * fourth argument to mock is the pointer to the receive buffer. This pointer is set to bytes. The fifth argument to
 * mock is the size of receive buffer. Here it is number_of_bytes.
 *
 */
void TestFixtureInterface::expectReadBytes(uint8_t register_address, uint8_t *bytes, uint8_t number_of_bytes,
                                           err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock,
                mock_osal_transfer_data(EqOsalId(valid_osal_id), Pointee(register_address), 1, _, number_of_bytes))
        .WillOnce(DoAll(SetArrayArgument<3>(bytes, bytes + number_of_bytes), Return(return_code)));
}

/*!
 * \brief Prepare mock transfer_data to read 8-bit values
 *
 * \param[in] bytes - pointer to values which mock should output
 * \param[in] number_of_bytes - number of values which mock should output
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is NULL.
 * The third argument to mock is 0, because there is no send buffer.
 * The fourth argument to mock is the pointer to the receive buffer. This pointer is set to bytes.
 * The fifth argument to mock is the size of receive buffer. Here it is number_of_bytes.
 *
 */
void TestFixtureInterface::expectReadBytes_without_send(uint8_t *bytes, uint8_t number_of_bytes, err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock, mock_osal_transfer_data(EqOsalId(valid_osal_id), NULL, 0, _, number_of_bytes))
        .WillOnce(DoAll(SetArrayArgument<3>(bytes, bytes + number_of_bytes), Return(return_code)));
}

/*!
 * \brief Prepare mock transfer_data to write a 8-bit value to a register address
 *
 * \param[in] register_address - register address to read from
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is checked that this pointer points to
 * register_address. The third argument to mock is 2: 1 byte for register address + 1 byte for register value. It is the
 * size of send buffer. The fourth argument to mock is the pointer to the receive buffer. This pointer is NULL. The
 * fifth argument to mock is the size of receive buffer. Here it is 0.
 *
 */
void TestFixtureInterface::expectWriteRegister(uint8_t register_address, err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock, mock_osal_transfer_data(EqOsalId(valid_osal_id), Pointee(register_address), 2, NULL, 0))
        .WillOnce(Return(return_code));
}

/*!
 * \brief Prepare mock transfer_data to write 8-bit values to a register address
 *
 * \param[in] register_address - register address to write to
 * \param[in] number_of_bytes - number of values
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. It is checked that this pointer points to
 * register_address. The third argument to mock is number_of_bytes. It is the size of send buffer. The fourth argument
 * to mock is the pointer to the receive buffer. This pointer is NULL. The fifth argument to mock is the size of receive
 * buffer. Here it is 0.
 *
 */
void TestFixtureInterface::expectWriteBytes(uint8_t register_address, uint8_t number_of_bytes, err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock,
                mock_osal_transfer_data(EqOsalId(valid_osal_id), Pointee(register_address), number_of_bytes, NULL, 0))
        .WillOnce(Return(return_code));
}

/*!
 * \brief Prepare mock transfer_data to write 8-bit values to a register address
 *
 * \param[in] actual_send_buffer - pointer to a buffer, in which mock save the input values
 * \param[in] buf_size - size of send buffer, third argument of mock
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. Mock saves the input values in actual_send_buffer. So
 * the data can be checked after the call. The third argument to mock is buf_size. It is the size of send buffer. The
 * fourth argument to mock is the pointer to the receive buffer. This pointer is NULL. The fifth argument to mock is the
 * size of receive buffer. Here it is 0.
 *
 */
void TestFixtureInterface::expectWriteRegister_without_check(uint8_t *actual_send_buffer, uint8_t buf_size,
                                                             err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock, mock_osal_transfer_data(EqOsalId(valid_osal_id), _, buf_size, NULL, 0))
        .WillOnce(DoAll(SaveArray(actual_send_buffer), Return(return_code)));
}

/*!
 * \brief Prepare mock transfer_data to write a 8-bit value to a register address
 *
 * \param[in] expected_send_buffer - pointer to expected send buffer
 * \param[in] return_code - code which mock should return
 *
 * \note The first argument to mock is the valid osal id which is defined for test.
 *
 * The second argument to mock is the pointer to the send buffer. The actual send buffer is checked against the the
 * expected send buffer. The third argument to mock is 2: 1 byte for register address + 1 byte for register value. It is
 * the size of send buffer. The fourth argument to mock is the pointer to the receive buffer. This pointer is NULL. The
 * fifth argument to mock is the size of receive buffer. Here it is 0.
 *
 */
void TestFixtureInterface::expectWriteRegister_with_check(uint8_t *expected_send_buffer, err_code_t return_code)
{

    EXPECT_CALL(*_osal_mock,
                mock_osal_transfer_data(EqOsalId(valid_osal_id), EqArray(expected_send_buffer, 2), 2, NULL, 0))
        .WillOnce(Return(return_code));
}

}; // namespace ChipLibUnittest
