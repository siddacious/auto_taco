/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _param {
    uint16_t maximum_adc;
    uint16_t highest_adc;
    uint8_t lower_gain_limit;
    uint8_t upper_gain_limit;
    uint8_t gain_in;
    uint8_t expected_gain;
    uint8_t expected_saturation;
};

/**** test class ********************************************************/

class GetOptimizedGain : public ::TestFixtureInterface,
                         public WithParamInterface<_param> {

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_optimized_gain as7341_get_optimized_gain
*
* Test cases for as7341_get_optimized_gain.
*
*
*/

/*!
 * \ingroup tc_get_optimized_gain
 * \brief Check get optimized gain
 * 
 * \Description{
 *   - check response to null pointer for gain
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for gain
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_OPTIMIZED_GAIN_0001}
 * 
 */
TEST_F(GetOptimizedGain, TEST_GET_OPTIMIZED_GAIN_0001__NullPointer) {

    // dummies
    uint16_t maximum_adc = 0;
    uint16_t highest_adc = 0;
    uint8_t lower_gain_limit = 0;
    uint8_t upper_gain_limit = 0;
    uint8_t saturation = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_optimized_gain(maximum_adc, highest_adc, lower_gain_limit, upper_gain_limit, NULL, &saturation));
}

/*!
 * \ingroup tc_get_optimized_gain
 * \brief Check get optimized gain
 * 
 * \Description{
 *   - check response to null pointer for saturation
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with null pointer for saturation
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_OPTIMIZED_GAIN_0002}
 * 
 */
TEST_F(GetOptimizedGain, TEST_GET_OPTIMIZED_GAIN_0002__NullPointerSaturation) {

    // dummies
    uint16_t maximum_adc = 0;
    uint16_t highest_adc = 0;
    uint8_t lower_gain_limit = 0;
    uint8_t upper_gain_limit = 0;
    uint8_t gain = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_optimized_gain(maximum_adc, highest_adc, lower_gain_limit, upper_gain_limit, &gain, NULL));
}

/*!
 * \ingroup tc_get_optimized_gain
 * \brief Check get optimized gain
 * 
 * \Description{
 *   - check ouotputs
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that output gain and expected gain are equal
 *   - check that output saturation and expected stauration are equal
 * }
 *
 * \TestID{TEST_GET_OPTIMIZED_GAIN_0003}
 * 
 */
TEST_P(GetOptimizedGain, TEST_GET_OPTIMIZED_GAIN_0003__Success) {

    // get the next test parameter structure
    _param my_param = GetParam();

    uint16_t maximum_adc = my_param.maximum_adc;
    uint16_t highest_adc = my_param.highest_adc;
    uint8_t lower_gain_limit = my_param.lower_gain_limit;
    uint8_t upper_gain_limit = my_param.upper_gain_limit;
    uint8_t gain = my_param.gain_in;
    uint8_t saturation = my_param.expected_saturation;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_optimized_gain(maximum_adc, highest_adc, lower_gain_limit, upper_gain_limit, &gain, &saturation));

    EXPECT_EQ(my_param.expected_gain, gain);
    EXPECT_EQ(my_param.expected_saturation, saturation);  
}

/**** parameterized test cases ********************************************************/
// Expected gain and saturation is determined with excel.
_param my_array[] = {
    // highest_adc = maximum_adc = 0 --> saturation, gain > LOW_AUTO_GAIN_VALUE --> gain / 2
    {0, 0, 1, 8, 4, 2, 1}, 
    // highest_adc = maximum_adc = 0 --> saturation, gain = LOW_AUTO_GAIN_VALUE --> gain = lower_gain_limit
    {0, 0, 4, 8, 3, 4, 1}, 
    // highest_adc > maximum_adc --> saturation, gain > LOW_AUTO_GAIN_VALUE --> gain / 2
    {15, 20, 1, 8, 4, 2, 1}, 
    // highest_adc > maximum_adc --> saturation, gain = LOW_AUTO_GAIN_VALUE --> gain = lower_gain_limit
    {15, 20, 4, 8, 3, 4, 1},
    // highest_adc < maximum_adc --> no saturation, gain_change = 2 --> highest_bit = 1 --> gain + highest_bit
    {300, 100, 2, 5, 3, 4, 0}, 
    // highest_adc < maximum_adc --> no saturation, gain_change = 12 --> highest_bit = 3 --> gain = upper_gain_limit
    {300, 20, 2, 5, 3, 5, 0}, 
    // highest_adc < maximum_adc --> no saturation, gain_change = 0 --> gain - 1
    {300, 250, 2, 5, 3, 2, 0}, 
    // highest_adc < maximum_adc --> no saturation, gain_change = 0 --> gain - 1 < lower_gain_limit --> gain = lower_gain_limit
    {300, 250, 3, 5, 3, 3, 0} 
};

INSTANTIATE_TEST_SUITE_P(OptimizedGainAndSaturation, GetOptimizedGain, ValuesIn(my_array));

}