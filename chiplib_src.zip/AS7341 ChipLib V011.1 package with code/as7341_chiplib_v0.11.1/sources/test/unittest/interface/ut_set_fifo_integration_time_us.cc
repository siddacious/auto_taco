/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetFifoIntegrationTimeUs : public ::TestFixtureInterface {

protected:
    // register addresses to read ftime from: AS7341_REGADDR_FD_TIME_L, AS7341_REGADDR_FD_TIME_H
    uint8_t register_address_fd_time_low = 0xD8;
    uint8_t register_address_fd_time_high = 0xDA;
    // register mask and byte shift to determine ftime: REG_BIT_FD_TIME_2_FD_TIME_MSK, BYTE_SHIFT
    uint8_t fd_time_mask = 0x07;
    uint8_t byte_shift = 8;

public:
    void SetUp() {

        g_device_config[valid_device_id].ftime = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_fifo_integration_time_us as7341_set_fifo_integration_time_us
*
* Test cases for as7341_set_fifo_integration_time_us.
*
*
*/

/*!
 * \ingroup tc_set_fifo_integration_time_us
 * \brief Check set integration time of fifo
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FIFO_INTEGRATION_TIME_US_0001}
 * 
 */
TEST_F(SetFifoIntegrationTimeUs, TEST_SET_FIFO_INTEGRATION_TIME_US_0001__DeviceIdIsInvalid) {

    // dummy
    uint32_t time_us = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fifo_integration_time_us(invalid_osal_id, time_us));
}

/*!
 * \ingroup tc_set_fifo_integration_time_us
 * \brief Check set integration time of fifo
 * 
 * \Description{
 *   - check response to time_us is too small
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a time_us is too small
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FIFO_INTEGRATION_TIME_US_0002}
 * 
 */
TEST_F(SetFifoIntegrationTimeUs, TEST_SET_FIFO_INTEGRATION_TIME_US_0002__TimeIsTooSmall) {

    // time is smaller than 3 (MIN_FTIME_US)
    uint32_t time_us = 2;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fifo_integration_time_us(valid_osal_id, time_us));
}

/*!
 * \ingroup tc_set_fifo_integration_time_us
 * \brief Check set integration time of fifo
 * 
 * \Description{
 *   - check response to time_us is too big
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a time_us is too big
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FIFO_INTEGRATION_TIME_US_0003}
 * 
 */
TEST_F(SetFifoIntegrationTimeUs, TEST_SET_FIFO_INTEGRATION_TIME_US_0003__TimeIsTooBig) {

    // time is greater than 5689 (MAX_FTIME_US)
    uint32_t time_us = 5690;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fifo_integration_time_us(valid_osal_id, time_us));
}

/*!
 * \ingroup tc_set_fifo_integration_time_us
 * \brief Check set integration time of fifo
 * 
 * \Description{
 *   - check response to as7341_set_ftime failed
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid time_us value
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that ftime is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_FIFO_INTEGRATION_TIME_US_0004}
 * 
 */
TEST_F(SetFifoIntegrationTimeUs, TEST_SET_FIFO_INTEGRATION_TIME_US_0004__SetFTimeFailed) {

    // time to set
    uint32_t time_us = 5000;

    // prepare as7341_set_ftime() 
    //   mock read_register fd_time_high --> returns an error
    expectReadRegister(register_address_fd_time_high, 0, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_fifo_integration_time_us(valid_osal_id, time_us));

    EXPECT_EQ(g_device_config[valid_device_id].ftime, 0);
}

/*!
 * \ingroup tc_set_fifo_integration_time_us
 * \brief Check set integration time of fifo
 * 
 * \Description{
 *   - check response to as7341_set_ftime succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns ERR_SUCCESS
 *   - mock function for write register fd_time_high returns ERR_SUCCESS
 *   - mock function for write register fd_time_low returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid time_us value
 * }
 * 
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check that ftime is saved in device configuration
 * }
 *
 * \TestID{TEST_SET_FIFO_INTEGRATION_TIME_US_0005}
 * 
 */
TEST_F(SetFifoIntegrationTimeUs, TEST_SET_FIFO_INTEGRATION_TIME_US_0005__Success) {

    // time to set
    uint32_t time_us = 5000;

    // calculate ftime
    uint16_t ftime = (uint16_t)(
        ((((int64_t)time_us * INTEGRATION_TIME_STEP_US_DIVIDER * 10 / INTEGRATION_TIME_STEP_US_FACTOR) + 5) / 10) - 1);

    // prepare as7341_set_ftime()
    // (1) mock read_register register_address_fd_time_high --> returns ERR_SUCCESS
    uint8_t register_value_high = 0;
    expectReadRegister(register_address_fd_time_high, register_value_high, ERR_SUCCESS);
    // (2) mock write_register register_address_fd_time_high --> returns ERR_SUCCESS
    //   calculate expected value for write fd_time_high
    uint8_t expected_value = register_value_high & ~fd_time_mask;
    expected_value |= (uint8_t)(ftime >> byte_shift) & fd_time_mask;
    //   expected send buffer transfer
    uint8_t expected_send_buf[] = {register_address_fd_time_high, expected_value};
    expectWriteRegister_with_check(expected_send_buf, ERR_SUCCESS);
    // (3) mock write_register register_address_fd_time_low --> returns ERR_SUCCESS
    //   calculate expected value for write fd_time_low
    uint8_t expected_value_2 = (uint8_t)(ftime & 0xFF);
    //   expected send buffer transfer
    uint8_t expected_send_buf_2[] = {register_address_fd_time_low, expected_value_2};
    expectWriteRegister_with_check(expected_send_buf_2, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fifo_integration_time_us(valid_osal_id, time_us));

    EXPECT_EQ(g_device_config[valid_device_id].ftime, ftime);
}

}