/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetFtime : public ::TestFixtureInterface {

protected:
    // register addresses to read ftime from: AS7341_REGADDR_FD_TIME_L, AS7341_REGADDR_FD_TIME_H
    uint8_t register_address_fd_time_low = 0xD8;
    uint8_t register_address_fd_time_high = 0xDA;
    // register mask and byte shift to determine ftime: REG_BIT_FD_TIME_2_FD_TIME_MSK, BYTE_SHIFT
    uint8_t fd_time_mask = 0x07;
    uint8_t byte_shift = 8;

public:
    void SetUp() {

    }

};

class GetSavedFtime : public ::TestFixtureInterface {

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_ftime as7341_get_ftime
*
* Test cases for as7341_get_ftime.
*
*
*/

/*!
 * \ingroup tc_get_ftime
 * \brief Check get time for flicker
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FTIME_0001}
 * 
 */
TEST_F(GetFtime, TEST_GET_FTIME_0001__DeviceIdIsInvalid) {

    // dummy
    uint16_t ftime = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_ftime(invalid_osal_id, &ftime));
}

/*!
 * \ingroup tc_get_ftime
 * \brief Check get time for flicker
 * 
 * \Description{
 *   - check response to null pointer for ftime
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for ftime
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FTIME_0002}
 * 
 */
TEST_F(GetFtime, TEST_GET_FTIME_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_ftime(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_ftime
 * \brief Check get time for flicker
 * 
 * \Description{
 *   - check response to read register fd_time_high failed
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid ftime
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_GET_FTIME_0003}
 * 
 */
TEST_F(GetFtime, TEST_GET_FTIME_0003__ReadRegisterFdTimeHighFailed) {

    uint16_t ftime = 0;
    
    // register value returned by mock
    uint8_t register_value_high = 0x12;

    expectReadRegister(register_address_fd_time_high, register_value_high, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_ftime(valid_osal_id, &ftime));
}

/*!
 * \ingroup tc_get_ftime
 * \brief Check get time for flicker
 * 
 * \Description{
 *   - check response to read register fd_time_low failed
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns ERR_SUCCESS
 *   - mock function for read register fd_time_low returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid ftime
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check output ftime
 * }
 *
 * \TestID{TEST_GET_FTIME_0004}
 * 
 */
TEST_F(GetFtime, TEST_GET_FTIME_0004__ReadRegisterFdTimeLowFailed) {

    uint16_t ftime = 0;
    
    // registers value returned by mock
    uint8_t register_value_high = 0x12;
    uint8_t register_value_low = 0x34;

    // calculate expected ftime
    uint16_t expected_ftime = (uint16_t)(register_value_high & fd_time_mask) << byte_shift;

    expectReadRegister(register_address_fd_time_high, register_value_high, ERR_SUCCESS);
    expectReadRegister(register_address_fd_time_low, register_value_low, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_ftime(valid_osal_id, &ftime));

    EXPECT_EQ(expected_ftime, ftime);
}

/*!
 * \ingroup tc_get_ftime
 * \brief Check get time for flicker
 * 
 * \Description{
 *   - check response to read registers succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns ERR_SUCCESS
 *   - mock function for read register fd_time_low returns an ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid ftime
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check output ftime
 * }
 *
 * \TestID{TEST_GET_FTIME_0005}
 * 
 */
TEST_F(GetFtime, TEST_GET_FTIME_0005__ReadRegistersSucceeded) {

    uint16_t ftime = 0;
    
    // registers value returned by mock
    uint8_t register_value_high = 0x12;
    uint8_t register_value_low = 0x34;

    // calculate expected ftime
    uint16_t expected_ftime = (uint16_t)(register_value_high & fd_time_mask) << byte_shift;
    expected_ftime |= register_value_low;

    expectReadRegister(register_address_fd_time_high, register_value_high, ERR_SUCCESS);
    expectReadRegister(register_address_fd_time_low, register_value_low, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_ftime(valid_osal_id, &ftime));

    EXPECT_EQ(expected_ftime, ftime);
}
/*!
*
* @defgroup tc_get_ftime as7341_get_ftime
*
* Test cases for as7341_get_ftime.
*
*
*/

/*!
 * \ingroup tc_get_saved_ftime
 * \brief Check get saved time for flicker
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_SAVED_FTIME_0001}
 * 
 */
TEST_F(GetSavedFtime, TEST_GET_SAVED_FTIME_0001__DeviceIdIsInvalid) {

    // dummy
    uint16_t ftime = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_saved_ftime(invalid_osal_id, &ftime));
}

/*!
 * \ingroup tc_get_saved_ftime
 * \brief Check get saved time for flicker
 * 
 * \Description{
 *   - check response to null pointer for ftime
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for ftime
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_SAVED_FTIME_0002}
 * 
 */
TEST_F(GetSavedFtime, TEST_GET_SAVED_FTIME_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_saved_ftime(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_saved_ftime
 * \brief Check get saved time for flicker
 * 
 * \Description{
 *   - check output for saved ftime
 * }
 * 
 * \Preconditions{
 *   - set element ftime in configuration
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid pointer for ftime
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_GET_SAVED_FTIME_0003}
 * 
 */
TEST_F(GetSavedFtime, TEST_GET_SAVED_FTIME_0003__Success) {

    uint16_t ftime = 0;

    g_device_config[valid_device_id].ftime = 0x1234;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_saved_ftime(valid_osal_id, &ftime));

    EXPECT_EQ(g_device_config[valid_device_id].ftime, ftime);
}

}