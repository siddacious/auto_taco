/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class Stop : public ::TestFixtureInterface {

protected:
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;
    // REG_ENABLE_BIT_SP_EN
    uint8_t enable_bit_spectral = 0x02;
    // REG_ENABLE_BIT_FDEN
    uint8_t enable_bit_flicker = 0x40;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_stop as7341_stop
*
* Test cases for as7341_stop.
*
*
*/

/*!
 * \ingroup tc_stop
 * \brief Check stop measurement
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_STOP_0001}
 * 
 */
TEST_F(Stop, TEST_STOP_0001__DeviceIdIsInvalid) {

    EXPECT_EQ(ERR_ARGUMENT, as7341_stop(invalid_osal_id, MEAS_TYPE_SPECTRAL));
}

/*!
 * \ingroup tc_stop
 * \brief Check stop measurement
 * 
 * \Description{
 *   - check response to write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'spectral'
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_STOP_0003}
 * 
 */
TEST_F(Stop, TEST_STOP_0003__WriteRegisterFailedForSpectral) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_stop(valid_osal_id, MEAS_TYPE_SPECTRAL));

    // The enable_bit is reset regardless off write register failed or succeeded!
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_spectral;
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_stop
 * \brief Check stop measurement
 * 
 * \Description{
 *   - check response to write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'spectral'
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that enable bit in element register_enable of device configuration is reset
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_STOP_0004}
 * 
 */
TEST_F(Stop, TEST_STOP_0004__WriteRegisterSucceededForSpectral) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // value to set
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_spectral;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_enable, value};
    uint8_t buf_size = sizeof(expected_send_buf);
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // check input arguments and save send buffer to check later
    expectWriteRegister_without_check(actual_send_buf, buf_size, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_stop(valid_osal_id, MEAS_TYPE_SPECTRAL));

    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, buf_size));
}

/*!
 * \ingroup tc_stop
 * \brief Check stop measurement
 * 
 * \Description{
 *   - check response to write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'fifo'
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_STOP_0005}
 * 
 */
TEST_F(Stop, TEST_STOP_0005__WriteRegisterFailedForFlicker) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_stop(valid_osal_id, MEAS_TYPE_FIFO));

    // The enable_bit is reset regardless off write register failed or succeeded!
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_stop
 * \brief Check stop measurement
 * 
 * \Description{
 *   - check response to write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'fifo'
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that enable bit in element register_enable of device configuration is reset
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_STOP_0006}
 * 
 */
TEST_F(Stop, TEST_STOP_0006__WriteRegisterSucceededForFlicker) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // value to set
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_enable, value};
    uint8_t buf_size = sizeof(expected_send_buf);
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // check input arguments and save send buffer to check later
    expectWriteRegister_without_check(actual_send_buf, buf_size, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_stop(valid_osal_id, MEAS_TYPE_FIFO));

    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, buf_size));
}

}