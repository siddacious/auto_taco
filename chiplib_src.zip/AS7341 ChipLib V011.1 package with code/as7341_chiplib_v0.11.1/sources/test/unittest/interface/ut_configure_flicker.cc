/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class ConfigureFlicker : public ::TestFixtureInterface {

protected:
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;
    // REG_ENABLE_BIT_FDEN
    uint8_t enable_bit_flicker = 0x40;
    // register address to enable fifo: AS7341_REGADDR_FD_CFG0
    uint8_t register_address_fd_cfg0 = 0xD7;
    // REG_BIT_FIFO_CFG_0_FIFO_WRITE_FD_MSK
    uint8_t enable_fifo = 0xA1;
    // register address to clear fifo mapping: AS7341_REGADDR_FIFO_MAP
    uint8_t register_address_fifo_map = 0xFC;
    // register address to set fifo level: AS7341_REGADDR_CFG8
    uint8_t register_address_cfg8 = 0xB1;
    // REG_BIT_CFG8_FIFO_TH_MSK
    uint8_t fifo_mask = 0xC0;
    // register address to disable interrupts: AS7341_REGADDR_CFG9
    uint8_t register_address_cfg9 = 0xB2;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_configure_flicker as7341_configure_flicker
*
* Test cases for as7341_configure_flicker.
*
*
*/

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0001}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0001__DeviceIdIsInvalid) {

    EXPECT_EQ(ERR_ARGUMENT, as7341_configure_flicker(invalid_osal_id));
}

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to write register for stop flicker failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0002}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0002__StopFlickerFailed) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};

    expectWriteRegister_with_check(expected_send_buf1, special_error_code);

    EXPECT_EQ(special_error_code, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to write register for enable fifo failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to disable interrupts returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0003}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0003__DisableInterruptsFailed) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};
    // (2) disable interrupts --> register_cfg9
    uint8_t expected_send_buf2[] = {register_address_cfg9, 0};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, special_error_code);

    EXPECT_EQ(special_error_code, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}


/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to write register for enable fifo failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to disable interrupts returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to enable fifo returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0004}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0004__EnableFifoFailed) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};
    // (2) disable interrupts --> register_cfg9
    uint8_t expected_send_buf2[] = {register_address_cfg9, 0};
    // (3) enable fifo --> register fd_cfg0
    uint8_t expected_send_buf3[] = {register_address_fd_cfg0, enable_fifo};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf3, special_error_code);

    EXPECT_EQ(special_error_code, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to write register for clear fifo mapping failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to disable interrupts returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to enable fifo returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to clear fifo mapping returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0005}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0005__ClearFifoMappingFailed) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};
    // (2) disable interrupts --> register_cfg9
    uint8_t expected_send_buf2[] = {register_address_cfg9, 0};
    // (3) enable fifo --> register fd_cfg0
    uint8_t expected_send_buf3[] = {register_address_fd_cfg0, enable_fifo};
    // (4) clear fifo mapping --> register fifo_map
    uint8_t expected_send_buf4[] = {register_address_fifo_map, 0};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf3, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf4, special_error_code);

    EXPECT_EQ(special_error_code, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check response to write register cfg8 failed for set fifo level
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to disable interrupts returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to enable fifo returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to clear fifo mapping returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to set fifo level returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0006}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0006__SetFifoLevelFailed) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};
    // (2) disable interrupts --> register_cfg9
    uint8_t expected_send_buf2[] = {register_address_cfg9, 0};
    // (3) enable fifo --> register fd_cfg0
    uint8_t expected_send_buf3[] = {register_address_fd_cfg0, enable_fifo};
    // (4) clear fifo mapping --> register fifo_map
    uint8_t expected_send_buf4[] = {register_address_fifo_map, 0};
    // (5) set fifo level --> register cfg8
    uint8_t expected_send_buf5[] = {register_address_cfg8, fifo_mask};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf3, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf4, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf5, special_error_code);

    EXPECT_EQ(special_error_code, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_configure_flicker
 * \brief Check configure of flicker detection
 * 
 * \Description{
 *   - check configure flicker detection succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to stop flicker returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to disable interrupts returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to enable fifo returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to clear fifo mapping returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to set fifo level returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that enable bit 'flicker' in element register_enable of device configuration is reset
 * }
 *
 * \TestID{TEST_CONFIGURE_FLICKER_0007}
 * 
 */
TEST_F(ConfigureFlicker, TEST_CONFIGURE_FLICKER_0007__Success) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0xFF;

    // expected send buffer transfer to mock
    // (1) stop flicker --> register enable
    uint8_t value = g_device_config[valid_device_id].register_enable & ~enable_bit_flicker;
    uint8_t expected_send_buf1[] = {register_address_enable, value};
    // (2) disable interrupts --> register_cfg9
    uint8_t expected_send_buf2[] = {register_address_cfg9, 0};
    // (3) enable fifo --> register fd_cfg0
    uint8_t expected_send_buf3[] = {register_address_fd_cfg0, enable_fifo};
    // (4) clear fifo mapping --> register fifo_map
    uint8_t expected_send_buf4[] = {register_address_fifo_map, 0};
    // (5) set fifo level --> register cfg8
    uint8_t expected_send_buf5[] = {register_address_cfg8, fifo_mask};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf3, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf4, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf5, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_configure_flicker(valid_osal_id));

    // The enable_bit is reset regardless of write register failed or succeeded!
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

}