/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetFgain : public ::TestFixtureInterface {

protected:
    // register addresses to read fgain from: AS7341_REGADDR_FD_TIME_H
    uint8_t register_address_fd_time_high = 0xDA;
    // byte shift to get fgain: FD_GAIN_REG_OFFSET
    uint8_t shift_fgain = 3;

public:
    void SetUp() {

        g_device_config[valid_device_id].fgain = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_fgain as7341_set_fgain
*
* Test cases for as7341_set_fgain.
*
*
*/

/*!
 * \ingroup tc_set_fgain
 * \brief Check set gain for flicker
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FGAIN_0001}
 * 
 */
TEST_F(SetFgain, TEST_SET_FGAIN_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t fgain = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fgain(invalid_osal_id, fgain));
}

/*!
 * \ingroup tc_set_fgain
 * \brief Check set gain for flicker
 * 
 * \Description{
 *   - check response to invalid ftime
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid fgain
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FGAIN_0002}
 * 
 */
TEST_F(SetFgain, TEST_SET_FGAIN_0002__FtimeIsInvalid) {

    // fgain is greater than 10 (MAX_GAIN_INDEX)
    uint8_t fgain = 11;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fgain(valid_osal_id, fgain));
}

/*!
 * \ingroup tc_set_fgain
 * \brief Check set time for flicker
 * 
 * \Description{
 *   - check response to read register fd_time_high failed
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain value
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that fgain is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_FGAIN_0003}
 * 
 */
TEST_F(SetFgain, TEST_SET_FGAIN_0003__ReadRegisterFdTimeHighFailed) {

    // fgain to set
    uint8_t fgain = 7;

    // register value returned by mock
    uint8_t register_value_high = 0x12;

    expectReadRegister(register_address_fd_time_high, register_value_high, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_fgain(valid_osal_id, fgain));

    EXPECT_EQ(g_device_config[valid_device_id].fgain, 0);
}

/*!
 * \ingroup tc_set_fgain
 * \brief Check set time for flicker
 * 
 * \Description{
 *   - check response to write register fd_time_high failed
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns ERR_SUCCESS
 *   - mock function for write register fd_time_high returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain value
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that fgain is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_FGAIN_0004}
 * 
 */
TEST_F(SetFgain, TEST_SET_FGAIN_0004__WriteRegisterFdTimeHighFailed) {

    // fgain to set
    uint8_t fgain = 7;

    // register value returned by mock
    uint8_t register_value_high = 0x12;
    expectReadRegister(register_address_fd_time_high, register_value_high, ERR_SUCCESS);

    // calculate expected value for write fd_time_high
    uint8_t expected_value = register_value_high & REG_BIT_FD_TIME_2_FD_TIME_MSK;
    expected_value |= fgain << FD_GAIN_REG_OFFSET;
    // expected send buffer transfer to mock write fd_time_high
    uint8_t expected_send_buf[] = {register_address_fd_time_high, expected_value};
    expectWriteRegister_with_check(expected_send_buf, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_fgain(valid_osal_id, fgain));

    EXPECT_EQ(g_device_config[valid_device_id].fgain, 0);
}

/*!
 * \ingroup tc_set_fgain
 * \brief Check set gain for flicker
 * 
 * \Description{
 *   - check response to set fgain succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for read register fd_time_high returns ERR_SUCCESS
 *   - mock function for write register fd_time_high returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain value
 * }
 * 
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check that fgain is saved in device configuration
 * }
 *
 * \TestID{TEST_SET_FGAIN_0005}
 * 
 */
TEST_F(SetFgain, TEST_SET_FGAIN_0005__Success) {

    // fgain to set
    uint8_t fgain = 7;

    // register value returned by mock
    uint8_t register_value_high = 0x12;
    expectReadRegister(register_address_fd_time_high, register_value_high, ERR_SUCCESS);

    // calculate expected value for write fd_time_high
    uint8_t expected_value = register_value_high & REG_BIT_FD_TIME_2_FD_TIME_MSK;
    expected_value |= fgain << FD_GAIN_REG_OFFSET;
    // expected send buffer transfer to mock write fd_time_high
    uint8_t expected_send_buf[] = {register_address_fd_time_high, expected_value};
    expectWriteRegister_with_check(expected_send_buf, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fgain(valid_osal_id, fgain));

    EXPECT_EQ(g_device_config[valid_device_id].fgain, fgain);
}

}