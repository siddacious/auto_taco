/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class IsDataReady : public ::TestFixtureInterface {

protected:
    // register address to read is_data_ready from: AS7341_REGADDR_STATUS2
    uint8_t register_address_status2 = 0xA3;
    // register mask: REG_BIT_STATUS_2_AVALID_MSK
    uint8_t avalid_mask = 0x40;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_is_data_ready as7341_is_data_ready
*
* Test cases for as7341_is_data_ready.
*
*
*/

/*!
 * \ingroup tc_is_data_ready
 * \brief Check is data ready
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_IS_DATA_READY_LOW_0001}
 * 
 */
TEST_F(IsDataReady, TEST_IS_DATA_READY_LOW_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t is_data_ready = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_is_data_ready(invalid_osal_id, &is_data_ready));
}

/*!
 * \ingroup tc_is_data_ready
 * \brief Check is data ready
 * 
 * \Description{
 *   - check response to null pointer for is_data_ready
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for is_data_ready
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_IS_DATA_READY_LOW_0002}
 * 
 */
TEST_F(IsDataReady, TEST_IS_DATA_READY_LOW_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_is_data_ready(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_is_data_ready
 * \brief Check is data ready
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid is_data_ready
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_IS_DATA_READY_LOW_0003}
 * 
 */
TEST_F(IsDataReady, TEST_IS_DATA_READY_LOW_0003__ReadRegisterFailed) {

    uint8_t is_data_ready = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    expectReadRegister(register_address_status2, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_is_data_ready(valid_osal_id, &is_data_ready));
}

/*!
 * \ingroup tc_is_data_ready
 * \brief Check is data ready
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid is_data_ready
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected is_data_ready is equal received is_data_ready
 * }
 *
 * \TestID{TEST_IS_DATA_READY_LOW_0004}
 * 
 */
TEST_F(IsDataReady, TEST_IS_DATA_READY_LOW_0004__ReadRegisterSucceeded) {

    uint8_t is_data_ready = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    // calculate expected is_data_ready 
    uint8_t expected_is_data_ready = ((register_value & avalid_mask) == avalid_mask) ? 1 : 0;

    expectReadRegister(register_address_status2, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_is_data_ready(valid_osal_id, &is_data_ready));

    EXPECT_EQ(expected_is_data_ready, is_data_ready);
}

}