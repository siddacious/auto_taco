/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetPartId : public ::TestFixtureInterface {

protected:
    // register address to read part id from: 0x92 (AS7341_REGADDR_ID)
    uint8_t register_address_id = 0x92;
    // REG_BIT_PART_ID_OFFSET
    uint8_t part_id_offset = 2;

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_part_id as7341_get_part_id
*
* Test cases for as7341_get_part_id.
*
*
*/

/*!
 * \ingroup tc_get_part_id
 * \brief Check get part id
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_PART_ID_0001}
 * 
 */
TEST_F(GetPartId, TEST_GET_PART_ID_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t part_id = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_part_id(invalid_osal_id, &part_id));
}

/*!
 * \ingroup tc_get_part_id
 * \brief Check get part id
 * 
 * \Description{
 *   - check response to null pointer for part id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for part id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_PART_ID_0002}
 * 
 */
TEST_F(GetPartId, TEST_GET_PART_ID_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_part_id(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_part_id
 * \brief Check get part id
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid part id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_PART_ID_0003}
 * 
 */
TEST_F(GetPartId, TEST_GET_PART_ID_0003__ReadRegisterFailed) {

    uint8_t part_id = 0;

    // register value returned by mock
    uint8_t register_value = 0x5C;

    expectReadRegister(register_address_id, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_part_id(valid_osal_id, &part_id));
}

/*!
 * \ingroup tc_get_part_id
 * \brief Check get part id
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid part id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected part id is equal received part_id
 * }
 *
 * \TestID{TEST_GET_PART_ID_0004}
 * 
 */
TEST_F(GetPartId, TEST_GET_PART_ID_0004__ReadRegisterSucceeded) {

    uint8_t part_id = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    // calculate expected part id: right shift register value by 2 (REG_BIT_PART_ID_OFFSET)
    uint8_t expected_part_id = register_value >> part_id_offset;

    expectReadRegister(register_address_id, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_part_id(valid_osal_id, &part_id));

    EXPECT_EQ(expected_part_id, part_id);
}

}