/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetAutoZero : public ::TestFixtureInterface {

protected:
    // register address to write autozero to: AS7341_REGADDR_AZCONFIG
    uint8_t register_address_azconfig = 0xD6;

public:
    void SetUp() {
        // init autozero in device configuration
        g_device_config[valid_device_id].auto_zero = 0;       
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_autozero as7341_set_autozero
*
* Test cases for as7341_set_autozero.
*
*
*/

/*!
 * \ingroup tc_set_autozero
 * \brief Check set autozero
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_AUTOZERO_0001}
 * 
 */
TEST_F(SetAutoZero, TEST_SET_AUTOZERO_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t autozero = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_autozero(invalid_osal_id, autozero));
}

/*!
 * \ingroup tc_set_autozero
 * \brief Check set autozero
 * 
 * \Description{
 *   - check response to write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid autozero value
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that autozero is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_AUTOZERO_0003}
 * 
 */
TEST_F(SetAutoZero, TEST_SET_AUTOZERO_0003__WriteRegisterFailed) {

    // autozero to set
    uint8_t autozero = 5;

    // actual send buffer, will be saved by mock
    uint8_t actual_send_buffer[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buffer, sizeof(actual_send_buffer), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_autozero(valid_osal_id, autozero));

    EXPECT_EQ(g_device_config[valid_device_id].auto_zero, 0);
}

/*!
 * \ingroup tc_set_autozero
 * \brief Check set autozero
 * 
 * \Description{
 *   - check response to write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid autozero 
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that autozero is saved in device configuration
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_SET_AUTOZERO_0004}
 * 
 */
TEST_F(SetAutoZero, TEST_SET_AUTOZERO_0004__WriteRegisterSucceeded) {

    // autozero to set
    uint8_t autozero = 5;

    // expected send buffer
    uint8_t expected_send_buffer[] = {register_address_azconfig, autozero};
    // actual send buffer, will be saved by mock
    uint8_t actual_send_buffer[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buffer, sizeof(actual_send_buffer), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_autozero(valid_osal_id, autozero));

    EXPECT_EQ(g_device_config[valid_device_id].auto_zero, autozero);

    EXPECT_THAT(expected_send_buffer, ElementsAreArray(actual_send_buffer, sizeof(actual_send_buffer)));
}

}