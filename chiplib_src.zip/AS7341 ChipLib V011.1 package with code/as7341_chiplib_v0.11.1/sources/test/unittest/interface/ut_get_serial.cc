/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetSerial : public ::TestFixtureInterface {

protected:
    // register address to read data from: AS7341_REGADDR_CHIP_ID
    uint8_t register_address_chip_id = 0x0B;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_serial as7341_get_serial
*
* Test cases for as7341_get_serial.
*
*
*/

/*!
 * \ingroup tc_get_serial
 * \brief Check get timestamp and tester id
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_SERIAL_0001}
 * 
 */
TEST_F(GetSerial, TEST_GET_SERIAL_0001__DeviceIdIsInvalid) {

    // dummies
    uint32_t timestamp = 0;
    uint32_t tester_id = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_serial(invalid_osal_id, &timestamp, &tester_id));
}

/*!
 * \ingroup tc_get_serial
 * \brief Check get timestamp and tester id
 * 
 * \Description{
 *   - check response to null pointer for timestamp
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for timestamp
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_SERIAL_0002}
 * 
 */
TEST_F(GetSerial, TEST_GET_SERIAL_0002__NullPointerTimestamp) {

    // dummies
    uint32_t tester_id = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_serial(valid_osal_id, NULL, &tester_id));
}

/*!
 * \ingroup tc_get_serial
 * \brief Check get timestamp and tester id
 * 
 * \Description{
 *   - check response to null pointer for tester id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for tester id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_SERIAL_0003}
 * 
 */
TEST_F(GetSerial, TEST_GET_SERIAL_0003__NullPointerTesterId) {

    // dummies
    uint32_t timestamp = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_serial(valid_osal_id, &timestamp, NULL));
}

/*!
 * \ingroup tc_get_serial
 * \brief Check get timestamp and tester id
 * 
 * \Description{
 *   - check response to transfer data failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid timestamp and tester id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that timestamp and tester id are not overwritten by transfer data
 * }
 *
 * \TestID{TEST_GET_SERIAL_0004}
 * 
 */
TEST_F(GetSerial, TEST_GET_SERIAL_0004__TransferDataFailed) {

    uint32_t timestamp = 0;
    uint32_t tester_id = 0;
    
    // data returned by mock
    uint8_t data[] = {1, 2, 3, 4, 5};

    expectReadBytes(register_address_chip_id, data, sizeof(data), special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_serial(valid_osal_id, &timestamp, &tester_id));

    EXPECT_EQ(timestamp, 0);
    EXPECT_EQ(tester_id, 0);
}

/*!
 * \ingroup tc_get_serial
 * \brief Check get timestamp and tester id
 * 
 * \Description{
 *   - check response to transfer data succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid timestamp and tester id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that timestamp and tester id are overwritten by transfer data
 * }
 *
 * \TestID{TEST_GET_SERIAL_0005}
 * 
 */
TEST_F(GetSerial, TEST_GET_SERIAL_0005__TransferDataSucceeded) {

    uint32_t timestamp = 0;
    uint32_t tester_id = 0;
    
    // data returned by mock
    uint8_t data[] = {1, 2, 3, 4, 5};

    expectReadBytes(register_address_chip_id, data, sizeof(data), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_serial(valid_osal_id, &timestamp, &tester_id));

    EXPECT_EQ(timestamp, *(uint32_t *)data);
    EXPECT_EQ(tester_id, data[4]);
}

}