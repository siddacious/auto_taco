/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class Led : public TestFixtureInterface {

protected:
    // register address for interrupt enable: AS7341_REGADDR_LED
    uint8_t register_address_led = 0x74;
    // register address for configuration: AS7341_REGADDR_CONFIG
    uint8_t register_address_config = 0x70;
    // bit for select led in register config: REG_BIT_CONFIG_LED_SEL_MSK
    uint8_t select_led_bit = 0x08;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_led as7341_x_led
*
* Test cases for as7341_get_led, as7341_set_led, set_led_pin.
*
*
*/

/*!
 * \ingroup tc_led
 * \brief Check set led
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_SET_LED_0001}
 * 
 */
TEST_F(Led, TEST_SET_LED_0001__InvalidDeviceId) {

    // dummy
    uint8_t led_config = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_set_led(invalid_osal_id, led_config));
}

/*!
 * \ingroup tc_led
 * \brief Check set led
 * 
 * \Description{
 *   - check set led
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check the send buffer to set register led
 *
 * \TestID{TEST_SET_LED_0002}
 * 
 */
TEST_F(Led, TEST_SET_LED_0002__Succeeded) {

    uint8_t led_config = 0xA5;

     // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_led, led_config};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // prepare the mock
    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, as7341_set_led(valid_osal_id, led_config));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_led
 * \brief Check get led
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_LED_0001}
 * 
 */
TEST_F(Led, TEST_GET_LED_0001__InvalidDeviceId) {

    // dummy
    uint8_t led_config = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_get_led(invalid_osal_id, &led_config));
}

/*!
 * \ingroup tc_led
 * \brief Check get led
 * 
 * \Description{
 *   - check response to null pointer for led_config
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for led_config
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_LED_0002}
 * 
 */
TEST_F(Led, TEST_GET_LED_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_led(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_led
 * \brief Check get led
 * 
 * \Description{
 *   - check get led
 * }
 * 
 * \Preconditions{
 *   - prepare the mock to read a value from a register address
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that returned led_config and register value are equal
 *
 * \TestID{TEST_GET_LED_0003}
 * 
 */
TEST_F(Led, TEST_GET_LED_0003__Succeeded) {

    uint8_t led_config = 0;

    // register value returned by mock
    uint8_t register_value = 0xA5;

    expectReadRegister(register_address_led, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_led(valid_osal_id, &led_config));

    EXPECT_EQ(register_value, led_config);
}

/*!
 * \ingroup tc_led
 * \brief Check set led pin
 * 
 * \Description{
 *   - check set led pin
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check the send buffer to set led pin
 *
 * \TestID{TEST_SET_LED_PIN_0001}
 * 
 */
TEST_F(Led, TEST_SET_LED_PIN_0001__Succeeded) {

    uint8_t register_value_to_read = 0xA5;
    uint8_t register_value_to_write = register_value_to_read | select_led_bit;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_config, register_value_to_write};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // prepare the mocks
    expectReadRegister(register_address_config, register_value_to_read, ERR_SUCCESS);
    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, set_led_pin(valid_osal_id));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_led
 * \brief Check set led pin
 * 
 * \Description{
 *   - check response if read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *
 * \TestID{TEST_SET_LED_PIN_0002}
 * 
 */
TEST_F(Led, TEST_SET_LED_PIN_0002__ReadRegisterFailed) {

    uint8_t register_value_to_read = 0xA5;

    expectReadRegister(register_address_config, register_value_to_read, special_error_code);

    EXPECT_EQ(special_error_code, set_led_pin(valid_osal_id));
}

/*!
 * \ingroup tc_led
 * \brief Check set led pin
 * 
 * \Description{
 *   - check response if write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *
 * \TestID{TEST_SET_LED_PIN_0003}
 * 
 */
TEST_F(Led, TEST_SET_LED_PIN_0003__WriteRegisterFailed) {

    uint8_t register_value_to_read = 0xA5;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // prepare the mocks
    expectReadRegister(register_address_config, register_value_to_read, ERR_SUCCESS);
    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, set_led_pin(valid_osal_id));
}

}