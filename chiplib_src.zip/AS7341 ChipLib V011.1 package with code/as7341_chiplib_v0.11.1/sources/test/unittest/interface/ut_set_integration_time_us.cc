/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _param {
    uint32_t time_us;
    uint16_t astep;
    uint8_t atime;
};

/**** test class ********************************************************/

class SetIntegrationTimeUs : public ::TestFixtureInterface,
                             public WithParamInterface<_param> {

protected:
    // register address to read astep from: AS7341_REGADDR_ASTEP
    uint8_t register_address_astep = 0xCA;
    // register address to read atime from: AS7341_REGADDR_ATIME
    uint8_t register_address_atime = 0x81;

public:
    void SetUp() {
        // init astep and atime in device configuration
        g_device_config[valid_device_id].astep = 0;
        g_device_config[valid_device_id].atime = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_integration_time_us as7341_set_integration_time_us
*
* Test cases for as7341_set_integration_time_us.
*
*
*/

/*!
 * \ingroup tc_set_integration_time_us
 * \brief Check set integration time
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_INTEGRATION_TIME_US_0001}
 *
 */
TEST_F(SetIntegrationTimeUs, TEST_SET_INTEGRATION_TIME_US_0001__DeviceIdIsInvalid) {

    // dummy
    uint32_t time_us = 10;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_integration_time_us(invalid_osal_id, time_us));
}

/*!
 * \ingroup tc_set_integration_time_us
 * \brief Check set integration time
 *
 * \Description{
 *   - check response to invalid integration time
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with integration time is too small or too big
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_INTEGRATION_TIME_US_0002}
 *
 */
TEST_F(SetIntegrationTimeUs, TEST_SET_INTEGRATION_TIME_US_0002__IntegrationTimeIsInvalid) {

    // integration time is too small: less than 6 (MIN_ITIME_US)
    EXPECT_EQ(ERR_ARGUMENT, as7341_set_integration_time_us(valid_osal_id, 5));

    // integration time is too big: bigger than 46602667 (MAX_ITIME_US)
    EXPECT_EQ(ERR_ARGUMENT, as7341_set_integration_time_us(valid_osal_id, 46602668));
}

/*!
 * \ingroup tc_set_integration_time_us
 * \brief Check set integration time
 *
 * \Description{
 *   - check response to as7341_set_astep failed
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data (as7341_set_astep) returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that astep is not saved in device configuration
 *   - check that atime is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_INTEGRATION_TIME_US_0003}
 *
 */
TEST_F(SetIntegrationTimeUs, TEST_SET_INTEGRATION_TIME_US_0003__SetAstepFailed) {

    // integration time to set
    uint32_t time_us = 10;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_integration_time_us(valid_osal_id, time_us));

    EXPECT_EQ(g_device_config[valid_device_id].astep, 0);
    EXPECT_EQ(g_device_config[valid_device_id].atime, 0);
}

/*!
 * \ingroup tc_set_integration_time_us
 * \brief Check set integration time
 *
 * \Description{
 *   - check response to as7341_set_atime failed
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data (as7341_set_astep) returns ERR_SUCCESS
 *   - mock function for osal_transfer_data (as7341_set_atime) returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that astep is saved in device configuration
 *   - check that the actual and expected send buffer for set_astep are equal
 *   - check that atime is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_INTEGRATION_TIME_US_0004}
 *
 */
TEST_F(SetIntegrationTimeUs, TEST_SET_INTEGRATION_TIME_US_0004__SetAtimeFailed) {

    // integration time to set
    uint32_t time_us = 10;

    // astep - calculated with excel
    uint16_t astep = 3;

    // (1) as7341_set_astep
    // expected send buffer transfer to mock
    uint8_t expected_send_buf_1[] = {register_address_astep, (uint8_t)(astep & 0xFF), (uint8_t)(astep >> 8)};
    // actual send buffer
    uint8_t actual_send_buf_1[] = {0, 0, 0};
    // --> returns ERR_SUCESS
    expectWriteRegister_without_check(actual_send_buf_1, sizeof(actual_send_buf_1), ERR_SUCCESS);

    // (2) as7341_set_atime
    // actual send buffer
    uint8_t actual_send_buf_2[] = {0, 0};
    // --> returns an error code
    expectWriteRegister_without_check(actual_send_buf_2, sizeof(actual_send_buf_2), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_integration_time_us(valid_osal_id, time_us));

    EXPECT_EQ(g_device_config[valid_device_id].astep, astep);
    EXPECT_EQ(g_device_config[valid_device_id].atime, 0);

    // check (1)
    EXPECT_THAT(expected_send_buf_1, ElementsAreArray(actual_send_buf_1, sizeof(actual_send_buf_1)));
}

/*!
 * \ingroup tc_set_integration_time_us
 * \brief Check set integration time
 *
 * \Description{
 *   - check response to set integration time is succeeded
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data (as7341_set_astep) returns ERR_SUCCESS
 *   - mock function for osal_transfer_data (as7341_set_atime) returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is ERR_CODE
 *   - check that astep is saved in device configuration
 *   - check that the actual and expected send buffer for set_astep are equal
 *   - check that atime is saved in device configuration
 *   - check that the actual and expected send buffer for set_atime are equal
 * }
 *
 * \TestID{TEST_SET_INTEGRATION_TIME_US_0005}
 *
 */
TEST_P(SetIntegrationTimeUs, TEST_SET_INTEGRATION_TIME_US_0005__CheckAtimeAndAstep) {

    // get the next test parameter structure
    _param my_param = GetParam();

    // integration time to set
    uint32_t time_us = my_param.time_us;

    // (1) as7341_set_astep
    // expected astep
    uint16_t astep = my_param.astep;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf_1[] = {register_address_astep, (uint8_t)(astep & 0xFF), (uint8_t)(astep >> 8)};
    // actual send buffer
    uint8_t actual_send_buf_1[] = {0, 0, 0};
    // --> returns ERR_SUCESS
    expectWriteRegister_without_check(actual_send_buf_1, sizeof(actual_send_buf_1), ERR_SUCCESS);

    // (2) as7341_set_atime
    // expected atime
    uint8_t atime = my_param.atime;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf_2[] = {register_address_atime, atime};
    // actual send buffer
    uint8_t actual_send_buf_2[] = {0, 0};
    // --> returns an error code
    expectWriteRegister_without_check(actual_send_buf_2, sizeof(actual_send_buf_2), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_integration_time_us(valid_osal_id, time_us));

    EXPECT_EQ(g_device_config[valid_device_id].astep, astep);
    EXPECT_EQ(g_device_config[valid_device_id].atime, atime);

    // check (1)
    EXPECT_THAT(expected_send_buf_1, ElementsAreArray(actual_send_buf_1, sizeof(actual_send_buf_1)));

    // check (2)
    EXPECT_THAT(expected_send_buf_2, ElementsAreArray(actual_send_buf_2, sizeof(actual_send_buf_2)));
}

/**** parameterized test cases ********************************************************/
// Values for astep and atime are calculated with excel but in accordance with the code.
_param my_array[] = { {6, 1, 0}, {30000000, 42187, 255}, {10000000, 33027, 108} };

INSTANTIATE_TEST_SUITE_P(IntegrationTimeUs, SetIntegrationTimeUs, ValuesIn(my_array));

}