/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;

namespace ChipLibUnittest {

/**** test class ********************************************************/

struct _param {
    uint8_t long_time_param;
    uint8_t enable_param;
};

class SetWaitTime : public TestFixtureInterface,
                    public WithParamInterface<_param> {

protected:
    // register address to read wtime from: AS7341_REGADDR_WTIME
    uint8_t register_address_wtime = 0x83;
    // register address to switch memory bank: AS7341_REGADDR_CFG0
    uint8_t register_address_cfg0 = 0xA9;
    // register address to set wait time to: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;

public:
    void SetUp() {
        // init long wait time in device configuration
        g_device_config[valid_device_id].long_wait_time = 0;
        // init register enable in device configuration
        g_device_config[valid_device_id].register_enable = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_wait_time as7341_set_wait_time
*
* Test cases for as7341_set_wait_time.
*
*
*/

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0001}
 *
 */
TEST_F(SetWaitTime, TEST_SET_WAIT_TIME_0001__DeviceIdIsInvalid) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_wait_time(invalid_osal_id, wtime, enable, long_time));
}

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check response if switch memory bank failed
 * }
 *
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0002}
 *
 */
TEST_F(SetWaitTime, TEST_SET_WAIT_TIME_0002__SwitchToMemoryBankFailed) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    expectWriteRegister(register_address_cfg0, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_wait_time(valid_osal_id, wtime, enable, long_time));
}

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check response if write register <wait time> failed
 * }
 *
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <wait time> --> osal_transfer_data returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock for write register <wait time>
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0003}
 *
 */
TEST_F(SetWaitTime, TEST_SET_WAIT_TIME_0003__SetWaitTimeRegisterFailed) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);

    expectWriteRegister(register_address_wtime, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_wait_time(valid_osal_id, wtime, enable, long_time));
}

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check response if write register <enable> failed
 * }
 *
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <wait time> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock for write register <enable>
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0004}
 *
 */
TEST_F(SetWaitTime, TEST_SET_WAIT_TIME_0004__SetEnableRegisterFailed) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);

    expectWriteRegister(register_address_wtime, ERR_SUCCESS);

    expectWriteRegister(register_address_enable, special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_wait_time(valid_osal_id, wtime, enable, long_time));
}

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check response if set wait time succeeded
 * }
 *
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <wait time> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0005}
 *
 */
TEST_F(SetWaitTime, TEST_SET_WAIT_TIME_0005__SetWaitTimeSucceeded) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);

    expectWriteRegister(register_address_wtime, ERR_SUCCESS);

    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_wait_time(valid_osal_id, wtime, enable, long_time));
}

/*!
 * \ingroup tc_set_wait_time
 * \brief Check set wait time
 *
 * \Description{
 *   - check change of device configuration using parameterized test
 * }
 *
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <wait time> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check changes of device configuration values long_wait_time, register_enable
 * }
 *
 * \TestID{TEST_SET_WAIT_TIME_0006}
 *
 */
TEST_P(SetWaitTime, TEST_SET_WAIT_TIME_0006__CheckDeviceConfiguration) {

    // dummies
    uint8_t wtime = 0;

    // get the next test parameter structure
    _param my_param = GetParam();
    uint8_t long_time = my_param.long_time_param;
    uint8_t enable = my_param.enable_param;

    // prepare device configuration to check changes
    g_device_config[valid_device_id].long_wait_time = (0 != long_time) ? 0 : 1;
    g_device_config[valid_device_id].register_enable = (0 != enable) ? 0 : 0xFF;

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);

    expectWriteRegister(register_address_wtime, ERR_SUCCESS);

    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_wait_time(valid_osal_id, wtime, enable, long_time));

    // check device configuration
    // (1) long_wait_time
    //    is changed 0 --> 1 if long_time is not 0
    //    is changed 1 --> 0 if long_time is 0
    uint8_t expected_long_time = (0 != long_time) ? 1 : 0;
    EXPECT_EQ(g_device_config[valid_device_id].long_wait_time, expected_long_time);
    // (2) register_enable, handle important bit 4 (REG_ENABLE_BIT_WEN)
    //    is changed 0x00 --> 0x08 if enable is not 0
    //    is changed 0xFF --> 0xF7 if enable is 0
    uint8_t expected_enable = (0 != enable) ? 0x08 : 0xF7;
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, expected_enable);
}

/**** parameterized test cases ********************************************************/
_param my_array[] = { {0, 0}, {0, 1}, {0, 2}, {1, 0}, {1, 1}, {1, 2}, {2, 0}, {2, 1}, {2, 2} };

INSTANTIATE_TEST_SUITE_P(DeviceConfig, SetWaitTime, ValuesIn(my_array));

}