/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetFifoIntegrationTimeUs : public ::TestFixtureInterface {

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_fifo_integration_time_us as7341_get_fifo_integration_time_us
*
* Test cases for as7341_get_fifo_integration_time_us.
*
*
*/

/*!
 * \ingroup tc_get_fifo_integration_time_us
 * \brief Check get integration time for fifo
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FIFO_INTEGRATION_TIME_US_0001}
 * 
 */
TEST_F(GetFifoIntegrationTimeUs, TEST_GET_FIFO_INTEGRATION_TIME_US_0001__DeviceIdIsInvalid) {

    // dummy
    uint32_t time_us = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_fifo_integration_time_us(invalid_osal_id, &time_us));
}

/*!
 * \ingroup tc_get_fifo_integration_time_us
 * \brief Check get integration time for fifo
 * 
 * \Description{
 *   - check response to null pointer for time_us
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for time_us
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FIFO_INTEGRATION_TIME_US_0002}
 * 
 */
TEST_F(GetFifoIntegrationTimeUs, TEST_GET_FIFO_INTEGRATION_TIME_US_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_fifo_integration_time_us(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_fifo_integration_time_us
 * \brief Check get integration time for fifo
 * 
 * \Description{
 *   - check response to get fifo integration time succeeded
 * }
 * 
 * \Preconditions{
 *   - set element ftime in device configuration
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid pointer for time_us
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check output time_us
 * }
 *
 * \TestID{TEST_GET_FIFO_INTEGRATION_TIME_US_0003}
 * 
 */
TEST_F(GetFifoIntegrationTimeUs, TEST_GET_FIFO_INTEGRATION_TIME_US_0003__Success) {

    uint32_t time_us = 0;
    
    // prepare device configuration
    g_device_config[valid_device_id].ftime = 1;

    // calculate expected time_us
    uint32_t expected_time_us = ((((uint32_t)g_device_config[valid_device_id].ftime + 1) * 
        INTEGRATION_TIME_STEP_US_FACTOR * 10 / INTEGRATION_TIME_STEP_US_DIVIDER) + 5) / 10;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_fifo_integration_time_us(valid_osal_id, &time_us));

    EXPECT_EQ(expected_time_us, time_us);
}

}