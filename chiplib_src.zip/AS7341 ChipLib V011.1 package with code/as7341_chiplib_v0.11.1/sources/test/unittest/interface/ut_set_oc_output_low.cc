/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _param {
    uint8_t reg_gpio2;
    uint8_t is_low;
    uint8_t expected_reg_gpio2;
};

/**** test class ********************************************************/

class SetOcOutputLow : public ::TestFixtureInterface,
                       public WithParamInterface<_param> {

protected:
    // register address to read oc_output_low from: AS7341_REGADDR_GPIO2
    uint8_t register_address_gpio2 = 0xBE;
    // register mask: REG_BIT_GPIO_2_GPIO_OUT_MSK
    uint8_t gpio_out_mask = 0x02;

public:
    void SetUp() {

    }
};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_oc_output_low as7341_set_oc_output_low
*
* Test cases for as7341_set_oc_output_low.
*
*
*/

/*!
 * \ingroup tc_set_oc_output_low
 * \brief Check set oc output low
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_OC_OUTPUT_LOW_0001}
 *
 */
TEST_F(SetOcOutputLow, TEST_SET_OC_OUTPUT_LOW_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t is_low = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_oc_output_low(invalid_osal_id, is_low));
}

/*!
 * \ingroup tc_set_oc_output_low
 * \brief Check set oc output low
 *
 * \Description{
 *   - check response to write register failed
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid is_low value
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_SET_OC_OUTPUT_LOW_0003}
 *
 */
TEST_F(SetOcOutputLow, TEST_SET_OC_OUTPUT_LOW_0003__WriteRegisterFailed) {

    // is_low to set
    uint8_t is_low = 5;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_oc_output_low(valid_osal_id, is_low));
}

/*!
 * \ingroup tc_set_oc_output_low
 * \brief Check set oc output low
 *
 * \Description{
 *   - check response to write register succeeded
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid is_low
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that the actual and expected send buffer for write register are equal
 * }
 *
 * \TestID{TEST_SET_OC_OUTPUT_LOW_0004}
 *
 */
TEST_F(SetOcOutputLow, TEST_SET_OC_OUTPUT_LOW_0004__WriteRegisterSucceeded) {

    // calculate reg_gpio2:
    // depends on g_device_config[valid_device_id].register_gpio_2 and argument is_low
    g_device_config[valid_device_id].register_gpio_2 = 0;
    uint8_t is_low = 5;
    uint8_t reg_gpio2 = g_device_config[valid_device_id].register_gpio_2;
    reg_gpio2 = (is_low != 0) ? reg_gpio2 & ~gpio_out_mask : reg_gpio2 | gpio_out_mask;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_gpio2, reg_gpio2};
    uint8_t buf_size = sizeof(expected_send_buf);
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_oc_output_low(valid_osal_id, is_low));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, buf_size));

    EXPECT_EQ(reg_gpio2, g_device_config[valid_device_id].register_gpio_2);
}

/*!
 * \ingroup tc_set_oc_output_low
 * \brief Check set oc output low
 *
 * \Description{
 *   - check setting of register_gpio_2 using paramerized test
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid is_low
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that the actual and expected register_gpio_2 are equal
 * }
 *
 * \TestID{TEST_SET_OC_OUTPUT_LOW_0004}
 *
 */
TEST_P(SetOcOutputLow, TEST_SET_OC_OUTPUT_LOW_0005__CheckRegisterGpio2) {

    // get the next test parameter structure
    _param my_param = GetParam();

    g_device_config[valid_device_id].register_gpio_2 = my_param.reg_gpio2;
    uint8_t is_low = my_param.is_low;

    // expected reg_gpio2
    uint8_t reg_gpio2 = my_param.expected_reg_gpio2;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_gpio2, reg_gpio2};
    uint8_t buf_size = sizeof(expected_send_buf);
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_oc_output_low(valid_osal_id, is_low));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, buf_size));

    EXPECT_EQ(reg_gpio2, g_device_config[valid_device_id].register_gpio_2);

    std::array<s_debug_output, 3> my_debug = {{
        {"gpio2", my_param.reg_gpio2},
        {"is_low", my_param.is_low},
        {"expected_reg_gpio2", my_param.expected_reg_gpio2}
    }};
    debug_output(my_debug);
}

/**** parameterized test cases ********************************************************/
_param my_array[] = { {0, 0, 0x02}, {0, 1, 0}, {0x02, 0, 0x02}, {0x02, 1, 0}, {0xFF, 0, 0xFF}, {0xFF, 1, 0xFD} };

INSTANTIATE_TEST_SUITE_P(RegisterGpio2, SetOcOutputLow, ValuesIn(my_array));

}