/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#ifndef __TEST_FIXTURE_INTERFACE_H__
#define __TEST_FIXTURE_INTERFACE_H__

#include "as7341_interface.h"
#include "as7341_typedefs.h"

#include "osal_mock_interface.h"

using ::testing::Matcher;

namespace ChipLibUnittest {

/**** special matcher  *******************************************************/

// can be used in mock functions to check arguments of type osal_id_t
MATCHER_P(EqOsalId, expected_osal_id, "") {
    return arg.chip == expected_osal_id.chip && arg.dev == expected_osal_id.dev;
}

// can be used in mock functions to check array arguments
MATCHER_P2(EqArray, expected_array, n, "") {
    for (int i = 0; i < n; i++) {
        if (expected_array[i] != arg[i]) {
            return false;
        }
    }
    return true; 
}

/**** special action  ********************************************************/

// action to store the array p_send_data 
// which is input for mock_osal_transfer_data()
// spectral_osal_transfer_data(osal_id_t osal_id, 
//                             uint8_t *p_send_data, uint8_t send_data_size,
//                             uint8_t *p_receive_data, uint8_t receive_data_size)
ACTION_P(SaveArray, expected_array) {
    memcpy(expected_array, arg1, arg2);
}

/**** special structure  ********************************************************/
struct s_debug_output {
    std::string param_name;
    int param_value;
};

// Create a TestFixture
class TestFixtureInterface: public ::testing::Test {
protected:
    void SetUp() override;
    void TearDown() override;

    void debug_output(const std::array<s_debug_output, 3> &debug_output);
    void expectReadRegister(uint8_t register_address, uint8_t register_value, err_code_t return_code);
    void expectReadData(uint8_t register_address, uint16_t *data, uint8_t number_of_data, err_code_t return_code);
    void expectReadBytes(uint8_t register_address, uint8_t *bytes, uint8_t number_of_bytes, err_code_t return_code);
    void expectReadBytes_without_send(uint8_t *bytes, uint8_t number_of_bytes, err_code_t return_code);
    void expectWriteRegister(uint8_t register_address, err_code_t return_code);
    void expectWriteBytes(uint8_t register_address, uint8_t number_of_bytes, err_code_t return_code);
    void expectWriteRegister_without_check(uint8_t *actual_send_buffer, uint8_t buf_size, err_code_t return_code);
    void expectWriteRegister_with_check(uint8_t *expected_send_buffer, err_code_t return_code);

public:
    TestFixtureInterface();
    ~TestFixtureInterface();

    // pointer for accessing mocked libraries
    static std::unique_ptr<OSAL_MOCK> _osal_mock;

protected:
    // valid device id
    const uint8_t valid_device_id = 0;
    // valid osal id
    const osal_id_t valid_osal_id = {CHIP_LIB_IDENT, valid_device_id};
 
    // invalid device id
    const uint8_t invalid_device_id = 2;
    // invalid osal id
    const osal_id_t invalid_osal_id = {CHIP_LIB_IDENT, invalid_device_id};
    
    // special error code, not defined in enum AS7341_ERROR_CODES
    err_code_t special_error_code = (err_code_t)99;

};

}

#endif // __TEST_FIXTURE_INTERFACE_H__
