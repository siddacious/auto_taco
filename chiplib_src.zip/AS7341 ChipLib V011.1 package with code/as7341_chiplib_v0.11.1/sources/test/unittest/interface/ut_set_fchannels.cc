/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _one_channel {
    uint32_t channel_bit;
    uint8_t fsmux_config_index;
    uint8_t fsmux_value;
};

struct _two_channels {
    _one_channel channel_1;
    _one_channel channel_2;
};

/**** data for parameterized test *********************************/

// Values for channel_bit, fsmux_config_index and fsmux_value are calculated with excel but in accordance with the code.
_one_channel test_array_1[] = {
    /* SMUX_F1_1 */     {1, 2, 6},          /* SMUX_F1_2 */     {2, 17, 6},
    /* SMUX_F2_1 */     {4, 6, 6},          /* SMUX_F2_2 */     {8, 13, 96},
    /* SMUX_F3_1 */     {16, 1, 96},        /* SMUX_F3_2 */     {32, 16, 96},
    /* SMUX_F4_1 */     {64, 6, 96},        /* SMUX_F4_2 */     {128, 14, 6},
    /* SMUX_F5_1 */     {256, 7, 96},       /* SMUX_F5_2 */     {512, 10, 96},
    /* SMUX_F6_1 */     {1024, 5, 6},       /* SMUX_F6_2 */     {2048, 15, 96},
    /* SMUX_F7_1 */     {4096, 8, 6},       /* SMUX_F7_2 */     {8192, 11, 6},
    /* SMUX_F8_1 */     {16384, 4, 96},     /* SMUX_F8_2 */     {32768, 15, 6},
    /* SMUX_CLEAR_1 */  {65536, 9, 96},     /* SMUX_CLEAR_2 */  {131072, 18, 96},
    /* SMUX_NIR */      {262144, 20, 6},    /* SMUX_FLICKER */  {524288, 20, 96},
};

_two_channels test_array_2[] = {
    {/* SMUX_F2_1 */     {4, 6, 6},         /* SMUX_F4_1 */     {64, 6, 96}, },
    {/* SMUX_F6_2 */     {2048, 15, 96},    /* SMUX_F8_2 */     {32768, 15, 6}, },
    {/* SMUX_NIR */      {262144, 20, 6},   /* SMUX_FLICKER */  {524288, 20, 96},},
};


/**** test class ********************************************************/

class SetFchannels : public ::TestFixtureInterface,
                     public WithParamInterface<_one_channel> {

public:
    void SetUp() {

        memset(g_device_config[valid_device_id].fsmux_config, 0xFF, SIZE_OF_SMUX_BUFFER);
    }

};

class SetFchannels2 : public ::TestFixtureInterface,
                      public WithParamInterface<_two_channels> {

public:
    void SetUp() {

        memset(g_device_config[valid_device_id].fsmux_config, 0xFF, SIZE_OF_SMUX_BUFFER);
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_fchannels as7341_set_fchannels
*
* Test cases for as7341_set_fchannels.
*
*
*/

/*!
 * \ingroup tc_set_fchannels
 * \brief Check set channels for flicker detection
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FCHANNELS_0001}
 *
 */
TEST_F(SetFchannels, TEST_SET_FCHANNELS_0001__DeviceIdIsInvalid) {

    // dummy
    uint32_t fchannels = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fchannels(invalid_osal_id, fchannels));
}

/*!
 * \ingroup tc_set_fchannels
 * \brief Check set channels for flicker detection
 *
 * \Description{
 *   - check response to as7341_set_fchannels succeeded
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid fchannels value
 * }
 *
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check element fchannels in device configuration
 *   - check element fsmux_config in device configuration
 * }
 *
 * \TestID{TEST_SET_FCHANNELS_0002}
 *
 */
TEST_F(SetFchannels, TEST_SET_FCHANNELS_0002__FChannelIsZero) {

    // fchannels to set
    uint32_t fchannels = 0;

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fchannels(valid_osal_id, fchannels));

    EXPECT_EQ(g_device_config[valid_device_id].fchannels, fchannels);

    // expected fsmux_config
    uint8_t expected_fsmux_config[SIZE_OF_SMUX_BUFFER] = {0};
    EXPECT_THAT(g_device_config[valid_device_id].fsmux_config, ElementsAreArray(expected_fsmux_config, SIZE_OF_SMUX_BUFFER));
}

/*!
 * \ingroup tc_set_fchannels
 * \brief Check set channels for flicker detection
 *
 * \Description{
 *   - check response to as7341_set_fchannels succeeded
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid fchannels value
 * }
 *
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check element fchannels in device configuration
 *   - check element fsmux_config in device configuration
 * }
 *
 * \TestID{TEST_SET_FCHANNELS_0003}
 *
 */
TEST_F(SetFchannels, TEST_SET_FCHANNELS_0003__AllFChannels) {

    // fchannels to set: all 20 channels
    uint32_t fchannels = 0x000FFFFF;

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fchannels(valid_osal_id, fchannels));

    EXPECT_EQ(g_device_config[valid_device_id].fchannels, fchannels);

    // expected fsmux_config
    uint8_t expected_fsmux_config[SIZE_OF_SMUX_BUFFER] = {0};
    for (unsigned int i = 0; i < sizeof(test_array_1) / sizeof(_one_channel); i++) {
        expected_fsmux_config[test_array_1[i].fsmux_config_index] |= test_array_1[i].fsmux_value;
    }
    EXPECT_THAT(g_device_config[valid_device_id].fsmux_config, ElementsAreArray(expected_fsmux_config, SIZE_OF_SMUX_BUFFER));
}

/*!
 * \ingroup tc_set_fchannels
 * \brief Check set channels for flicker detection
 *
 * \Description{
 *   - check response to as7341_set_fchannels succeeded
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid fchannels value
 * }
 *
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check element fchannels in device configuration
 *   - check element fsmux_config in device configuration
 * }
 *
 * \TestID{TEST_SET_FCHANNELS_0004}
 *
 */
TEST_P(SetFchannels, TEST_SET_FCHANNELS_0004__CheckFsmuxOneChannel) {

    // get the next test parameter structure
    _one_channel my_param = GetParam();

    // fchannels to set
    uint32_t fchannels = my_param.channel_bit;

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fchannels(valid_osal_id, fchannels));

    EXPECT_EQ(g_device_config[valid_device_id].fchannels, fchannels);

    // expected fsmux_config: only one channel
    uint8_t expected_fsmux_config[SIZE_OF_SMUX_BUFFER] = {0};
    expected_fsmux_config[my_param.fsmux_config_index] = my_param.fsmux_value;
    EXPECT_THAT(g_device_config[valid_device_id].fsmux_config, ElementsAreArray(expected_fsmux_config, SIZE_OF_SMUX_BUFFER));
}

/*!
 * \ingroup tc_set_fchannels
 * \brief Check set channels for flicker detection
 *
 * \Description{
 *   - check response to as7341_set_fchannels succeeded
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid fchannels value
 * }
 *
 * \Expectations{
 *   - return code ERR_SUCCESS
 *   - check element fchannels in device configuration
 *   - check element fsmux_config in device configuration
 * }
 *
 * \TestID{TEST_SET_FCHANNELS_0005}
 *
 */
TEST_P(SetFchannels2, TEST_SET_FCHANNELS_0005__CheckFsmuxTwoChannels) {

    // get the next test parameter structure
    _two_channels my_param = GetParam();

    // fchannels to set
    uint32_t fchannels = my_param.channel_1.channel_bit + my_param.channel_2.channel_bit;

    EXPECT_EQ(ERR_SUCCESS, as7341_set_fchannels(valid_osal_id, fchannels));

    EXPECT_EQ(g_device_config[valid_device_id].fchannels, fchannels);

    // expected fsmux_config: two channels are combined at the same index
    uint8_t expected_fsmux_config[SIZE_OF_SMUX_BUFFER] = {0};
    expected_fsmux_config[my_param.channel_1.fsmux_config_index] = my_param.channel_1.fsmux_value | my_param.channel_2.fsmux_value;
    EXPECT_THAT(g_device_config[valid_device_id].fsmux_config, ElementsAreArray(expected_fsmux_config, SIZE_OF_SMUX_BUFFER));
}

/**** parameterized test cases ********************************************************/

INSTANTIATE_TEST_SUITE_P(FChannels1, SetFchannels, ValuesIn(test_array_1));

INSTANTIATE_TEST_SUITE_P(FChannels2, SetFchannels2, ValuesIn(test_array_2));

}