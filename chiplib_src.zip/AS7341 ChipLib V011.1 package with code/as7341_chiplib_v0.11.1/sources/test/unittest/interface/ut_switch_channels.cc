/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SwitchChannels : public TestFixtureInterface {

protected:
    // register address to switch memory bank to: AS7341_REGADDR_CFG0
    uint8_t register_address_cfg0 = 0xA9;
    // register address to write to smux chain to: AS7341_REGADDR_CFG6
    uint8_t register_address_cfg6 = 0xAF;
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;

public:
    // valid size for smux config is SIZE_OF_SMUX_BUFFER
    static const uint8_t smux_buffer_size = 21;

    void SetUp() {
        // init long wait time in device configuration
        g_device_config[valid_device_id].long_wait_time = 0;
        // init register enable in device configuration
        g_device_config[valid_device_id].register_enable = 0;

        // Init with a value which does not match the other register addresses!
        //  smux config block 0
        memset(g_device_config[valid_device_id].smux_config[0], 0x66, smux_buffer_size);
        //  smux config block 1
        memset(g_device_config[valid_device_id].smux_config[1], 0x77, smux_buffer_size);
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_switch_channels as7341_switch_channels
*
* Test cases for as7341_switch_channels.
*
*
*/

/*!
 * \ingroup tc_switch_channels
 * \brief Check switch channels
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SWITCH_CHANNELS_0001}
 * 
 */
TEST_F(SwitchChannels, TEST_SWITCH_CHANNELS_0001__NullPointer) {

    // dummy
    uint8_t block = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_switch_channels(invalid_osal_id, block));
}

/*!
 * \ingroup tc_switch_channels
 * \brief Check switch channels
 * 
 * \Description{
 *   - check response if argument block is too big
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and block is too big
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SWITCH_CHANNELS_0002}
 * 
 */
TEST_F(SwitchChannels, TEST_SWITCH_CHANNELS_0002__BlockIsTooBig) {

    // block is 2 (MAX_SUPPORTED_CHANNEL_BLOCKS)
    uint8_t block = 2;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_switch_channels(valid_osal_id, block));
}

/*!
 * \ingroup tc_switch_channels
 * \brief Check switch channels
 * 
 * \Description{
 *   - check response if set smux config succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and a valid block
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_SWITCH_CHANNELS_0003}
 * 
 */
TEST_F(SwitchChannels, TEST_SWITCH_CHANNELS_0003__Success) {

    // block is valid
    uint8_t block = 0;

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 0
    uint8_t my_array1[2] = {register_address_cfg0, 0x00};
    expectWriteRegister_with_check(my_array1, ERR_SUCCESS);
  
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(g_device_config[valid_device_id].smux_config[block][0], smux_buffer_size, ERR_SUCCESS);
   
    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 1
    uint8_t my_array2[2] = {register_address_cfg0, 0x10};
    expectWriteRegister_with_check(my_array2, ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, as7341_switch_channels(valid_osal_id, block));
}

}