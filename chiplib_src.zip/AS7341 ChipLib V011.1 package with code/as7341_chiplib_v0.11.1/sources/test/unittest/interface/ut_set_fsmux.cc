/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetFsmux : public TestFixtureInterface {

protected:
    // register address to switch memory bank to: AS7341_REGADDR_CFG0
    uint8_t register_address_cfg0 = 0xA9;
    // register address to write to smux chain to: AS7341_REGADDR_CFG6
    uint8_t register_address_cfg6 = 0xAF;
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;

public:
    // valid size for smux config is SIZE_OF_SMUX_BUFFER
    static const uint8_t smux_buffer_size = 21;

    void SetUp() {
        // init long time in device configuration
        g_device_config[valid_device_id].long_wait_time = 0;
        // init register enable in device configuration
        g_device_config[valid_device_id].register_enable = 0;

        // // Init with a value which does not match the other register addresses!
        memset(g_device_config[valid_device_id].fsmux_config, 0x99, smux_buffer_size);
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_fsmux as7341_set_fsmux
*
* Test cases for as7341_set_fsmux.
*
*
*/

/*!
 * \ingroup tc_set_fsmux
 * \brief Check set smux for flicker
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_FSMUX_0001}
 * 
 */
TEST_F(SetFsmux, TEST_SET_FSMUX_0001__DeviceIdIsInvalid) {

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_fsmux(invalid_osal_id));
}

/*!
 * \ingroup tc_set_fsmux
 * \brief Check set smux for flicker
 * 
 * \Description{
 *   - check response if set_smux_config failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_SET_FSMUX_0002}
 * 
 */
TEST_F(SetFsmux, TEST_SET_FSMUX_0002__SetSmuxConfigFailed) {

    expectWriteRegister(register_address_cfg0, special_error_code);
   
    EXPECT_EQ(special_error_code, as7341_set_fsmux(valid_osal_id));
}

/*!
 * \ingroup tc_set_fsmux
 * \brief Check set smux for flicker
 * 
 * \Description{
 *   - check response if set_smux_config succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_SET_FSMUX_0003}
 * 
 */
TEST_F(SetFsmux, TEST_SET_FSMUX_0003__Success) {

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 0
    uint8_t my_array1[] = {register_address_cfg0, 0x00};
    expectWriteRegister_with_check(my_array1, ERR_SUCCESS);
  
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(g_device_config[valid_device_id].fsmux_config[0], smux_buffer_size, ERR_SUCCESS);
   
    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 1
    uint8_t my_array2[] = {register_address_cfg0, 0x10};
    expectWriteRegister_with_check(my_array2, ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, as7341_set_fsmux(valid_osal_id));
}

}