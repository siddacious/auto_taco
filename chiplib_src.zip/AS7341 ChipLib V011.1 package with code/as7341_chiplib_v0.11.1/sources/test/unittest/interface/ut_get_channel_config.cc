/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetChannelConfig : public TestFixtureInterface {

protected:
    // CHANNEL_NUMBER
    const uint8_t channel_number = 12;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_channel_config as7341_get_channel_config
*
* Test cases for as7341_get_channel_config.
*
*
*/

/*!
 * \ingroup tc_get_channel_config
 * \brief Check get channel config
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_CHANNEL_CONFIG_0001}
 * 
 */
TEST_F(GetChannelConfig, TEST_GET_CHANNEL_CONFIG_0001__InvalidDeviceId) {

    // dummy
    uint8_t channel_config[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_get_channel_config(invalid_osal_id, channel_config, channel_number));
}

/*!
 * \ingroup tc_get_channel_config
 * \brief Check get channel config
 * 
 * \Description{
 *   - check response to null pointer for channel_config
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for channel_config
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_CHANNEL_CONFIG_0002}
 * 
 */
TEST_F(GetChannelConfig, TEST_GET_CHANNEL_CONFIG_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_channel_config(valid_osal_id, NULL, channel_number));
}

/*!
 * \ingroup tc_get_channel_config
 * \brief Check get channel config
 * 
 * \Description{
 *   - check response to invalid size
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id, a valid pointer to channel_config and an invalid size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SIZE
 *
 * \TestID{TEST_GET_CHANNEL_CONFIG_0003}
 * 
 */
TEST_F(GetChannelConfig, TEST_GET_CHANNEL_CONFIG_0003__InvalidSize) {

    // invalid size: not channel_number (CHANNEL_NUMBER)
    uint8_t invalid_size = 10;

    // dummy
    uint8_t channel_config[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    EXPECT_EQ(ERR_SIZE, as7341_get_channel_config(valid_osal_id, channel_config, invalid_size));
}

/*!
 * \ingroup tc_get_channel_config
 * \brief Check set channel config
 * 
 * \Description{
 *   - check set channel config
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id, a valid pointer to channel_config and a valid size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that get channel_config is equal channels in device config 
 *
 * \TestID{TEST_GET_CHANNEL_CONFIG_0004}
 * 
 */
TEST_F(GetChannelConfig, TEST_GET_CHANNEL_CONFIG_0004__Succeeded) {

    // init channels in device config
    for (int i = 0;  i < channel_number; i++) {
        g_device_config[valid_device_id].channels[i] = 2 * i + 1;
    }

    // init channel_config to get
    uint8_t channel_config[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    EXPECT_EQ(ERR_SUCCESS, as7341_get_channel_config(valid_osal_id, channel_config, channel_number));

    EXPECT_THAT(g_device_config[valid_device_id].channels, ElementsAreArray(channel_config, channel_number));
}

}