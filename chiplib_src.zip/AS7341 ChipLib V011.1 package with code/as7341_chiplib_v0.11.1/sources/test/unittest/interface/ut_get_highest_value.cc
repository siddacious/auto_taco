/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetHighestValue : public TestFixtureInterface {

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_highest_value as7341_get_highest_value
*
* Test cases for get highest value.
*
*
*/

/*!
 * \ingroup tc_get_highest_value
 * \brief Check get highest value
 *
 * \Description{
 *   - check response to null pointer for data
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with null pointer for data
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_HIGHEST_VALUE_0001}
 *
 */
TEST_F(GetHighestValue, TEST_GET_HIGHEST_VALUE_0001__NullPointerData) {
// as7341_get_highest_value(uint16_t *p_data, uint32_t number, uint16_t *p_highest)
    // dummies
    uint32_t number = 0;
    uint16_t highest_value;

    EXPECT_EQ(ERR_POINTER, as7341_get_highest_value(NULL, number, &highest_value));
}

/*!
 * \ingroup tc_get_highest_value
 * \brief Check get highest value
 *
 * \Description{
 *   - check response to null pointer for highest value
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with null pointer for highest value
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_HIGHEST_VALUE_0002}
 *
 */
TEST_F(GetHighestValue, TEST_GET_HIGHEST_VALUE_0002__NullPointerHighestValue) {

    // dummies
    uint16_t data[7] = { 0 };
    uint32_t number = 7;

    EXPECT_EQ(ERR_POINTER, as7341_get_highest_value(data, number, NULL));
}

/*!
 * \ingroup tc_get_highest_value
 * \brief Check get highest value
 *
 * \Description{
 *   - check get highest value
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that returned highest value and expected highest value are equal
 *
 * \TestID{TEST_GET_HIGHEST_VALUE_0003}
 *
 */
TEST_F(GetHighestValue, TEST_GET_HIGHEST_VALUE_0003__CheckHighestValue) {

    uint16_t data[7] = { 2, 4, 3, 47, 3, 4, 2 };
    uint32_t number = 7;

    uint16_t highest_value = 0;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_highest_value(data, number, &highest_value));

    EXPECT_EQ(47, highest_value);
}

}