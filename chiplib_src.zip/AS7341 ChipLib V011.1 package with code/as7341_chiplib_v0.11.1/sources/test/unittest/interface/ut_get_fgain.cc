/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetFgain : public ::TestFixtureInterface {

protected:
    // register addresses to read fgain from: AS7341_REGADDR_FD_TIME_H
    uint8_t register_address_fd_time_high = 0xDA;
    // byte shift to get fgain: FD_GAIN_REG_OFFSET
    uint8_t shift_fgain = 3;

public:
    void SetUp() {

    }

};

class GetSavedFgain : public ::TestFixtureInterface {

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_fgain as7341_get_fgain
*
* Test cases for as7341_get_fgain.
*
*
*/

/*!
 * \ingroup tc_get_fgain
 * \brief Check get flicker gain
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FGAIN_0001}
 * 
 */
TEST_F(GetFgain, TEST_GET_FGAIN_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t fgain = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_fgain(invalid_osal_id, &fgain));
}

/*!
 * \ingroup tc_get_fgain
 * \brief Check get flicker gain
 * 
 * \Description{
 *   - check response to null pointer for fgain
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for fgain
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FGAIN_0002}
 * 
 */
TEST_F(GetFgain, TEST_GET_FGAIN_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_fgain(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_fgain
 * \brief Check get flicker gain
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain buffer
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that input fgain is not changed
 * }
 *
 * \TestID{TEST_GET_FGAIN_0003}
 * 
 */
TEST_F(GetFgain, TEST_GET_FGAIN_0003__ReadRegisterFailed) {

    uint8_t fgain = 0;

    // register value returned by mock
    uint8_t register_value = 0x5C;

    expectReadRegister(register_address_fd_time_high, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_fgain(valid_osal_id, &fgain));

    EXPECT_EQ(0, fgain);
}

/*!
 * \ingroup tc_get_fgain
 * \brief Check get flicker gain
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain buffer
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected fgain is equal received fgain
 * }
 *
 * \TestID{TEST_GET_FGAIN_0004}
 * 
 */
TEST_F(GetFgain, TEST_GET_FGAIN_0004__ReadRegisterSucceeded) {

    uint8_t fgain = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    // calculate expected fgain: register value AND again mask
    uint8_t expected_fgain = register_value >> shift_fgain;

    expectReadRegister(register_address_fd_time_high, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_fgain(valid_osal_id, &fgain));

    EXPECT_EQ(expected_fgain, fgain);
}

/*!
*
* @defgroup tc_get_saved_gain as7341_get_saved_fgain
*
* Test cases for as7341_get_saved_fgain.
*
*
*/

/*!
 * \ingroup tc_get_saved_gain
 * \brief Check get saved flicker gain
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_SAVED_FGAIN_0001}
 * 
 */
TEST_F(GetSavedFgain, TEST_GET_SAVED_FGAIN_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t fgain = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_saved_fgain(invalid_osal_id, &fgain));
}

/*!
 * \ingroup tc_get_saved_gain
 * \brief Check get saved flicker gain
 * 
 * \Description{
 *   - check response to null pointer for fgain
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for fgain
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_SAVED_FGAIN_0002}
 * 
 */
TEST_F(GetSavedFgain, TEST_GET_SAVED_FGAIN_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_saved_fgain(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_saved_gain
 * \brief Check get saved flicker gain
 * 
 * \Description{
 *   - check response to get saved fgain succeeded
 * }
 * 
 * \Preconditions{
 *   - set element fgain in device configuration
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid fgain buffer
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that element fgain in device configuration is equal received fgain
 * }
 *
 * \TestID{TEST_GET_SAVED_FGAIN_0003}
 * 
 */
TEST_F(GetSavedFgain, TEST_GET_SAVED_FGAIN_0003__Success) {

    uint8_t fgain = 0;
    
    // prepare device configuration
    g_device_config[valid_device_id].fgain = 0x78;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_saved_fgain(valid_osal_id, &fgain));

    EXPECT_EQ(g_device_config[valid_device_id].fgain, fgain);
}

}