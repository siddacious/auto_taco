/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class Start : public ::TestFixtureInterface {

protected:
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;
    // register address to write register control: AS7341_REGADDR_CONTROL
    uint8_t register_address_control = 0xFA;
    // REG_BIT_CONTROL_FIFO_CLR_MSK
    uint8_t bit_control_fifo_clear = 0x02;
    // REG_ENABLE_BIT_SP_EN
    uint8_t enable_bit_spectral = 0x02;
    // REG_ENABLE_BIT_FDEN
    uint8_t enable_bit_flicker = 0x40;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_start as7341_start
*
* Test cases for as7341_start.
*
*
*/

/*!
 * \ingroup tc_start
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_START_0001}
 * 
 */
TEST_F(Start, TEST_START_0001__DeviceIdIsInvalid) {

    EXPECT_EQ(ERR_ARGUMENT, as7341_start(invalid_osal_id, MEAS_TYPE_SPECTRAL));
}

/*!
 * \ingroup tc_start
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'spectral'
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit in element register_enable of device configuration is set
 * }
 *
 * \TestID{TEST_START_0003}
 * 
 */
TEST_F(Start, TEST_START_0003__WriteRegisterEnableFailedForSpectral) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_start(valid_osal_id, MEAS_TYPE_SPECTRAL));

    // The enable_bit_spectral is set regardless off write register failed or succeeded!
    uint8_t value = g_device_config[valid_device_id].register_enable | enable_bit_spectral;
    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);
}

/*!
 * \ingroup tc_start
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'spectral'
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that enable bit in element register_enable of device configuration is set
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_START_0004}
 * 
 */
TEST_F(Start, TEST_START_0004__WriteRegisterEnableSucceededForSpectral) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0;

    // value to set
    uint8_t value = g_device_config[valid_device_id].register_enable | enable_bit_spectral;
    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_enable, value};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_start(valid_osal_id, MEAS_TYPE_SPECTRAL));

    EXPECT_EQ(g_device_config[valid_device_id].register_enable, value);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_start
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to write registers succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data for register 'control' returns ERR_SUCCESS
 *   - mock function for osal_transfer_data for register 'enable' returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'fifo'
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that enable bit in element register_enable of device configuration is set
 *   - check the expected send buffer for write register 'control' and 'enable'
 * }
 *
 * \TestID{TEST_START_0005}
 * 
 */
TEST_F(Start, TEST_START_0005__WriteRegistersSucceededForFlicker) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0;

    // expected register_enable
    uint8_t register_enable = g_device_config[valid_device_id].register_enable | enable_bit_flicker;

    // expected send buffer transfer to mock
    // (1) register control
    uint8_t expected_send_buf1[] = {register_address_control, bit_control_fifo_clear};
    // (2) register enable
    uint8_t expected_send_buf2[] = {register_address_enable, register_enable};

    expectWriteRegister_with_check(expected_send_buf1, ERR_SUCCESS);
    expectWriteRegister_with_check(expected_send_buf2, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_start(valid_osal_id, MEAS_TYPE_FIFO));

    EXPECT_EQ(g_device_config[valid_device_id].register_enable, register_enable);
}

/*!
 * \ingroup tc_start
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to write register 'control' failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data for register 'control' returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and meas type 'fifo'
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that enable bit in element register_enable of device configuration is set
 * }
 *
 * \TestID{TEST_START_0006}
 * 
 */
TEST_F(Start, TEST_START_0006__WriteRegisterControlFailedForFlicker) {

    // prepare device config
    g_device_config[valid_device_id].register_enable = 0;

    // expected register_enable
    uint8_t register_enable = g_device_config[valid_device_id].register_enable | enable_bit_flicker;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_control, bit_control_fifo_clear};

    expectWriteRegister_with_check(expected_send_buf, special_error_code);

    EXPECT_EQ(special_error_code, as7341_start(valid_osal_id, MEAS_TYPE_FIFO));

    EXPECT_EQ(g_device_config[valid_device_id].register_enable, register_enable);
}

}