/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetPower : public TestFixtureInterface {

protected:
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;
    // power on bit (REG_ENABLE_BIT_PON)
    uint8_t power_on_bit = 1;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_power set_power
*
* Test cases for set_power.
*
*
*/

/*!
 * \ingroup tc_set_power
 * \brief Check set power ON
 * 
 * \Description{
 *   - check set power on
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that register_enable in device configuration is equal 1
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_SET_POWER_0001}
 * 
 */
TEST_F(SetPower, TEST_SET_POWER_0001__SetPowerON) {

    // init register enable in device configuration to see change to 1
    g_device_config[valid_device_id].register_enable = 0;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_enable, power_on_bit};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, set_power_on(valid_osal_id));

    EXPECT_EQ(power_on_bit, g_device_config[valid_device_id].register_enable);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_set_power
 * \brief Check set power OFF
 * 
 * \Description{
 *   - check set power off
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that register_enable in device configuration is equal 0
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_SET_POWER_0002}
 * 
 */
TEST_F(SetPower, TEST_SET_POWER_0002__SetPowerOFF) {

    // init register enable in device configuration to see change to 0
    g_device_config[valid_device_id].register_enable = power_on_bit;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_enable, 0};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, set_power_off(valid_osal_id));

    EXPECT_EQ(0, g_device_config[valid_device_id].register_enable);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

}