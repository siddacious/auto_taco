/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::Return;
using ::testing::DoAll;
using ::testing::ElementsAreArray;
using ::testing::Pointee;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetChannelData : public TestFixtureInterface {

protected:
    // NUM_OF_ADC_CHANNELS
    const uint8_t adc_channel_number = 6;
    // register address to read channel data from: AS7341_REGADDR_CH0_DATA
    uint8_t register_address_ch0_data = 0x95;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_channel_data as7341_get_channel_data
*
* Test cases for as7341_get_channel_data.
*
*
*/

/*!
 * \ingroup tc_get_channel_data
 * \brief Check get channel data
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_CHANNEL_DATA_0001}
 * 
 */
TEST_F(GetChannelData, TEST_GET_CHANNEL_DATA_0001__InvalidDeviceId) {

    // dummies
    uint16_t channel_data[] = {0, 0, 0, 0, 0, 0};
    uint8_t size = adc_channel_number * sizeof(uint16_t);
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_get_channel_data(invalid_osal_id, channel_data, size));
}

/*!
 * \ingroup tc_get_channel_data
 * \brief Check get channel data
 * 
 * \Description{
 *   - check response to null pointer for channel_data
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for channel_data
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_CHANNEL_DATA_0002}
 * 
 */
TEST_F(GetChannelData, TEST_GET_CHANNEL_DATA_0002__NullPointer) {

    // dummy
    uint8_t size = adc_channel_number * sizeof(uint16_t);

    EXPECT_EQ(ERR_POINTER, as7341_get_channel_data(valid_osal_id, NULL, size));
}

/*!
 * \ingroup tc_get_channel_data
 * \brief Check get channel data
 * 
 * \Description{
 *   - check response to invalid size
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id, a valid pointer to channel_data and an invalid size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SIZE
 *
 * \TestID{TEST_GET_CHANNEL_DATA_0003}
 * 
 */
TEST_F(GetChannelData, TEST_GET_CHANNEL_DATA_0003__InvalidSize) {

    // invalid size: not adc_channel_number * 2
    uint8_t size = 10;

    // dummy
    uint16_t channel_data[] = {0, 0, 0, 0, 0, 0};

    EXPECT_EQ(ERR_SIZE, as7341_get_channel_data(valid_osal_id, channel_data, size));
}

/*!
 * \ingroup tc_get_channel_data
 * \brief Check set channel data
 * 
 * \Description{
 *   - check get channel data
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id, a valid pointer to channel_data and a valid size
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *
 * \TestID{TEST_GET_CHANNEL_DATA_0004}
 * 
 */
TEST_F(GetChannelData, TEST_GET_CHANNEL_DATA_0004__ReadDataFailed) {

    uint8_t size = adc_channel_number * sizeof(uint16_t);

    uint16_t channel_data[] = {0, 0, 0, 0, 0, 0};

    uint16_t receive_channel_data[] = {0x1020, 0x1121, 0x1222, 0x1323, 0x1424, 0x1525};

    expectReadData(register_address_ch0_data, receive_channel_data, adc_channel_number, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_channel_data(valid_osal_id, channel_data, size));

    EXPECT_THAT(channel_data, ElementsAreArray(receive_channel_data, adc_channel_number));
}

/*!
 * \ingroup tc_get_channel_data
 * \brief Check set channel data
 * 
 * \Description{
 *   - check set channel data
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id, a valid pointer to channel_data and a valid size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that get channel_data is equal receive_channel_data from mock
 *
 * \TestID{TEST_GET_CHANNEL_DATA_0005}
 * 
 */
TEST_F(GetChannelData, TEST_GET_CHANNEL_DATA_0005__Succeeded) {

    uint8_t size = adc_channel_number * sizeof(uint16_t);

    uint16_t channel_data[] = {0, 0, 0, 0, 0, 0};

    uint16_t receive_channel_data[] = {0x1020, 0x1121, 0x1222, 0x1323, 0x1424, 0x1525};

    // prepare mock
    expectReadData(register_address_ch0_data, receive_channel_data, adc_channel_number, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_channel_data(valid_osal_id, channel_data, size));

    EXPECT_THAT(channel_data, ElementsAreArray(receive_channel_data, adc_channel_number));
}

}