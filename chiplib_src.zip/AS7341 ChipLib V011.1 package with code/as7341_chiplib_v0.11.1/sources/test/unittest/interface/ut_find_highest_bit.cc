/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class FindHighestBit : public TestFixtureInterface {

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_find_highest_bit as7341_get_highest_value
*
* Test cases for find highest bit.
*
*
*/

/*!
 * \ingroup tc_find_highest_bit
 * \brief Check find highest bit
 *
 * \Description{
 *   - check find highest bit
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid value
 * }
 *
 * \Expectations{
 *   - check that returned highest bit and expected highest bit are equal
 *
 * \TestID{TEST_FIND_HIGHEST_BIT_0001}
 *
 */
TEST_F(FindHighestBit, TEST_FIND_HIGHEST_BIT_0001__CheckHighestBit) {

    // init some test data
    uint8_t expected_highest_bit[5] = { 31, 27, 14, 0, 5 };

    for (int i = 0; i < 5; i++)
    {
        EXPECT_EQ(expected_highest_bit[i], find_highest_bit(uint32_t(1 << expected_highest_bit[i])));
    }
}

}