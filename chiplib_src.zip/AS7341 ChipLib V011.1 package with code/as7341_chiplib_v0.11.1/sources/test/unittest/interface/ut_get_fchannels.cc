/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetFchannels : public ::TestFixtureInterface {

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_fchannels as7341_get_fchannels
*
* Test cases for as7341_get_fchannels.
*
*
*/

/*!
 * \ingroup tc_get_fchannels
 * \brief Check get channels for flicker detection
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FCHANNELS_0001}
 * 
 */
TEST_F(GetFchannels, TEST_GET_FCHANNELS_0001__DeviceIdIsInvalid) {

    // dummy
    uint32_t fchannels = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_fchannels(invalid_osal_id, &fchannels));
}

/*!
 * \ingroup tc_get_fchannels
 * \brief Check get integration time for fifo
 * 
 * \Description{
 *   - check response to null pointer for fchannels
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for fchannels
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FCHANNELS_0002}
 * 
 */
TEST_F(GetFchannels, TEST_GET_FCHANNELS_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_fchannels(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_fchannels
 * \brief Check get channels for flicker detection
 * 
 * \Description{
 *   - check response to get channels for flicker detection succeeded
 * }
 * 
 * \Preconditions{
 *   - set element fchannels in device configuration
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid pointer for fchannels
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check output fchannels
 * }
 *
 * \TestID{TEST_GET_FCHANNELS_0003}
 * 
 */
TEST_F(GetFchannels, TEST_GET_FCHANNELS_0003__Success) {

    uint32_t fchannels = 0;
    
    // prepare device configuration
    g_device_config[valid_device_id].fchannels = 1;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_fchannels(valid_osal_id, &fchannels));

    EXPECT_EQ(g_device_config[valid_device_id].fchannels, fchannels);
}

}