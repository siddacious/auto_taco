/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class Shorty : public TestFixtureInterface {

protected:
    // register address for interrupt enable: AS7341_REGADDR_INTENAB
    uint8_t register_address_interrupt_enable = 0xF9;
    // register address for status: AS7341_REGADDR_STATUS
    uint8_t register_address_status = 0x93;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_shorty as7341_x
*
* Test cases for simple as7341_x.
*
*
*/

/*!
 * \ingroup tc_shorty
 * \brief Check activate interrupt
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_ACTIVATE_INTERRUPT_0001}
 * 
 */
TEST_F(Shorty, TEST_ACTIVATE_INTERRUPT_0001__InvalidDeviceId) {

    // dummy
    uint8_t interrupt = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_activate_interrupt(invalid_osal_id, interrupt));
}

/*!
 * \ingroup tc_shorty
 * \brief Check activate interrupt
 * 
 * \Description{
 *   - check activate interrupt
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check the send buffer to set register interrupt_enable
 *
 * \TestID{TEST_ACTIVATE_INTERRUPT_0002}
 * 
 */
TEST_F(Shorty, TEST_ACTIVATE_INTERRUPT_0002__Succeeded) {

    uint8_t interrupt = 0xA5;

     // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_interrupt_enable, interrupt};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // prepare the mock
    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, as7341_activate_interrupt(valid_osal_id, interrupt));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_shorty
 * \brief Check reset interrupt
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_RESET_INTERRUPT_0001}
 * 
 */
TEST_F(Shorty, TEST_RESET_INTERRUPT_0001__InvalidDeviceId) {

    // dummy
    uint8_t interrupt = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_reset_interrupt(invalid_osal_id, interrupt));
}

/*!
 * \ingroup tc_shorty
 * \brief Check reset interrupt
 * 
 * \Description{
 *   - check reset interrupt
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check the send buffer to set register status
 *
 * \TestID{TEST_RESET_INTERRUPT_0002}
 * 
 */
TEST_F(Shorty, TEST_RESET_INTERRUPT_0002__Succeeded) {

    uint8_t interrupt = 0xA5;

     // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_status, interrupt};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    // prepare the mock
    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, as7341_reset_interrupt(valid_osal_id, interrupt));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/*!
 * \ingroup tc_shorty
 * \brief Check is_second_smux_conf_available
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_IS_SECOND_SMUX_AVAILABLE_0001}
 * 
 */
TEST_F(Shorty, TEST_IS_SECOND_SMUX_AVAILABLE_0001__InvalidDeviceId) {

    // dummy
    uint8_t state = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_is_second_smux_conf_available(invalid_osal_id, &state));
}

/*!
 * \ingroup tc_shorty
 * \brief Check is_second_smux_conf_available
 * 
 * \Description{
 *   - check response to null pointer for state
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for state
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_IS_SECOND_SMUX_AVAILABLE_0002}
 * 
 */
TEST_F(Shorty, TEST_IS_SECOND_SMUX_AVAILABLE_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_is_second_smux_conf_available(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_shorty
 * \brief Check is_second_smux_conf_available
 * 
 * \Description{
 *   - check is_second_smux_conf_available
 * }
 * 
 * \Preconditions{
 *   - init element second_smux_config_available in device config
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that returned state and corresponding element in device config are equal
 *
 * \TestID{TEST_IS_SECOND_SMUX_AVAILABLE_0003}
 * 
 */
TEST_F(Shorty, TEST_IS_SECOND_SMUX_AVAILABLE_0003__Succeeded) {

    uint8_t state = 0;

    g_device_config[valid_device_id].second_smux_config_available = 0xA5;

    EXPECT_EQ(ERR_SUCCESS, as7341_is_second_smux_conf_available(valid_osal_id, &state));

    EXPECT_EQ(g_device_config[valid_device_id].second_smux_config_available, state);
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_internal_autozero
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_INTERNAL_AUTOZERO_0001}
 * 
 */
TEST_F(Shorty, TEST_GET_INTERNAL_AUTOZERO_0001__InvalidDeviceId) {

    // dummy
    uint8_t autozero = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_get_internal_autozero(invalid_osal_id, &autozero));
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_internal_autozero
 * 
 * \Description{
 *   - check response to null pointer for autozero
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for autozero
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_INTERNAL_AUTOZERO_0002}
 * 
 */
TEST_F(Shorty, TEST_GET_INTERNAL_AUTOZERO_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_internal_autozero(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_internal_autozero
 * 
 * \Description{
 *   - check get_internal_autozero
 * }
 * 
 * \Preconditions{
 *   - init element auto_zero in device config
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that returned autozero and corresponding element in device config are equal
 *
 * \TestID{TEST_GET_INTERNAL_AUTOZERO_0003}
 * 
 */
TEST_F(Shorty, TEST_GET_INTERNAL_AUTOZERO_0003__Succeeded) {

    uint8_t autozero = 0;

    g_device_config[valid_device_id].auto_zero = 0xA5;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_internal_autozero(valid_osal_id, &autozero));

    EXPECT_EQ(g_device_config[valid_device_id].auto_zero, autozero);
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_saved_gain
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_SAVED_GAIN_0001}
 * 
 */
TEST_F(Shorty, TEST_GET_SAVED_GAIN_0001__InvalidDeviceId) {

    // dummy
    uint8_t gain = 0;
   
    EXPECT_EQ(ERR_ARGUMENT, as7341_get_saved_gain(invalid_osal_id, &gain));
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_saved_gain
 * 
 * \Description{
 *   - check response to null pointer for gain
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for gain
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 *
 * \TestID{TEST_GET_SAVED_GAIN_0002}
 * 
 */
TEST_F(Shorty, TEST_GET_SAVED_GAIN_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_saved_gain(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_shorty
 * \brief Check get_saved_gain
 * 
 * \Description{
 *   - check get_saved_gain
 * }
 * 
 * \Preconditions{
 *   - init element again in device config
 * }
 * 
 * \Steps{
 *   - call test function with a valid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that returned gain and corresponding element in device config are equal
 *
 * \TestID{TEST_GET_SAVED_GAIN_0003}
 * 
 */
TEST_F(Shorty, TEST_GET_SAVED_GAIN_0003__Succeeded) {

    uint8_t gain = 0;

    g_device_config[valid_device_id].again = 0xA5;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_saved_gain(valid_osal_id, &gain));

    EXPECT_EQ(g_device_config[valid_device_id].again, gain);
}

}