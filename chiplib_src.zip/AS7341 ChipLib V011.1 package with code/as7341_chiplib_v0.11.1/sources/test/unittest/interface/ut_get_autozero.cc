/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetAutoZero : public ::TestFixtureInterface {

protected:
    // register address to read autozero from: AS7341_REGADDR_AZCONFIG
    uint8_t register_address_azconfig = 0xD6;

public:
    void SetUp() {
        // init auto zero in device configuration
        g_device_config[valid_device_id].auto_zero = 0;       
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_autozero as7341_get_autozero
*
* Test cases for as7341_get_autozero.
*
*
*/

/*!
 * \ingroup tc_get_autozero
 * \brief Check get autozero
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_AUTOZERO_0001}
 * 
 */
TEST_F(GetAutoZero, TEST_GET_AUTOZERO_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t autozero = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_autozero(invalid_osal_id, &autozero));
}

/*!
 * \ingroup tc_get_autozero
 * \brief Check get autozero
 * 
 * \Description{
 *   - check response to null pointer for autozero
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for autozero
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_AUTOZERO_0002}
 * 
 */
TEST_F(GetAutoZero, TEST_GET_AUTOZERO_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_autozero(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_autozero
 * \brief Check get autozero
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid autozero buffer
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that autozero returned from mock is not saved in device configuration
 * }
 *
 * \TestID{TEST_GET_AUTOZERO_0003}
 * 
 */
TEST_F(GetAutoZero, TEST_GET_AUTOZERO_0003__ReadRegisterFailed) {

    uint8_t autozero = 0;

    // register value returned by mock
    uint8_t register_value = 0x5C;

    // expected autozero
    uint8_t expected_autozero = register_value;

    expectReadRegister(register_address_azconfig, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_autozero(valid_osal_id, &autozero));

    // only for test: the value returned from mock is the expected value
    EXPECT_EQ(expected_autozero, autozero);

    EXPECT_EQ(g_device_config[valid_device_id].auto_zero, 0);
}

/*!
 * \ingroup tc_get_autozero
 * \brief Check get autozero
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid autozero buffer
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected autozero is equal received autozero
 *   - check that autozero is saved in device configuration
 * }
 *
 * \TestID{TEST_GET_AUTOZERO_0004}
 * 
 */
TEST_F(GetAutoZero, TEST_GET_AUTOZERO_0004__ReadRegisterSucceeded) {

    uint8_t autozero = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    // expected autozero
    uint8_t expected_autozero = register_value;

    expectReadRegister(register_address_azconfig, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_autozero(valid_osal_id, &autozero));

    EXPECT_EQ(expected_autozero, autozero);

    EXPECT_EQ(g_device_config[valid_device_id].auto_zero, autozero);
}

}