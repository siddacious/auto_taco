/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest
{

/**** test class ********************************************************/

class SetStep : public ::TestFixtureInterface
{

  protected:
    // register address to read astep from: AS7341_REGADDR_ASTEP
    uint8_t register_address_astep = 0xCA;

  public:
    void SetUp()
    {
        // init astep in device configuration
        g_device_config[valid_device_id].astep = 0;
    }
};

/**** test definitions ********************************************************/

/*!
 *
 * @defgroup tc_set_step as7341_set_astep
 *
 * Test cases for as7341_set_astep.
 *
 *
 */

/*!
 * \ingroup tc_set_step
 * \brief Check set astep
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_STEP_0001}
 *
 */
TEST_F(SetStep, TEST_SET_STEP_0001__DeviceIdIsInvalid)
{

    // dummy
    uint16_t astep = 10;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_astep(invalid_osal_id, astep));
}

/*!
 * \ingroup tc_set_step
 * \brief Check set astep
 *
 * \Description{
 *   - check response to invalid astep
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid astep
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_STEP_0002}
 *
 */
TEST_F(SetStep, TEST_SET_STEP_0002__AstepIsInvalid)
{

    // invalid astep values
    uint16_t astep[] = {0, 0xFFFF};

    for (unsigned int i = 0; i < sizeof(astep) / sizeof(uint16_t); i++) {
        EXPECT_EQ(ERR_ARGUMENT, as7341_set_astep(valid_osal_id, astep[i]));
    }
}

/*!
 * \ingroup tc_set_step
 * \brief Check set astep
 *
 * \Description{
 *   - check response to write register failed
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid astep value
 * }
 *
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that astep is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_STEP_0003}
 *
 */
TEST_F(SetStep, TEST_SET_STEP_0003__WriteRegisterFailed)
{

    // astep to set
    uint16_t astep = 0x1234;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_astep(valid_osal_id, astep));

    EXPECT_EQ(g_device_config[valid_device_id].astep, 0);
}

/*!
 * \ingroup tc_set_step
 * \brief Check set astep
 *
 * \Description{
 *   - check response to write register succeeded
 * }
 *
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid astep
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that astep is saved in device configuration
 *   - check that the actual and expected send buffer for write register are equal
 * }
 *
 * \TestID{TEST_SET_STEP_0004}
 *
 */
TEST_F(SetStep, TEST_SET_STEP_0004__WriteRegisterSucceeded)
{

    // astep to set
    uint16_t astep = 0x1234;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_astep, (uint8_t)(astep & 0xFF), (uint8_t)(astep >> 8)};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_astep(valid_osal_id, astep));

    EXPECT_EQ(g_device_config[valid_device_id].astep, astep);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

} // namespace ChipLibUnittest