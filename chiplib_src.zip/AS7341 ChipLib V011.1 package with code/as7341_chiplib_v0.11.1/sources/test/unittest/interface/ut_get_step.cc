/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetStep : public ::TestFixtureInterface {

protected:
    // register address to read astep from: AS7341_REGADDR_ASTEP
    uint8_t register_address_astep = 0xCA;

public:
    void SetUp() {
        // init astep in device configuration
        g_device_config[valid_device_id].astep = 0;       
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_step as7341_get_astep
*
* Test cases for as7341_get_astep.
*
*
*/

/*!
 * \ingroup tc_get_step
 * \brief Check get astep
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_STEP_0001}
 * 
 */
TEST_F(GetStep, TEST_GET_STEP_0001__DeviceIdIsInvalid) {

    // dummy
    uint16_t astep = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_astep(invalid_osal_id, &astep));
}

/*!
 * \ingroup tc_get_step
 * \brief Check get astep
 * 
 * \Description{
 *   - check response to null pointer for astep
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for astep
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_STEP_0002}
 * 
 */
TEST_F(GetStep, TEST_GET_STEP_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_astep(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_step
 * \brief Check get astep
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid astep
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that astep returned from mock is not saved in device configuration
 * }
 *
 * \TestID{TEST_GET_STEP_0003}
 * 
 */
TEST_F(GetStep, TEST_GET_STEP_0003__ReadRegisterFailed) {

    uint16_t astep = 0;
    
    // register value returned by mock
    uint16_t register_value = 0x1234;

    // expected astep
    uint16_t expected_step = register_value;

    expectReadBytes(register_address_astep, (uint8_t *)&register_value, sizeof(register_value), special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_astep(valid_osal_id, &astep));

    // only for test: the value returned from mock is the expected value
    EXPECT_EQ(expected_step, astep);

    EXPECT_EQ(g_device_config[valid_device_id].astep, 0);
}

/*!
 * \ingroup tc_get_step
 * \brief Check get astep
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid astep
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected astep is equal received astep
 *   - check that astep is saved in device configuration
 * }
 *
 * \TestID{TEST_GET_STEP_0004}
 * 
 */
TEST_F(GetStep, TEST_GET_STEP_0004__ReadRegisterSucceeded) {

    uint16_t astep = 0;
    
    // register value returned by mock
    uint16_t register_value = 0x1234;

    // expected astep
    uint16_t expected_step = register_value;

    expectReadBytes(register_address_astep, (uint8_t *)&register_value, sizeof(register_value), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_astep(valid_osal_id, &astep));

    EXPECT_EQ(expected_step, astep);

    EXPECT_EQ(g_device_config[valid_device_id].astep, astep);
}

}