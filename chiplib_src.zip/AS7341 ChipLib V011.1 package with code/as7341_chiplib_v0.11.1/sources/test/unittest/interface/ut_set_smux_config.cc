/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetSmuxConfig : public TestFixtureInterface {

protected:
    // register address to switch memory bank to: AS7341_REGADDR_CFG0
    uint8_t register_address_cfg0 = 0xA9;
    // register address to write to smux chain to: AS7341_REGADDR_CFG6
    uint8_t register_address_cfg6 = 0xAF;
    // register address to write register enable: AS7341_REGADDR_ENABLE
    uint8_t register_address_enable = 0x80;

public:
    // valid size for smux config is SIZE_OF_SMUX_BUFFER
    static const uint8_t smux_buffer_size = 21;
    // smux config data
    uint8_t smux_config_data[smux_buffer_size];

    void SetUp() {
        // init long time in device configuration
        g_device_config[valid_device_id].long_wait_time = 0;
        // init register enable in device configuration
        g_device_config[valid_device_id].register_enable = 0;

        // // Init with a value which does not match the other register addresses!
        memset(smux_config_data, 0x99, smux_buffer_size);
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_smux_config set_smux_config
*
* Test cases for set_smux_config.
*
*
*/

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response to invalid size of smux config
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and an invalid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SIZE
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0001}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0001__InvalidSizeOfSmuxConfig) {

    // size is not SIZE_OF_SMUX_BUFFER
    uint8_t invalid_size = 20;
   
    EXPECT_EQ(ERR_SIZE, set_smux_config(valid_osal_id, NULL, invalid_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if switch memory bank failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0002}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0002__SwitchToMemoryBankFailed) {

    expectWriteRegister(register_address_cfg0, special_error_code);
   
    EXPECT_EQ(special_error_code, set_smux_config(valid_osal_id, NULL, smux_buffer_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if write to smux chain failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock for write to smux chain
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0003}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0003__WriteToSmuxChainFailed) {

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);
   
    expectWriteRegister(register_address_cfg6, special_error_code);

    EXPECT_EQ(special_error_code, set_smux_config(valid_osal_id, NULL, smux_buffer_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if write to ram failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock for write to ram
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0004}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0004__WriteToRamFailed) {

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);
   
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(smux_config_data[0], smux_buffer_size, special_error_code);

    EXPECT_EQ(special_error_code, set_smux_config(valid_osal_id, smux_config_data, smux_buffer_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if write register <enable> failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock for write register <enable>
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0005}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0005__WriteRegisterEnableFailed) {

    expectWriteRegister(register_address_cfg0, ERR_SUCCESS);
   
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(smux_config_data[0], smux_buffer_size, ERR_SUCCESS);
   
    expectWriteRegister(register_address_enable, special_error_code);

    EXPECT_EQ(special_error_code, set_smux_config(valid_osal_id, smux_config_data, smux_buffer_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if all write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0005}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0005__Success) {

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 0
    uint8_t my_array1[] = {register_address_cfg0, 0x00};
    expectWriteRegister_with_check(my_array1, ERR_SUCCESS);
  
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(smux_config_data[0], smux_buffer_size, ERR_SUCCESS);
   
    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 1
    uint8_t my_array2[] = {register_address_cfg0, 0x10};
    expectWriteRegister_with_check(my_array2, ERR_SUCCESS);
  
    EXPECT_EQ(ERR_SUCCESS, set_smux_config(valid_osal_id, smux_config_data, smux_buffer_size));
}

/*!
 * \ingroup tc_set_smux_config
 * \brief Check set smux config
 * 
 * \Description{
 *   - check response if write register <enable> failed
 * }
 * 
 * \Preconditions{
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to smux chain --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write to ram --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <enable> --> osal_transfer_data returns ERR_SUCCESS
 *   - mock function for write register <switch memory bank> --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and the valid size of smux config
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock for the second write register <switch memory bank>
 * }
 *
 * \TestID{TEST_SET_SMUX_CONFIG_0006}
 * 
 */
TEST_F(SetSmuxConfig, TEST_SET_SMUX_CONFIG_0006__SecondSwitchToMemoryBankFailed) {

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 0
    uint8_t my_array1[2] = {register_address_cfg0, 0x00};
    expectWriteRegister_with_check(my_array1, ERR_SUCCESS);
  
    expectWriteRegister(register_address_cfg6, ERR_SUCCESS);

    expectWriteBytes(smux_config_data[0], smux_buffer_size, ERR_SUCCESS);
   
    expectWriteRegister(register_address_enable, ERR_SUCCESS);

    // bit 4 (REG_BIT_CFG0_REG_BANK_OFFSET) in AS7341_REGADDR_CFG0 should be 1
    uint8_t my_array2[2] = {register_address_cfg0, 0x10};
    expectWriteRegister_with_check(my_array2, special_error_code);
  
    EXPECT_EQ(special_error_code, set_smux_config(valid_osal_id, smux_config_data, smux_buffer_size));
}

}