/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetGain : public ::TestFixtureInterface {

protected:
    // register address to read gain from: AS7341_REGADDR_CFG1
    uint8_t register_address_cfg1 = 0xAA;
    // REG_BIT_CFG1_AGAIN_MSK
    uint8_t again_mask = 0x1F;

public:
    void SetUp() {
        // init gain in device configuration
        g_device_config[valid_device_id].again = 0;       
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_gain as7341_set_gain
*
* Test cases for as7341_set_gain.
*
*
*/

/*!
 * \ingroup tc_set_gain
 * \brief Check set gain
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_GAIN_0001}
 * 
 */
TEST_F(SetGain, TEST_SET_GAIN_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t gain = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_gain(invalid_osal_id, gain));
}

/*!
 * \ingroup tc_set_gain
 * \brief Check set gain
 * 
 * \Description{
 *   - check response if gain is too big
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and a too big gain value
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_GAIN_0002}
 * 
 */
TEST_F(SetGain, TEST_SET_GAIN_0002__GainIsTooBig) {

    uint8_t gain = 11;  // > 10 (MAX_GAIN_INDEX)

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_gain(valid_osal_id, gain));
}

/*!
 * \ingroup tc_set_gain
 * \brief Check set gain
 * 
 * \Description{
 *   - check response to write register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid gain value
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that gain is not saved in device configuration
 * }
 *
 * \TestID{TEST_SET_GAIN_0003}
 * 
 */
TEST_F(SetGain, TEST_SET_GAIN_0003__WriteRegisterFailed) {

    // gain to set
    uint8_t gain = 5;

    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), special_error_code);

    EXPECT_EQ(special_error_code, as7341_set_gain(valid_osal_id, gain));

    EXPECT_EQ(g_device_config[valid_device_id].again, 0);
}

/*!
 * \ingroup tc_set_gain
 * \brief Check set gain
 * 
 * \Description{
 *   - check response to write register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid gain 
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that gain is saved in device configuration
 *   - check that the actual and expected send buffer for write register are equal 
 * }
 *
 * \TestID{TEST_SET_GAIN_0004}
 * 
 */
TEST_F(SetGain, TEST_SET_GAIN_0004__WriteRegisterSucceeded) {

    // gain to set
    uint8_t gain = 5;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_cfg1, gain};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_set_gain(valid_osal_id, gain));

    EXPECT_EQ(g_device_config[valid_device_id].again, gain);

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

}