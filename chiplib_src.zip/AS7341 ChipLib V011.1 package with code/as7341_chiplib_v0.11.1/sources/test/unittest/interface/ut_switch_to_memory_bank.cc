/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::ElementsAreArray;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _param {
    uint8_t is_mem_bank;
    uint8_t long_wait_time;
    uint8_t expected_register_value;
};

/**** test class ********************************************************/

class SwitchToMemoryBank : public TestFixtureInterface,
                           public WithParamInterface<_param> {

protected:
    // register address to switch memory bank to: AS7341_REGADDR_CFG0
    uint8_t register_address_cfg0 = 0xA9;
    // long wait time bit (REG_BIT_CFG0_WLONG_MSK)
    uint8_t long_wait_time_bit = 0x04;
    // shift (REG_BIT_CFG0_REG_BANK_OFFSET)
    uint8_t shift = 4;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_switch_to_memory_bank switch_to_memory_bank
*
* Test cases for switch_to_memory_bank.
*
*
*/

/*!
 * \ingroup tc_switch_to_memory_bank
 * \brief Check switch to memory bank
 *
 * \Description{
 *   - check switch to memory bank using parameterized test
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check value for register cfg0
 * }
 *
 * \TestID{TEST_SWITCH_TO_MEMORY_BANK_0001}
 *
 */
TEST_P(SwitchToMemoryBank, TEST_SWITCH_TO_MEMORY_BANK_0001__SwitchTo0) {

    // get the next test parameter structure
    _param my_param = GetParam();

    uint8_t is_mem_bank = my_param.is_mem_bank;

    // init long time in device configuration
    g_device_config[valid_device_id].long_wait_time = my_param.long_wait_time;

    // expected send buffer transfer to mock
    uint8_t expected_send_buf[] = {register_address_cfg0, my_param.expected_register_value};
    // actual send buffer
    uint8_t actual_send_buf[] = {0, 0};

    expectWriteRegister_without_check(actual_send_buf, sizeof(actual_send_buf), ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, switch_to_memory_bank(valid_osal_id, is_mem_bank));

    EXPECT_THAT(expected_send_buf, ElementsAreArray(actual_send_buf, sizeof(actual_send_buf)));
}

/**** parameterized test cases ********************************************************/
_param my_array[] = { {0, 0, 0x10}, {0, 1, 0x14}, {1, 0, 0}, {1, 1, 0x04} };

INSTANTIATE_TEST_SUITE_P(MemoryBank, SwitchToMemoryBank, ValuesIn(my_array));

}