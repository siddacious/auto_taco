/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetFlickerData : public ::TestFixtureInterface {

protected:
    // register address to read fifo status from: AS7341_REGADDR_STATUS6
    uint8_t register_address_status6 = 0xA7;
    // register address to read fifo data from: AS7341_REGADDR_FIFO_LVL
    uint8_t register_address_fifo_lvl = 0xFD;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_flicker_data as7341_get_flicker_data
*
* Test cases for as7341_get_flicker_data.
*
*
*/

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0001}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0001__DeviceIdIsInvalid) {

    // dummies
    uint8_t flicker_data[] = {0};
    uint8_t flicker_data_size = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_flicker_data(invalid_osal_id, flicker_data, &flicker_data_size));
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to null pointer for flicker data
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for flicker data
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0002}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0002__NullPointerFlickerData) {

    // dummy
    uint8_t flicker_data_size = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_flicker_data(valid_osal_id, NULL, &flicker_data_size));
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to null pointer for flicker data size
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0003}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0003__NullPointerFlickerDataSize) {

    // dummy
    uint8_t flicker_data[] = {0};

    EXPECT_EQ(ERR_POINTER, as7341_get_flicker_data(valid_osal_id, flicker_data, NULL));
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response if flicker data size is too small
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size is too small
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0004}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0004__FlickerDataSizeIsTooSmall) {

    uint8_t flicker_data[] = {0};
    uint8_t flicker_data_size = 31;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to read fifo status failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to read register status returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that flicker data size is null
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0005}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0005__ReadFifoStatusFailed) {

    uint8_t flicker_data[] = {0};
    uint8_t flicker_data_size = 32;

    // prepare mock for read register status6
    expectReadRegister(register_address_status6, 0, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));

    EXPECT_EQ(0, flicker_data_size);
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to read fifo level failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to read register status returns ERR_SUCCESS
 *   - mock function for osal_transfer_data to read register fifo level returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that flicker data size is null
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0006}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0006__ReadFifoLevelFailed) {

    uint8_t flicker_data[] = {0};
    uint8_t flicker_data_size = 32;

    // prepare mock for read register status6
    expectReadRegister(register_address_status6, 0, ERR_SUCCESS);
    // prepare mock for read register fifo level
    expectReadRegister(register_address_fifo_lvl, 0, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));

    EXPECT_EQ(0, flicker_data_size);
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to too less fifo data
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to read register status returns ERR_SUCCESS
 *   - read status is null
 *   - mock function for osal_transfer_data to read register fifo level returns ERR_SUCCESS
 *   - read fifo level is less than 16 (FIFO_THRESHOLD)
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that flicker data size is null
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0007}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0007__TooLessFifoData) {

    uint8_t flicker_data[] = {0};
    uint8_t flicker_data_size = 32;

    // prepare mock for read register status6
    expectReadRegister(register_address_status6, 0, ERR_SUCCESS);
    // prepare mock for read register fifo level
    expectReadRegister(register_address_fifo_lvl, 15, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));

    EXPECT_EQ(0, flicker_data_size);
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to read fifo data failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to read register status returns ERR_SUCCESS
 *   - read status is null
 *   - mock function for osal_transfer_data to read register fifo level returns ERR_SUCCESS
 *   - read fifo level is 16 (FIFO_THRESHOLD)
 *   - mock function for osal_transfer_data to read register fifo data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 *   - check that flicker data size is 32
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0008}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0008__ReadFifoDataFailed) {

    uint8_t flicker_data_size = 32;
    uint8_t flicker_data[32] = {0};

    // prepare mock for read register status6
    expectReadRegister(register_address_status6, 0, ERR_SUCCESS);
    // prepare mock for read register fifo level
    expectReadRegister(register_address_fifo_lvl, 16, ERR_SUCCESS);

    // prepare mock for read flicker data
    uint8_t number_of_bytes = 32;
    uint8_t bytes[32];
    for (int i = 0; i < number_of_bytes; i++)
    {
        bytes[i] = i + 1;
    }
    expectReadBytes_without_send(bytes, number_of_bytes, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));

    EXPECT_EQ(number_of_bytes, flicker_data_size);
    EXPECT_THAT(bytes, ElementsAreArray(flicker_data, 32));
}

/*!
 * \ingroup tc_get_flicker_data
 * \brief Check get flicker data
 * 
 * \Description{
 *   - check response to read fifo data succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data to read register status returns ERR_SUCCESS
 *   - read status is null
 *   - mock function for osal_transfer_data to read register fifo level returns ERR_SUCCESS
 *   - read fifo level is 16 (FIFO_THRESHOLD)
 *   - mock function for osal_transfer_data to read register fifo data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and flicker data size
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that flicker data size is 32
 * }
 *
 * \TestID{TEST_GET_FLICKER_DATA_0009}
 * 
 */
TEST_F(GetFlickerData, TEST_GET_FLICKER_DATA_0009__Success) {

    uint8_t flicker_data_size = 32;
    uint8_t flicker_data[32] = {0};

    // prepare mock for read register status6
    expectReadRegister(register_address_status6, 0, ERR_SUCCESS);
    // prepare mock for read register fifo level
    expectReadRegister(register_address_fifo_lvl, 17, ERR_SUCCESS);

    // prepare mock for read flicker data
    uint8_t number_of_bytes = 32;
    uint8_t bytes[32];
    for (int i = 0; i < number_of_bytes; i++)
    {
        bytes[i] = i + 1;
    }
    expectReadBytes_without_send(bytes, number_of_bytes, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_flicker_data(valid_osal_id, flicker_data, &flicker_data_size));

    EXPECT_EQ(number_of_bytes, flicker_data_size);
    EXPECT_THAT(bytes, ElementsAreArray(flicker_data, 32));
}

}