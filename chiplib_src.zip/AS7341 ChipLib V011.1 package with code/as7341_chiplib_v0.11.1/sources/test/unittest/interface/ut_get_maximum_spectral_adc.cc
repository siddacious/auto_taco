/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;
using ::testing::WithParamInterface;
using ::testing::ValuesIn;

namespace ChipLibUnittest {

/**** structure for parameterized test *********************************/

struct _param {
    uint16_t astep;
    uint8_t atime;
    uint16_t expected_adc_max;
};

/**** test class ********************************************************/

class GetMaximumSpectralAdc : public ::TestFixtureInterface,
                              public WithParamInterface<_param> {

public:
    void SetUp() {
        // init astep, atime in device configuration
        g_device_config[valid_device_id].astep = 0;
        g_device_config[valid_device_id].atime = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_maximum_spectral_adc as7341_get_maximum_spectral_adc
*
* Test cases for as7341_get_maximum_spectral_adc.
*
*
*/

/*!
 * \ingroup tc_get_maximum_spectral_adc
 * \brief Check get maximum spectral adc
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_MAXIMUM_SPECTRAL_ADC_0001}
 *
 */
TEST_F(GetMaximumSpectralAdc, TEST_GET_MAXIMUM_SPECTRAL_ADC_0001__DeviceIdIsInvalid) {

    // dummy
    uint16_t adc_max = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_maximum_spectral_adc(invalid_osal_id, &adc_max));
}

/*!
 * \ingroup tc_get_maximum_spectral_adc
 * \brief Check get maximum spectral adc
 *
 * \Description{
 *   - check response to null pointer for adc_max
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and null pointer for adc_max
 *
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_MAXIMUM_SPECTRAL_ADC_0002}
 *
 */
TEST_F(GetMaximumSpectralAdc, TEST_GET_MAXIMUM_SPECTRAL_ADC_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_maximum_spectral_adc(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_maximum_spectral_adc
 * \brief Check get maximum spectral adc
 *
 * \Description{
 *   - check calculating maximum spectral adc using parameterized test
 * }
 *
 * \Preconditions{
 *   - set atime, astep in device configuration
 * }
 *
 * \Steps{
 *   - call test function with a valid osal id and valid adc_max buffer
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that the actual and expected adc_max are equal
 * }
 *
 * \TestID{TEST_GET_MAXIMUM_SPECTRAL_ADC_0003}
 *
 */
TEST_P(GetMaximumSpectralAdc, TEST_GET_MAXIMUM_SPECTRAL_ADC_0003__CheckMaximumAdc) {

    // get the next test parameter structure
    _param my_param = GetParam();

    // set device configuration
    g_device_config[valid_device_id].astep = my_param.astep;
    g_device_config[valid_device_id].atime = my_param.atime;

    // expected adc_max
    uint16_t expected_adc_max = my_param.expected_adc_max;

    uint16_t adc_max = 0;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_maximum_spectral_adc(valid_osal_id, &adc_max));

    EXPECT_EQ(expected_adc_max, adc_max);

    std::array<s_debug_output, 3> my_debug = {{
        {"astep", my_param.astep},
        {"atime", my_param.atime},
        {"adc_max", my_param.expected_adc_max}
    }};
    debug_output(my_debug);
}

/**** parameterized test cases ********************************************************/
_param my_array[] = { {0, 0, 1}, {0xFFFE, 0, 0xFFFF}, {0x8000, 1, 0xFFFF}, {0x7FFE, 1, 0xFFFE} };

INSTANTIATE_TEST_SUITE_P(MaximumAdc, GetMaximumSpectralAdc, ValuesIn(my_array));

}