/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetWaitTime : public TestFixtureInterface {

protected:
    // register address to read wtime from: AS7341_REGADDR_WTIME
    uint8_t register_address_wtime = 0x83;

public:
    void SetUp() {
        // init long wait time in device configuration
        g_device_config[valid_device_id].long_wait_time = 0;
        // init register enable in device configuration
        g_device_config[valid_device_id].register_enable = 0;
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_wait_time as7341_get_wait_time
*
* Test cases for as7341_get_wait_time.
*
*
*/

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0001}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0001__DeviceIdIsInvalid) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;
    uint8_t long_time = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_wait_time(invalid_osal_id, &wtime, &enable, &long_time));
}

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to null pointer for wait time
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for wait time
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0002}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0002__NullPointerWaitTime) {

    // dummies
    uint8_t enable = 0;
    uint8_t long_time = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_wait_time(valid_osal_id, NULL, &enable, &long_time));
}

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to null pointer for long time
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for long time
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0003}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0003__NullPointerLongTime) {

    // dummies
    uint8_t wtime = 0;
    uint8_t enable = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_wait_time(valid_osal_id, &wtime, &enable, NULL));
}

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to null pointer for enable
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for enable
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0004}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0004__NullPointerEnable) {

    // dummies
    uint8_t wtime = 0;
    uint8_t long_time = 0;

    EXPECT_EQ(ERR_POINTER, as7341_get_wait_time(valid_osal_id, &wtime, NULL, &long_time));
}

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to get wait time succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for read register <wait time> --> osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check output values wtime, enable, long_time
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0005}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0005__GetWaitTimeSucceeded) {

    // init output values
    uint8_t long_time = 0;
    uint8_t enable = 0;
    uint8_t wtime = 0;

    // register value returned by mock
    uint8_t register_value = 0x5C;

    // prepare device configuration to check output values
    g_device_config[valid_device_id].long_wait_time = 0x12;
    g_device_config[valid_device_id].register_enable = 0x34;

    expectReadRegister(register_address_wtime, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_wait_time(valid_osal_id, &wtime, &enable, &long_time));

    // check output values
    // (1) wtime: should be the register value returned from mock
    EXPECT_EQ(wtime, register_value);
    // (2) long_time: should be long_wait_time from device configuration
    EXPECT_EQ(long_time, g_device_config[valid_device_id].long_wait_time);
    // (3) enable, handle important bit 4 (REG_ENABLE_BIT_WEN)
    //    if bit 4 in g_device_config[valid_device_id].register_enable is set --> enable = 1
    //    if bit 4 in g_device_config[valid_device_id].register_enable is not set --> enable = 0
    uint8_t expected_enable = ((g_device_config[valid_device_id].register_enable & 0x08) == 0x08) ? 1 : 0;
    EXPECT_EQ(enable, expected_enable);
}

/*!
 * \ingroup tc_get_wait_time
 * \brief Check get wait time
 * 
 * \Description{
 *   - check response to get wait time succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for read register <wait time> --> osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id
 * }
 * 
 * \Expectations{
 *   - return code is the error code
 *   - wait time should not be changed
 * }
 *
 * \TestID{TEST_GET_WAIT_TIME_0006}
 * 
 */
TEST_F(GetWaitTime, TEST_GET_WAIT_TIME_0006__GetWaitTimeFailed) {

    // init output values
    uint8_t long_time = 0;
    uint8_t enable = 0;
    uint8_t wtime = 0;

    // register value returned by mock
    uint8_t register_value = 0x5C;

    // prepare device configuration to check output values
    g_device_config[valid_device_id].long_wait_time = 0x12;
    g_device_config[valid_device_id].register_enable = 0x34;

    expectReadRegister(register_address_wtime, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_wait_time(valid_osal_id, &wtime, &enable, &long_time));

    // check output values
    // (1) wtime: should not be the register value returned from mock, because read register failed.
    // Because the function returns an error this is not a requirement!
    // EXPECT_EQ(wtime, 0);
    // (2) long_time: should be long_wait_time from device configuration
    EXPECT_EQ(long_time, g_device_config[valid_device_id].long_wait_time);
    // (3) enable, handle important bit 4 (REG_ENABLE_BIT_WEN)
    //    if bit 4 in g_device_config[valid_device_id].register_enable is set --> enable = 1
    //    if bit 4 in g_device_config[valid_device_id].register_enable is not set --> enable = 0
    uint8_t expected_enable = ((g_device_config[valid_device_id].register_enable & 0x08) == 0x08) ? 1 : 0;
    EXPECT_EQ(enable, expected_enable);
}

}