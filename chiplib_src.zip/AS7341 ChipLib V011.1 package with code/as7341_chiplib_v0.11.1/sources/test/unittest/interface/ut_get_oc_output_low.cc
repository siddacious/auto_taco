/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_interface.c"

#include "test_fixture_interface.h"

using namespace ChipLibUnittest;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetOcOutputLow : public ::TestFixtureInterface {

protected:
    // register address to read oc_output_low from: AS7341_REGADDR_GPIO2
    uint8_t register_address_gpio2 = 0xBE;
    // register mask: REG_BIT_GPIO_2_GPIO_OUT_MSK
    uint8_t gpio_out_mask = 0x02;

public:
    void SetUp() {

    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_oc_output_low as7341_get_oc_output_low
*
* Test cases for as7341_get_oc_output_low.
*
*
*/

/*!
 * \ingroup tc_get_oc_output_low
 * \brief Check get oc output low
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_OC_OUTPUT_LOW_0001}
 * 
 */
TEST_F(GetOcOutputLow, TEST_GET_OC_OUTPUT_LOW_0001__DeviceIdIsInvalid) {

    // dummy
    uint8_t oc_output_low = 0;

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_oc_output_low(invalid_osal_id, &oc_output_low));
}

/*!
 * \ingroup tc_get_oc_output_low
 * \brief Check get oc output low
 * 
 * \Description{
 *   - check response to null pointer for oc_output_low
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and null pointer for oc_output_low
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_OC_OUTPUT_LOW_0002}
 * 
 */
TEST_F(GetOcOutputLow, TEST_GET_OC_OUTPUT_LOW_0002__NullPointer) {

    EXPECT_EQ(ERR_POINTER, as7341_get_oc_output_low(valid_osal_id, NULL));
}

/*!
 * \ingroup tc_get_oc_output_low
 * \brief Check get oc output low
 * 
 * \Description{
 *   - check response to read register failed
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns an error code
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid oc_output_low buffer
 * }
 * 
 * \Expectations{
 *   - return code is the error code of mock
 * }
 *
 * \TestID{TEST_GET_OC_OUTPUT_LOW_0003}
 * 
 */
TEST_F(GetOcOutputLow, TEST_GET_OC_OUTPUT_LOW_0003__ReadRegisterFailed) {

    uint8_t oc_output_low = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    expectReadRegister(register_address_gpio2, register_value, special_error_code);

    EXPECT_EQ(special_error_code, as7341_get_oc_output_low(valid_osal_id, &oc_output_low));
}

/*!
 * \ingroup tc_get_oc_output_low
 * \brief Check get oc output low
 * 
 * \Description{
 *   - check response to read register succeeded
 * }
 * 
 * \Preconditions{
 *   - mock function for osal_transfer_data returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with a valid osal id and valid oc_output_low buffer
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check that expected oc_output_low is equal received oc_output_low
 * }
 *
 * \TestID{TEST_GET_OC_OUTPUT_LOW_0004}
 * 
 */
TEST_F(GetOcOutputLow, TEST_GET_OC_OUTPUT_LOW_0004__ReadRegisterSucceeded) {

    uint8_t oc_output_low = 0;
    
    // register value returned by mock
    uint8_t register_value = 0x5C;

    // calculate expected oc_output_low 
    uint8_t expected_oc_output_low = ((register_value & gpio_out_mask) == gpio_out_mask) ? 0 : 1;

    expectReadRegister(register_address_gpio2, register_value, ERR_SUCCESS);

    EXPECT_EQ(ERR_SUCCESS, as7341_get_oc_output_low(valid_osal_id, &oc_output_low));

    EXPECT_EQ(expected_oc_output_low, oc_output_low);
}

}