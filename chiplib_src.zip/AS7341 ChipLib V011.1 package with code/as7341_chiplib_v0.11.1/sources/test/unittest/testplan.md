Testplan Unittest ChipLib
=========================

as7341_chiplib.c
================

static err_code_t get_item_handler(const osal_id_t osal_id, uint8_t item_id, uint8_t payload_size,
                                   struct config_item_entry **pp_cmd_item_entry)
--------------------------------------------------------------------------------------------------
- unittest
- mock:
    * config_get_item_table

err_code_t as7341_initialize(uint8_t device, as7341_callback_t p_callback, const void *p_cb_param,
                                             const char *p_interface_descr)
--------------------------------------------------------------------------------------------------
- unittest
- mock:
    * spectral_osal_initialize
    * config_initialize
    * measure_initialize

err_code_t as7341_shutdown(uint8_t device)
------------------------------------------
- unittest
- mock
    * measure_shutdown
    * config_shutdown
    * spectral_osal_shutdown

err_code_t as7341_set_configuration(uint8_t device, uint8_t *p_data, uint32_t size)
-----------------------------------------------------------------------------------
- unittest
- mock
    * config_get_item_table

err_code_t as7341_get_configuration(uint8_t device, uint8_t *p_data, uint32_t *p_size)
--------------------------------------------------------------------------------------
- unittest
- mock
    * config_get_item_size
    * config_get_item_table

err_code_t as7341_set_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
-----------------------------------------------------------------------------------------------
- unittest
- mock 
    * config_get_item_table

err_code_t as7341_get_item(uint8_t device, enum as7341_item_ids id, void *p_data, uint8_t size)
-----------------------------------------------------------------------------------------------
- unittest
- mock
    * config_get_item_table

err_code_t as7341_start_measurement(uint8_t device)
---------------------------------------------------
- unittest
- mock
    * spectral_osal_set_event

err_code_t as7341_execute_state_machine(uint8_t device, enum as7341_states *p_state)
------------------------------------------------------------------------------------
- unittest
- mock
    * spectral_osal_wait_for_event
    * measure_get_transition_table
    * measure_set_fsm_error

err_code_t as7341_abort_measurement(uint8_t device)
---------------------------------------------------
- unittest
- mock
    * spectral_osal_set_event


as7341_configuration.c
======================
- component test

as7341_interface.c
==================
- unittest for all global functions excluding open() and close()
- mock layer spectral_osal_chiplib

as7341_measurement.c
====================
- system test
