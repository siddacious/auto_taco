/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#include "chiplib/as7341_configuration.h"

#include "test_fixture.h"

using namespace ChipLibUnittest;

// mock configuration functions
err_code_t config_get_item_table(const osal_id_t osal_id, 
                                 struct config_item_entry **pp_item_entry, 
                                 uint32_t *p_num_of_entries) {

    return TestFixture::_config_mock->mock_config_get_item_table(osal_id, pp_item_entry, p_num_of_entries);
}

err_code_t config_get_item_size(const osal_id_t osal_id, const uint8_t item_id, uint8_t *p_item_size) {

    return TestFixture::_config_mock->mock_config_get_item_size(osal_id, item_id, p_item_size);
}

err_code_t config_initialize(const osal_id_t osal_id) {

    return TestFixture::_config_mock->mock_config_initialize(osal_id);
}

err_code_t config_shutdown(const osal_id_t osal_id) {

    return TestFixture::_config_mock->mock_config_shutdown(osal_id);
}
