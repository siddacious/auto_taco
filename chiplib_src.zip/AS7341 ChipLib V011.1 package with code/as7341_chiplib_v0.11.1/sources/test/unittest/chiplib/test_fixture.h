/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#ifndef __TEST_FIXTURE_H__
#define __TEST_FIXTURE_H__

#include "as7341_chiplib.h"

#include "config_mock.h"
#include "osal_mock.h"
#include "measure_mock.h"

namespace ChipLibUnittest {

/**** constants ********************************************************/

// define special error codes for the test
const err_code_t CONFIG_ITEM_HANDLER_FAILED = (err_code_t)99;
const err_code_t GET_ITEM_FUNCTION_FAILED = (err_code_t)98;
const err_code_t SET_ITEM_FUNCTION_FAILED = (err_code_t)97;


// Create a TestFixture
class TestFixture: public ::testing::Test {
protected:
    void SetUp() override;
    void TearDown() override;

public:
    TestFixture();
    ~TestFixture();

    // pointer for accessing mocked libraries
    static std::unique_ptr<CONFIG_MOCK> _config_mock;
    static std::unique_ptr<OSAL_MOCK> _osal_mock;
    static std::unique_ptr<MEASURE_MOCK> _measure_mock;

protected:
    // valid device id
    const uint8_t valid_device_id = 0;

};

}

#endif // __TEST_FIXTURE_H__
