/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::DoAll;
using ::testing::Return;
using ::testing::SetArgPointee;

namespace ChipLibUnittest
{

/**** test class ********************************************************/

class GetItem : public ::TestFixture
{

  protected:
    // -- organize item table
    // number of entries in item table
    static const uint8_t num_of_entries = 2;
    // container for test item table
    struct config_item_entry my_item_table[num_of_entries] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {0, ITEM_NO_LENGTH_CHECK, NULL, NULL, NO_INDEX_USED},
        {0, ITEM_NO_LENGTH_CHECK, NULL, NULL, NO_INDEX_USED},
    };

    // get item function
    static err_code_t get_item_function(__attribute__((unused)) const osal_id_t osal_id, uint8_t index,
                                        __attribute__((unused)) void *p_data, __attribute__((unused)) uint8_t size)
    {
        // use parameter index to set return code
        return (NO_INDEX_USED > index) ? GET_ITEM_FUNCTION_FAILED : ERR_SUCCESS;
    }

  public:
    /*
     * Function set the item in item table at index [idx] with values [p_item] pointed to.
     * The mock function for config_get_table() is prepared to output the pointer to the item table and
     * the pointer to the number of entries.
     * Also it returns [retval].
     */
    void expectConfigGetItemTable(uint8_t idx, struct config_item_entry *p_item, err_code_t retval)
    {

        if (idx < num_of_entries) {
            my_item_table[idx].item_id = p_item->item_id;
            my_item_table[idx].size = p_item->size;
            my_item_table[idx].get_fct_pnt = p_item->get_fct_pnt;
            my_item_table[idx].index = p_item->index;
        }

        EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _))
            .WillOnce(DoAll(SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(retval)));
    }
};

/**** test definitions ********************************************************/

/*!
 *
 * @defgroup tc_get_item as7341_get_item
 *
 * Test cases for as7341_get_item.
 *
 *
 */

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_ITEM_0001}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0001__DeviceIdIsInvalid)
{

    uint8_t invalid_device_id = 1;
    // dummies
    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    uint8_t item_data[item_size] = {};

    EXPECT_EQ(ERR_ARGUMENT,
              as7341_get_item(invalid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response to null pointer for item data
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with valid device id and null pointer for item data
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_ITEM_0002}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0002__NullPointer)
{

    // dummies
    uint8_t item_id = 1;
    uint8_t item_size = 2;

    EXPECT_EQ(ERR_POINTER, as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, NULL, item_size));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response to invalid fsm state
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_PERMISSION
 * }
 *
 * \TestID{TEST_GET_ITEM_0003}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0003__InvalidFsmState)
{

    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    uint8_t item_data[item_size] = {};

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    EXPECT_EQ(ERR_PERMISSION,
              as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get function is NULL for the item
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - define a valid item table where pointer to get item functions is NULL
 *   - mock function for config_get_item_table returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *   - because get function is not defined for this item
 * }
 *
 * \TestID{TEST_GET_ITEM_0004}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0004__GetFunctionIsNull)
{

    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    // pointer to get item function is NULL
    struct config_item_entry my_entry = {item_id, item_size, NULL, NULL, NO_INDEX_USED};

    expectConfigGetItemTable(0, &my_entry, ERR_SUCCESS);

    uint8_t item_data[item_size] = {};

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(ERR_ARGUMENT,
              as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get function succeeded for the item
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - define a valid item table where pointer to get item functions is valid
 *   - this get function should return ERR_SUCCESS
 *   - mock function for config_get_item_table returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_GET_ITEM_0005}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0005__GetFunctionSucceeded)
{

    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    // pointer to get item function -> get_item_function
    // because index = NO_INDEX_USED -> get_item_function returns ERR_SUCCESS
    struct config_item_entry my_entry = {item_id, item_size, NULL, &get_item_function, NO_INDEX_USED};

    expectConfigGetItemTable(0, &my_entry, ERR_SUCCESS);

    uint8_t item_data[item_size] = {};

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get function failed for the item
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - define a valid item table where pointer to get item functions is valid
 *   - this get function should return special error code GET_ITEM_FUNCTION_FAILED
 *   - mock function for config_get_item_table returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is GET_ITEM_FUNCTION_FAILED
 * }
 *
 * \TestID{TEST_GET_ITEM_0006}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0006__GetFunctionFailed)
{

    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    // pointer to get item function -> get_item_function
    // because index < NO_INDEX_USED -> get_item_function returns GET_ITEM_FUNCTION_FAILED
    struct config_item_entry my_entry = {item_id, item_size, NULL, &get_item_function, 254};

    expectConfigGetItemTable(0, &my_entry, ERR_SUCCESS);

    uint8_t item_data[item_size];
    memset(item_data, 0, item_size * sizeof(uint8_t));

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(GET_ITEM_FUNCTION_FAILED,
              as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

/*!
 * \ingroup tc_get_item
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get item table failed
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - mock function for config_get_item_table returns special error code CONFIG_ITEM_HANDLER_FAILED
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is CONFIG_ITEM_HANDLER_FAILED
 * }
 *
 * \TestID{TEST_GET_ITEM_0007}
 *
 */
TEST_F(GetItem, TEST_GET_ITEM_0007__GetItemTableFailed)
{

    uint8_t item_id = 1;
    const uint8_t item_size = 2;
    uint8_t item_size_param = item_size;
    struct config_item_entry my_entry = {item_id, item_size, NULL, NULL, NO_INDEX_USED};

    expectConfigGetItemTable(0, &my_entry, CONFIG_ITEM_HANDLER_FAILED);

    uint8_t item_data[item_size] = {};

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(CONFIG_ITEM_HANDLER_FAILED,
              as7341_get_item(valid_device_id, (enum as7341_item_ids)item_id, item_data, item_size_param));
}

} // namespace ChipLibUnittest
