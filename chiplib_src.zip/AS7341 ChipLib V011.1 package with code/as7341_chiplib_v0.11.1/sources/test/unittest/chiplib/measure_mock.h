/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#ifndef MEASURE_MOCK_H
#define MEASURE_MOCK_H

#include "gmock/gmock.h"

#include "chiplib/as7341_measurement.h"

namespace ChipLibUnittest {

// Mock measurement functions
class MEASURE_MOCK{
public:
    virtual ~MEASURE_MOCK(){}

    // mock methods
    MOCK_METHOD(err_code_t, mock_measure_initialize, (const osal_id_t osal_id, as7341_callback_t p_callback, const void *p_callback_parameter));
    MOCK_METHOD(err_code_t, mock_measure_shutdown, (const osal_id_t osal_id));
    MOCK_METHOD(err_code_t, mock_measure_get_transition_table, (const osal_id_t osal_id, struct transitions **pp_transition_table, uint32_t *p_num_transitions));
    MOCK_METHOD(err_code_t, mock_measure_set_fsm_error, (const osal_id_t osal_id, err_code_t error_code));
};

}

#endif // MEASURE_MOCK_H