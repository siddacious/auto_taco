/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::Return;
using ::testing::DoAll;
using ::testing::SetArgPointee;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class GetItemHandler : public ::TestFixture {

protected:
    // valid osal id
    const osal_id_t osal_id = {CHIP_LIB_IDENT, valid_device_id};
    // test item to check item pointers
    struct config_item_entry item_entry = { 1, 2, NULL, NULL, 3 };

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_get_item_handler get_item_handler
*
* Test cases for get_item_handler.
*
*
*/

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response to invalid item id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with the invalid item id ITEM_ID_MAX
 *     and ITEM_ID_MAX + 1
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0001}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0001__ItemIdIsInvalid) {

    // invalid item id: bigger than 35 (ITEM_ID_MAX)
    uint8_t item_id = ITEM_ID_MAX;
    uint8_t item_size = 10;
    struct config_item_entry *p_item_entry = NULL;

    EXPECT_EQ(ERR_ARGUMENT, get_item_handler(osal_id, item_id, item_size, &p_item_entry));

    item_id = ITEM_ID_MAX + 1;
    EXPECT_EQ(ERR_ARGUMENT, get_item_handler(osal_id, item_id, item_size, &p_item_entry));
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table failed
 * }
 *
 * \Preconditions{
 *   - mock function for config_get_item_table returns ERR_NOT_SUPPORTED
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_NOT_SUPPORTED
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0002}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0002__GetConfigurationTableFailed) {

    uint8_t item_id = 1;
    uint8_t item_size = 10;
    struct config_item_entry *p_item_entry = NULL;

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillOnce(Return(ERR_NOT_SUPPORTED));

    EXPECT_EQ(ERR_NOT_SUPPORTED, get_item_handler(osal_id, item_id, item_size, &p_item_entry));
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table succeeded but
 *   - output number of entries is zero
 * }
 *
 * \Preconditions{
 *   - mock function for config_get_item_table returns ERR_SUCCESS
 *   - set pointer to number of items to zero
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - output pointer to item is NULL
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0003}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0003__ConfigurationTableNumberOfEntriesIsZero) {

    uint8_t item_id = 1;
    uint8_t item_size = 10;
    struct config_item_entry *p_item_entry = &item_entry;

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillOnce(
        DoAll(SetArgPointee<2>(0), Return(ERR_SUCCESS)));

    EXPECT_EQ(ERR_SUCCESS, get_item_handler(osal_id, item_id, item_size, &p_item_entry));

    EXPECT_EQ(NULL, p_item_entry);
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table succeeded and
 *   - output number of entries is greater than zero and
 *   - item size is checked
 * }
 *
 * \Preconditions{
 *   - define a valid item table where item size is not 255 - means item size is checked
 *   - mock function for config_get_item_table returns ERR_SUCCESS and
 *   - set pointer to item table to defined table and
 *   - set pointer to number of items to current number of items of defined table
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 *   - item size is item size in defined table
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - output pointer to item is the right pointer in item table
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0004}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0004__ConfigurationTableNumberOfEntriesIsGreaterThanZero) {

    uint8_t item_id = 1;
    uint8_t item_size = 10;
    struct config_item_entry *p_item_entry = &item_entry;

    // test item table
    struct config_item_entry my_item_table[] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {item_id, item_size, NULL, NULL, NO_INDEX_USED},
    };
    uint8_t num_of_entries = sizeof(my_item_table) / sizeof(struct config_item_entry);

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillOnce(DoAll(
        SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));

    EXPECT_EQ(ERR_SUCCESS, get_item_handler(osal_id, item_id, item_size, &p_item_entry));

    EXPECT_EQ(&my_item_table[0], p_item_entry);
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table succeeded and
 *   - output number of entries is greater than zero and
 *   - item size is not checked
 * }
 *
 * \Preconditions{
 *   - define a valid item table where item size is 255 - means item size is not checked
 *   - mock function for config_get_item_table returns ERR_SUCCESS and
 *   - set pointer to item table to defined table and
 *   - set pointer to number of items to current number of items of defined table
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 *   - item size is not item size in defined table
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - output pointer to item is the right pointer in item table
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0005}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0005__ItemSizeIsNotChecked) {

    uint8_t item_id = 1;
    uint8_t item_size = 255; // ITEM_NO_LENGTH_CHECK
    struct config_item_entry *p_item_entry = &item_entry;

    struct config_item_entry my_item_table[] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {item_id, item_size, NULL, NULL, NO_INDEX_USED},
    };
    uint8_t num_of_entries = sizeof(my_item_table) / sizeof(struct config_item_entry);

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillOnce(DoAll(
        SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));

    // change item size
    item_size = item_size + 1;
    EXPECT_EQ(ERR_SUCCESS, get_item_handler(osal_id, item_id, item_size, &p_item_entry));

    EXPECT_EQ(&my_item_table[0], p_item_entry);
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table succeeded and
 *   - output number of entries is greater than zero and
 *   - item size is checked
 * }
 *
 * \Preconditions{
 *   - define a valid item table where item size is not 255 - means item size is checked
 *   - mock function for config_get_item_table returns ERR_SUCCESS and
 *   - set pointer to item table to defined table and
 *   - set pointer to number of items to current number of items of defined table
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 *   - item size is not item size in defined table
 * }
 *
 * \Expectations{
 *   - return code is ERR_SIZE
 *   - output pointer to item is NULL
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0006}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0006__ItemSizeIsWrong) {

    uint8_t item_id = 1;
    uint8_t item_size = 10;
    struct config_item_entry *p_item_entry = &item_entry;

    // test item table
    struct config_item_entry my_item_table[] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {item_id, item_size, NULL, NULL, NO_INDEX_USED},
    };
    uint8_t num_of_entries = sizeof(my_item_table) / sizeof(struct config_item_entry);

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillOnce(DoAll(
        SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));

    // change item size
    item_size = item_size + 1;
    EXPECT_EQ(ERR_SIZE, get_item_handler(osal_id, item_id, item_size, &p_item_entry));

    EXPECT_EQ(NULL, p_item_entry);
}

/*!
 * \ingroup tc_get_item_handler
 * \brief Check get item handler
 *
 * \Description{
 *   - check response if get configuration table succeeded and
 *   - output number of entries is greater than zero
 * }
 *
 * \Preconditions{
 *   - define a valid item table with some items
 *   - item size of one item should be 255
 *   - item size of other items should be less than 255
 *   - mock function for config_get_item_table returns ERR_SUCCESS and
 *   - set pointer to item table to defined table and
 *   - set pointer to number of items to current number of items of defined table
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - output pointer to item is the right pointer in item table
 * }
 *
 * \TestID{TEST_GET_ITEM_HANDLER_0007}
 *
 */
TEST_F(GetItemHandler, TEST_GET_ITEM_HANDLER_0007__ConfigurationTableNumberOfEntriesIsGreaterThanZero) {

    struct config_item_entry *p_item_entry = &item_entry;
    uint8_t my_payload_size;

    // test item table
    struct config_item_entry my_item_table[] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {1, 10, NULL, NULL, NO_INDEX_USED},
        {2, 20, NULL, NULL, NO_INDEX_USED},
        {3, 255, NULL, NULL, NO_INDEX_USED},
        {4, 40, NULL, NULL, NO_INDEX_USED},
    };
    uint8_t num_of_entries = sizeof(my_item_table) / sizeof(struct config_item_entry);

    EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillRepeatedly(DoAll(
        SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));

    for (int i = 0; i < num_of_entries; i++) {
        // take item id from item table
        // set item size to size from item table if it is not 255 else to 254
        my_payload_size = (my_item_table[i].size != 255) ? my_item_table[i].size : 254;
        EXPECT_EQ(ERR_SUCCESS, get_item_handler(osal_id, my_item_table[i].item_id, my_payload_size, &p_item_entry));

        EXPECT_EQ(&my_item_table[i], p_item_entry);
    }

}

}
