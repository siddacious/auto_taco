/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::Return;

namespace ChipLibUnittest
{

// callback function
// Note: The parameters of this function are not used for the unittest.
void my_callback(__attribute__((unused)) uint8_t device, __attribute__((unused)) uint8_t error,
                 __attribute__((unused)) void *p_data, __attribute__((unused)) uint32_t data_size,
                 __attribute__((unused)) void *p_items, __attribute__((unused)) uint32_t items_size,
                 __attribute__((unused)) void *p_cb_param)
{
}

/**** test class ********************************************************/

class Initialize : public ::TestFixture
{
};

/**** test definitions ********************************************************/

/*!
 *
 * @defgroup tc_initialize as7341_initialize
 *
 * Test cases for as7341_initialize.
 *
 *
 */

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_INITIALIZE_0001}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0001__DeviceIdIsInvalid)
{

    uint8_t invalid_device_id = 1;
    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_EQ(ERR_ARGUMENT, as7341_initialize(invalid_device_id, my_callback, p_cb_param, p_interface_descr));
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response to null pointer for callback function
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with valid device id and null pointer for callback function
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_INITIALIZE_0002}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0002__NullPointer)
{

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_EQ(ERR_POINTER, as7341_initialize(valid_device_id, NULL, p_cb_param, p_interface_descr));
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response to invalid fsm state
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_PERMISSION
 * }
 *
 * \TestID{TEST_INITIALIZE_0003}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0003__InvalidFsmState)
{

    g_fsm_state[0] = FSM_STATE_IDLE;

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_EQ(ERR_PERMISSION, as7341_initialize(valid_device_id, my_callback, p_cb_param, p_interface_descr));
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response if initialization of operation system abstraction layer failed
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 *   - mock function for spectral_osal_initialize returns ERR_NOT_SUPPORTED
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_NOT_SUPPORTED
 *   - fsm state is UNKNOWN
 * }
 *
 * \TestID{TEST_INITIALIZE_0004}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0004__OsalInitFailed)
{

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_CALL(*_osal_mock, mock_osal_initialize(_, _)).WillOnce(Return(ERR_NOT_SUPPORTED));

    EXPECT_EQ(ERR_NOT_SUPPORTED, as7341_initialize(valid_device_id, my_callback, p_cb_param, p_interface_descr));

    EXPECT_EQ(FSM_STATE_UNKNOWN, g_fsm_state[0]);
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response if initialization of configuration failed
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 *   - mock function for spectral_osal_initialize returns ERR_SUCCESS
 *   - mock function for config_initialize returns ERR_NOT_SUPPORTED
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_NOT_SUPPORTED
 *   - fsm state is UNKNOWN
 * }
 *
 * \TestID{TEST_INITIALIZE_0005}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0005__ConfigurationInitFailed)
{

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_CALL(*_osal_mock, mock_osal_initialize(_, _)).WillOnce(Return(ERR_SUCCESS));
    EXPECT_CALL(*_config_mock, mock_config_initialize(_)).WillOnce(Return(ERR_NOT_SUPPORTED));

    EXPECT_EQ(ERR_NOT_SUPPORTED, as7341_initialize(valid_device_id, my_callback, p_cb_param, p_interface_descr));

    EXPECT_EQ(FSM_STATE_UNKNOWN, g_fsm_state[0]);
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response if initialization of measurement failed
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 *   - mock function for spectral_osal_initialize returns ERR_SUCCESS
 *   - mock function for config_initialize returns ERR_SUCCESS
 *   - mock function for measure_initialize returns ERR_NOT_SUPPORTED
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_NOT_SUPPORTED
 *   - fsm state is UNKNOWN
 * }
 *
 * \TestID{TEST_INITIALIZE_0006}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0006__MeasurementInitFailed)
{

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_CALL(*_osal_mock, mock_osal_initialize(_, _)).WillOnce(Return(ERR_SUCCESS));
    EXPECT_CALL(*_config_mock, mock_config_initialize(_)).WillOnce(Return(ERR_SUCCESS));
    EXPECT_CALL(*_measure_mock, mock_measure_initialize(_, _, _)).WillOnce(Return(ERR_NOT_SUPPORTED));

    EXPECT_EQ(ERR_NOT_SUPPORTED, as7341_initialize(valid_device_id, my_callback, p_cb_param, p_interface_descr));

    EXPECT_EQ(FSM_STATE_UNKNOWN, g_fsm_state[0]);
}

/*!
 * \ingroup tc_initialize
 * \brief Check initialization of library and device
 *
 * \Description{
 *   - check response if initialization succeeded complete
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 *   - mock function for spectral_osal_initialize returns ERR_SUCCESS
 *   - mock function for config_initialize returns ERR_SUCCESS
 *   - mock function for measure_initialize returns ERR_SUCCESS
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - fsm state is IDLE
 * }
 *
 * \TestID{TEST_INITIALIZE_0007}
 *
 */
TEST_F(Initialize, TEST_INITIALIZE_0007__InitializationSucceeded)
{

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    const void *p_cb_param = NULL;
    const char *p_interface_descr = NULL;

    EXPECT_CALL(*_osal_mock, mock_osal_initialize(_, _)).WillOnce(Return(ERR_SUCCESS));
    EXPECT_CALL(*_config_mock, mock_config_initialize(_)).WillOnce(Return(ERR_SUCCESS));
    EXPECT_CALL(*_measure_mock, mock_measure_initialize(_, _, _)).WillOnce(Return(ERR_SUCCESS));

    EXPECT_EQ(ERR_SUCCESS, as7341_initialize(valid_device_id, my_callback, p_cb_param, p_interface_descr));

    EXPECT_EQ(FSM_STATE_IDLE, g_fsm_state[0]);
}

} // namespace ChipLibUnittest