/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::Return;
using ::testing::Matcher;

namespace ChipLibUnittest {

// matcher for struct osal_id_t
MATCHER_P(EqOsalId, other_osal_id, "") {
    return arg.chip == other_osal_id.chip && arg.dev == other_osal_id.dev;
}

/**** test class ********************************************************/

class StartMeasurement : public ::TestFixture {


};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_start_measurement as7341_start_measurement
*
* Test cases for as7341_start_measurement.
*
*
*/


/*!
 * \ingroup tc_start_measurement
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_START_MEASUREMENT_0001}
 * 
 */
TEST_F(StartMeasurement, TEST_START_MEASUREMENT_0001__DeviceIdIsInvalid) {

    uint8_t invalid_device_id = 1;

    EXPECT_EQ(ERR_ARGUMENT, as7341_start_measurement(invalid_device_id));
}

/*!
 * \ingroup tc_start_measurement
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response to invalid fsm state
 * }
 * 
 * \Preconditions{
 *   - fsm state is UNKNOWN
 * }
 * 
 * \Steps{
 *   - call test function with valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_PERMISSION
 * }
 *
 * \TestID{TEST_START_MEASUREMENT_0002}
 * 
 */
TEST_F(StartMeasurement, TEST_START_MEASUREMENT_0002__InvalidFsmState) {

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    EXPECT_EQ(ERR_PERMISSION, as7341_start_measurement(valid_device_id));
}

/*!
 * \ingroup tc_start_measurement
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response if set event failed
 * }
 * 
 * \Preconditions{
 *   - fsm state is IDLE
 *   - mock function for spectral_osal_set_event returns ERR_NOT_SUPPORTED
 * }
 * 
 * \Steps{
 *   - call test function with valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_NOT_SUPPORTED
 * }
 *
 * \TestID{TEST_START_MEASUREMENT_0003}
 * 
 */
TEST_F(StartMeasurement, TEST_START_MEASUREMENT_0003__OsalSetEventFailed) {

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_CALL(*_osal_mock, mock_osal_set_event(_, _, _)).WillOnce(Return(ERR_NOT_SUPPORTED));

    EXPECT_EQ(ERR_NOT_SUPPORTED, as7341_start_measurement(valid_device_id));
}

/*!
 * \ingroup tc_start_measurement
 * \brief Check start measurement
 * 
 * \Description{
 *   - check response if set event succeeded
 * }
 * 
 * \Preconditions{
 *   - fsm state is IDLE
 *   - mock function for spectral_osal_set_event returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - check arguments of called function spectral_osal_set_event(): event is START
 * }
 *
 * \TestID{TEST_START_MEASUREMENT_0004}
 * 
 */
TEST_F(StartMeasurement, TEST_START_MEASUREMENT_0004__OsalSetEventSucceeded) {

    g_fsm_state[0] = FSM_STATE_IDLE;
    const osal_id_t osal_id = {CHIP_LIB_IDENT, 0};

    EXPECT_CALL(*_osal_mock, mock_osal_set_event(EqOsalId(osal_id), EVENT_START, 0)).WillOnce(Return(ERR_SUCCESS));

    EXPECT_EQ(ERR_SUCCESS, as7341_start_measurement(valid_device_id));
}

}