/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#include "spectral_osal_chiplib.h"
#include "spectral_osal_logging.h"

#include "test_fixture.h"

using namespace ChipLibUnittest;

// mock osal (operation system abstraction layer) functions
err_code_t spectral_osal_initialize(const osal_id_t osal_id, const char *p_interface_desc) {
    return TestFixture::_osal_mock->mock_osal_initialize(osal_id, p_interface_desc);
}

err_code_t spectral_osal_shutdown(const osal_id_t osal_id) {
    return TestFixture::_osal_mock->mock_osal_shutdown(osal_id);
}

err_code_t spectral_osal_set_event(const osal_id_t osal_id, uint16_t event, uint16_t payload) {
    return TestFixture::_osal_mock->mock_osal_set_event(osal_id, event, payload);
}

err_code_t spectral_osal_wait_for_event(const osal_id_t osal_id, uint16_t *p_event, uint16_t *p_payload) {
    return TestFixture::_osal_mock->mock_osal_wait_for_event(osal_id, p_event, p_payload);
}

err_code_t spectral_osal_check_pending_interrupt(const osal_id_t osal_id) {
    return TestFixture::_osal_mock->mock_osal_check_pending_interrupt(osal_id);
}

err_code_t spectral_osal_transfer_data(const osal_id_t osal_id, uint8_t *p_send_data, uint8_t send_data_size,
                                       uint8_t *p_receive_data, uint8_t receive_data_size) {
    return TestFixture::_osal_mock->mock_osal_transfer_data(osal_id, p_send_data, send_data_size,
                                                            p_receive_data, receive_data_size);									
}

err_code_t spectral_osal_configure_timer(const osal_id_t osal_id, uint8_t timer_id, uint32_t timer_us) {
    return TestFixture::_osal_mock->mock_osal_configure_timer(osal_id, timer_id, timer_us);
}

err_code_t spectral_osal_set_led(const osal_id_t osal_id, uint8_t led_id, uint16_t brightness) {
    return TestFixture::_osal_mock->mock_osal_set_led(osal_id, led_id, brightness);
}

err_code_t spectral_osal_get_temperature(const osal_id_t osal_id, uint8_t temp_id, uint32_t *p_temperature) {
    return TestFixture::_osal_mock->mock_osal_get_temperature(osal_id, temp_id, p_temperature);
}

err_code_t spectral_osal_get_timestamp(const osal_id_t osal_id, uint32_t *p_timestamp_us) {
    return TestFixture::_osal_mock->mock_osal_get_timestamp(osal_id, p_timestamp_us);
}

// fake logging function
// Note: The parameters of this function are not used for the unittest.
void spectral_osal_logging(__attribute__((unused)) osal_id_t osal_id, 
                           __attribute__((unused)) uint8_t level, 
                           __attribute__((unused)) const char *module_name, 
                           __attribute__((unused)) const char *fmt, ...) {}

