/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#ifndef OSAL_MOCK_
#define OSAL_MOCK_

#include "gmock/gmock.h"

#include "spectral_osal_chiplib.h"

namespace ChipLibUnittest {

// Mock osal functions
class OSAL_MOCK{
public:
    virtual ~OSAL_MOCK(){}

    // mock methods
    MOCK_METHOD(err_code_t, mock_osal_initialize, (const osal_id_t, const char*));
    MOCK_METHOD(err_code_t, mock_osal_shutdown, (const osal_id_t));
    MOCK_METHOD(err_code_t, mock_osal_transfer_data, (const osal_id_t, uint8_t*, uint8_t, uint8_t*, uint8_t));
    MOCK_METHOD(err_code_t, mock_osal_set_event, (const osal_id_t, uint16_t, uint16_t));
    MOCK_METHOD(err_code_t, mock_osal_wait_for_event, (const osal_id_t, uint16_t*, uint16_t*));
    MOCK_METHOD(err_code_t, mock_osal_check_pending_interrupt, (const osal_id_t));
    MOCK_METHOD(err_code_t, mock_osal_configure_timer, (const osal_id_t, uint8_t, uint32_t));
    MOCK_METHOD(err_code_t, mock_osal_set_led, (const osal_id_t, uint8_t, uint16_t));
    MOCK_METHOD(err_code_t, mock_osal_get_temperature, (const osal_id_t, uint8_t, uint32_t*));
    MOCK_METHOD(err_code_t, mock_osal_get_timestamp, (const osal_id_t, uint32_t*));
};

}

#endif // OSAL_MOCK_