/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#ifndef CONFIG_MOCK_H
#define CONFIG_MOCK_H

#include "gmock/gmock.h"

#include "chiplib/as7341_configuration.h"

namespace ChipLibUnittest {

// Mock configuration functions
class CONFIG_MOCK{
public:
    virtual ~CONFIG_MOCK(){}

    // mock methods
    MOCK_METHOD(err_code_t, mock_config_get_item_table, (const osal_id_t osal_id, struct config_item_entry **pp_item_entry, uint32_t *p_num_of_entries));
    MOCK_METHOD(err_code_t, mock_config_get_item_size, (const osal_id_t osal_id, const uint8_t item_id, uint8_t *p_item_size));
    MOCK_METHOD(err_code_t, mock_config_initialize, (const osal_id_t osal_id));
    MOCK_METHOD(err_code_t, mock_config_shutdown, (const osal_id_t osal_id));
};

}

#endif // CONFIG_MOCK_H