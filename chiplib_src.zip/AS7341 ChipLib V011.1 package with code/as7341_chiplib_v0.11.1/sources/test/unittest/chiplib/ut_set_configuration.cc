/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::Return;
using ::testing::DoAll;
using ::testing::SetArgPointee;
using ::testing::ElementsAreArray;

namespace ChipLibUnittest {

/**** test class ********************************************************/

class SetConfiguration : public ::TestFixture {

protected:
    // -- define item table
    // number of entries in item table
    static const uint8_t num_of_entries = 3;
    // test item table
    struct config_item_entry my_item_table[num_of_entries] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {1, 3, set_item_function, NULL, NO_INDEX_USED},
        {2, 4, set_item_function, NULL, NO_INDEX_USED},
        {3, 2, set_item_function, NULL, NO_INDEX_USED},
    };

    // set item function
    static err_code_t set_item_function(__attribute__((unused)) const osal_id_t osal_id, 
                                        __attribute__((unused)) uint8_t index, 
                                        __attribute__((unused)) void *p_data, 
                                        __attribute__((unused)) uint8_t size)
    {
        return ERR_SUCCESS;
    }

public:
    /* 
     * The mock function for config_get_table() is prepared to output the pointer to the item table and 
     * the pointer to the number of entries.
     * Also it returns ERR_SUCCESS. 
     */
    void expectConfigGetItemTable() {

        EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _)).WillRepeatedly(DoAll(
            SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));
    }

    /*
     * Get the number of bytes needed to fill a byte buffer with data recording to the item table.
     */
    uint32_t getNumOfBytes() {

        uint32_t num_of_bytes = 0;
    
        for (int i = 0; i < num_of_entries; i++) {
            // item data size: 1 byte
            num_of_bytes += 1;
            // item id: 1 byte
            num_of_bytes += 1;
            // item data: see item table
            num_of_bytes += my_item_table[i].size;
        }

        return num_of_bytes;
    }

    /*
     * Get data from item table
     */
    void getDataFromItemTable(uint8_t *p_data) {
        
        int k;
        for (int i = 0; i < num_of_entries; i++) {
            // item data size
            *p_data++ = my_item_table[i].size;
            // item id
            *p_data++ = my_item_table[i].item_id;
            // item data
            for (k = 0; k < my_item_table[i].size; k++) {
                // generate some data
                *p_data++ = 10 * my_item_table[i].item_id + k;
            }
        }
    }

};

/**** test definitions ********************************************************/

/*!
*
* @defgroup tc_set_configuration as7341_set_configuration
*
* Test cases for as7341_set_configuration.
*
*
*/


/*!
 * \ingroup tc_set_configuration
 * \brief Check set configuration
 * 
 * \Description{
 *   - check response to invalid device id
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with an invalid device id
 * }
 * 
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 * }
 *
 * \TestID{TEST_SET_CONFIGURATION_0001}
 * 
 */
TEST_F(SetConfiguration, TEST_SET_CONFIGURATION_0001__DeviceIdIsInvalid) {

    uint8_t invalid_device_id = 1;
    // dummies
    uint8_t data[10] = {0};
    uint32_t size = 10;

    EXPECT_EQ(ERR_ARGUMENT, as7341_set_configuration(invalid_device_id, data, size));
}

/*!
 * \ingroup tc_set_configuration
 * \brief Check set configuration
 * 
 * \Description{
 *   - check response to null pointer for data
 * }
 * 
 * \Preconditions{
 *   - none
 * }
 * 
 * \Steps{
 *   - call test function with valid device id and null pointer for data
 * }
 * 
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_SET_CONFIGURATION_0002}
 * 
 */
TEST_F(SetConfiguration, TEST_SET_CONFIGURATION_0002__NullPointer) {

    // dummies
    uint32_t size = 10;

    EXPECT_EQ(ERR_POINTER, as7341_set_configuration(valid_device_id, NULL, size));
}

/*!
 * \ingroup tc_set_configuration
 * \brief Check set configuration
 * 
 * \Description{
 *   - check response to invalid fsm state
 * }
 * 
 * \Preconditions{
 *   - fsm state is UNKNOWN
 * }
 * 
 * \Steps{
 *   - call test function with valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_PERMISSION
 * }
 *
 * \TestID{TEST_SET_CONFIGURATION_0003}
 * 
 */
TEST_F(SetConfiguration, TEST_SET_CONFIGURATION_0003__InvalidFsmState) {

    // dummies
    uint8_t data[10] = {0};
    uint32_t size = 10;

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    EXPECT_EQ(ERR_PERMISSION, as7341_set_configuration(valid_device_id, data, size));
}

/*!
 * \ingroup tc_set_configuration
 * \brief Check set configuration
 * 
 * \Description{
 *   - check response if set all items succeeded
 * }
 * 
 * \Preconditions{
 *   - fsm state is IDLE
 *   - define a valid item table where pointer to set item functions is valid
 *   - this set function should return ERR_SUCCESS
 *   - mock function for config_get_item_table returns ERR_SUCCESS
 * }
 * 
 * \Steps{
 *   - call test function with valid arguments
 * }
 * 
 * \Expectations{
 *   - return code is ERR_SUCCESS
 * }
 *
 * \TestID{TEST_SET_CONFIGURATION_0004}
 * 
 */
TEST_F(SetConfiguration, TEST_SET_CONFIGURATION_0004__SetAllItemsSucceeded) {

    expectConfigGetItemTable();

    g_fsm_state[0] = FSM_STATE_IDLE;

    uint32_t num_of_bytes = getNumOfBytes();
    uint8_t data[num_of_bytes];

    getDataFromItemTable(data);
    // check data array
    EXPECT_EQ(15, num_of_bytes);
    // item format: <size of item data> <item id> <item data 0> .. <item data N>
    // size of item data = N +1 
    uint8_t expected_data[] = { /* item 0: */ 3, 1, 10, 11, 12, 
                                /* item 1: */ 4, 2, 20, 21, 22, 23, 
                                /* item 2: */ 2, 3, 30, 31};
    EXPECT_THAT(std::vector<uint8_t>(data, data + num_of_bytes), ElementsAreArray(expected_data));

    EXPECT_EQ(ERR_SUCCESS, as7341_set_configuration(valid_device_id, data, num_of_bytes));

}

}