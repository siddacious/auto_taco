/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/

#include "chiplib/as7341_measurement.h"

#include "test_fixture.h"

using namespace ChipLibUnittest;

// mock measurement functions
err_code_t measure_initialize(const osal_id_t osal_id, as7341_callback_t p_callback, const void *p_callback_parameter) {

    return TestFixture::_measure_mock->mock_measure_initialize(osal_id, p_callback, p_callback_parameter);
}

err_code_t measure_shutdown(const osal_id_t osal_id) {

    return TestFixture::_measure_mock->mock_measure_shutdown(osal_id);
}

err_code_t measure_get_transition_table(const osal_id_t osal_id, 
                                        struct transitions **pp_transition_table, 
                                        uint32_t *p_num_transitions) {

    return TestFixture::_measure_mock->mock_measure_get_transition_table(osal_id, pp_transition_table, p_num_transitions);
}

err_code_t measure_set_fsm_error(const osal_id_t osal_id, err_code_t error_code) {

    return TestFixture::_measure_mock-> mock_measure_set_fsm_error(osal_id, error_code);
}
