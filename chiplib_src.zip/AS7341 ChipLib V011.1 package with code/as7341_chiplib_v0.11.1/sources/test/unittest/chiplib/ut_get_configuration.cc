/*
*****************************************************************************
* Copyright by ams AG                                                       *
* All rights are reserved.                                                  *
*                                                                           *
* IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
* THE SOFTWARE.                                                             *
*                                                                           *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
*****************************************************************************
*/
#include "as7341_chiplib.c"

#include "test_fixture.h"

using namespace ChipLibUnittest;
using ::testing::_;
using ::testing::DoAll;
using ::testing::Return;
using ::testing::SetArgPointee;

namespace ChipLibUnittest
{

/**** test class ********************************************************/

class GetConfiguration : public ::TestFixture
{

  protected:
    // -- define item table
    // Test item table is recreated g_item_table in as7341_configuration.c
    // Number of entries in item table is defined as ITEM_ID_MAX in as7341_typedefs.h
    static const uint8_t num_of_entries = ITEM_ID_MAX;
    // It is mandatory that all item sizes have the same value,
    // because this value can be simple returned by the mock function config_get_item_size.
    const uint8_t default_item_size = 2;
    // It is mandatory, that all defined item ids are used to fill the table,
    // because the test function handles the define ITEM_ID_MAX!
    struct config_item_entry my_item_table[num_of_entries] = {
        /* COMMAND_ID | PAYLOAD_SIZE | SET_FUNCTION_POINTER | GET_FUNCTION_POINTER | USED_INDEX */
        {ITEM_ID_ASTEP, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_ATIME, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_BREAK, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_ITIME, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_MEAS_TYPE, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_AGAIN, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_CHANNELS, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_VERSION, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_SERIAL, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_AUTOZERO, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_MEAS_COUNT, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_PATTERN, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_WAIT_TIME, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_INTERRUPT_PIN, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_INTERN, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_0, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_1, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_2, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_3, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_4, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_LED_EXT_5, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_OUTPUT, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_TEMP_EXT_0, default_item_size, NULL, get_item_function, 0},
        {ITEM_ID_TEMP_EXT_1, default_item_size, NULL, get_item_function, 1},
        {ITEM_ID_TEMP_EXT_2, default_item_size, NULL, get_item_function, 2},
        {ITEM_ID_TEMP_EXT_3, default_item_size, NULL, get_item_function, 3},
        {ITEM_ID_TEMP_EXT_4, default_item_size, NULL, get_item_function, 4},
        {ITEM_ID_TEMP_EXT_5, default_item_size, NULL, get_item_function, 5},
        {ITEM_ID_MEASURE_ITEMS, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_FGAIN, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_FTIME, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_FTIME_US, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_FCHANNELS, default_item_size, NULL, get_item_function, NO_INDEX_USED},
        {ITEM_ID_TIMESTAMP, default_item_size, NULL, get_item_function, NO_INDEX_USED},
    };

    // get item function
    static err_code_t get_item_function(__attribute__((unused)) const osal_id_t osal_id,
                                        __attribute__((unused)) uint8_t index, __attribute__((unused)) void *p_data,
                                        __attribute__((unused)) uint8_t size)
    {
        return ERR_SUCCESS;
    }

  public:
    /*
     * The mock function for config_get_table() is prepared to output the pointer to the item table and
     * the pointer to the number of entries.
     * Also it returns ERR_SUCCESS.
     */
    void expectConfigGetItemTable()
    {

        EXPECT_CALL(*_config_mock, mock_config_get_item_table(_, _, _))
            .WillRepeatedly(
                DoAll(SetArgPointee<1>(my_item_table), SetArgPointee<2>(num_of_entries), Return(ERR_SUCCESS)));
    }
};

/**** test definitions ********************************************************/

/*!
 *
 * @defgroup tc_get_configuration as7341_get_configuration
 *
 * Test cases for as7341_get_configuration.
 *
 *
 */

/*!
 * \ingroup tc_get_configuration
 * \brief Check get configuration handler
 *
 * \Description{
 *   - check response to invalid device id
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with an invalid device id
 * }
 *
 * \Expectations{
 *   - return code is ERR_ARGUMENT
 *
 * \TestID{TEST_GET_CONFIGURATION_0001}
 *
 */
TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0001__DeviceIdIsInvalid)
{

    uint8_t invalid_device_id = 1;
    // dummies
    const uint32_t config_buf_size = 2;
    uint32_t config_buf_size_param = config_buf_size;
    uint8_t config_buf_data[config_buf_size] = {};

    EXPECT_EQ(ERR_ARGUMENT, as7341_get_configuration(invalid_device_id, config_buf_data, &config_buf_size_param));
}

/*!
 * \ingroup tc_get_configuration
 * \brief Check get configuration handler
 *
 * \Description{
 *   - check response to null pointer for config buffer size
 * }
 *
 * \Preconditions{
 *   - none
 * }
 *
 * \Steps{
 *   - call test function with valid device id and null pointer for config buffer size
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_CONFIGURATION_0002}
 *
 */
TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0002__NullPointerConfigBufferSize)
{

    // dummies
    uint8_t config_buf_data[2] = {0};

    EXPECT_EQ(ERR_POINTER, as7341_get_configuration(valid_device_id, config_buf_data, NULL));
}

/*!
 * \ingroup tc_get_configuration
 * \brief Check get configuration handler
 *
 * \Description{
 *   - check response to invalid fsm state
 * }
 *
 * \Preconditions{
 *   - fsm state is UNKNOWN
 * }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_PERMISSION
 * }
 *
 * \TestID{TEST_GET_CONFIGURATION_0003}
 *
 */
TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0003__InvalidFsmState)
{

    // dummies
    const uint32_t config_buf_size = 2;
    uint32_t config_buf_size_param = config_buf_size;
    uint8_t config_buf_data[config_buf_size] = {};

    g_fsm_state[0] = FSM_STATE_UNKNOWN;

    EXPECT_EQ(ERR_PERMISSION, as7341_get_configuration(valid_device_id, config_buf_data, &config_buf_size_param));
}

/*!
 * \ingroup tc_get_configuration
 * \brief Check get configuration handler
 *
 * \Description{
 *   - check get the config buffer size
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - pointer to config buffer size is pointed to zero
 *   - pointer to config buffer is NULL
 *   - there is one item size for all items defined
 *   - mock function for config_get_item_size returns ERR_SUCCESS and output the defined item size
 }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_SUCCESS
 *   - output config buffer size is equal calculated config buffer size
 * }
 *
 * \TestID{TEST_GET_CONFIGURATION_0004}
 *
 */
TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0004__GetConfigBufferSize)
{

    uint32_t config_buf_size = 0;
    // calculate expected config buffer size
    uint32_t expected_config_buf_size = (ITEM_ID_MAX - 1) * (default_item_size + CONFIG_OFFSET_PAYLOAD);

    EXPECT_CALL(*_config_mock, mock_config_get_item_size(_, _, _))
        .WillRepeatedly(DoAll(SetArgPointee<2>(default_item_size), Return(ERR_SUCCESS)));

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(ERR_SUCCESS, as7341_get_configuration(valid_device_id, NULL, &config_buf_size));

    EXPECT_EQ(expected_config_buf_size, config_buf_size);
}

/*!
 * \ingroup tc_get_configuration
 * \brief Check get configuration handler
 *
 * \Description{
 *   - check response to null pointer of config buffer
 * }
 *
 * \Preconditions{
 *   - fsm state is IDLE
 *   - pointer to config buffer size is pointed to a value greater than zero
 *   - pointer to config buffer is NULL
 }
 *
 * \Steps{
 *   - call test function with valid arguments
 * }
 *
 * \Expectations{
 *   - return code is ERR_POINTER
 * }
 *
 * \TestID{TEST_GET_CONFIGURATION_0005}
 *
 */
TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0005__NullPointerConfigBuffer)
{

    // dummies
    uint32_t config_buf_size = 2;

    g_fsm_state[0] = FSM_STATE_IDLE;

    EXPECT_EQ(ERR_POINTER, as7341_get_configuration(valid_device_id, NULL, &config_buf_size));
}

// /*!
//  * \ingroup tc_get_configuration
//  * \brief Check get configuration handler
//  *
//  * \Description{
//  *   - check response if get function succeeded for the item
//  * }
//  *
//  * \Preconditions{
//  *   - fsm state is IDLE
//  *   - define a valid item table where pointer to get item functions is valid
//  *   - this get function should return ERR_SUCCESS
//  *   - mock function for config_get_item_table returns ERR_SUCCESS
//  * }
//  *
//  * \Steps{
//  *   - call test function with valid arguments
//  * }
//  *
//  * \Expectations{
//  *   - return code is ERR_SUCCESS
//  * }
//  *
//  * \TestID{TEST_GET_CONFIGURATION_0005}
//  *
//  */
// TEST_F(GetConfiguration, TEST_GET_CONFIGURATION_0005__GetFunctionSucceeded) {

//     uint8_t item_id = 1;
//     uint8_t item_size = 2;
//     // pointer to get item function -> get_item_function
//     // because index = NO_INDEX_USED -> get_item_function returns ERR_SUCCESS
//     struct config_item_entry my_entry = {item_id, item_size, NULL, &get_item_function, NO_INDEX_USED};

//     expectConfigGetItemTable(0, &my_entry, ERR_SUCCESS);

//     uint8_t item_data[item_size] = { 0 };

//     g_fsm_state[0] = FSM_STATE_IDLE;

//     EXPECT_EQ(ERR_SUCCESS, as7341_get_configuration(valid_device_id, (enum as7341_item_ids)item_id, item_data,
//     item_size));
// }

} // namespace ChipLibUnittest
