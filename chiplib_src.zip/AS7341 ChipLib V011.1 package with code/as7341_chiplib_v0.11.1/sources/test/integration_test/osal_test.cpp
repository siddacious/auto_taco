#include <fcntl.h>

#include "spectral_osal_chiplib.h"
#include "gtest/gtest.h"

#define GPIO_TO_TEST_IRQ 6

static const osal_id_t g_osal_id{0, 0};

class osal_test : public ::testing::Test
{
  private:
    int sysfs_write_property(const char *prop, const char *val)
    {
        int ret = -1;
        int fd = -1;
        fd = open(prop, O_RDWR);

        if (fd > 0) {
            ret = write(fd, val, strlen(val));
            close(fd);
        }

        if (ret >= 0) {
            ret = 0;
        }

        return ret;
    }

    int sysfs_test_property(const char *prop)
    {
        int ret = 0;
        int fd = -1;
        fd = open(prop, O_RDONLY);
        if (fd > 0) {
            ret = 1;
        }
        return ret;
    }

  public:
    uint8_t gpio_to_test_irq;
    osal_test()
    {
        gpio_to_test_irq = GPIO_TO_TEST_IRQ;
    }

    void SetUp()
    {
    }

    void TearDown()
    {
        char prop[64];
        sprintf(prop, "/sys/class/gpio/gpio%d", gpio_to_test_irq);

        if (0 != sysfs_test_property(prop)) {
            unexportTestOutput(gpio_to_test_irq);
        }
    }

    ~osal_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }

    void exportTestOutput(uint8_t gpio_nr)
    {
        char prop[64];
        char val[8];

        sprintf(prop, "/sys/class/gpio/export");
        sprintf(val, "%d\n", gpio_nr);
        ASSERT_EQ(sysfs_write_property(prop, val), 0);

        sprintf(prop, "/sys/class/gpio/gpio%d/direction", gpio_nr);
        sprintf(val, "out\n");
        ASSERT_EQ(sysfs_write_property(prop, val), 0);
    }

    void unexportTestOutput(uint8_t gpio_nr)
    {
        char prop[64];
        char val[8];

        sprintf(prop, "/sys/class/gpio/unexport");
        sprintf(val, "%d\n", gpio_nr);
        ASSERT_EQ(sysfs_write_property(prop, val), 0);
    }

    void setGpioState(uint8_t gpio_nr, uint8_t state)
    {
        char prop[64];
        char val[8];

        sprintf(prop, "/sys/class/gpio/gpio%d/value", gpio_nr);
        sprintf(val, "%hu\n", state);
        ASSERT_EQ(sysfs_write_property(prop, val), 0);
    }
};

TEST_F(osal_test, open_close)
{
    ASSERT_EQ(spectral_osal_initialize(g_osal_id, NULL), ERR_SUCCESS);
    ASSERT_EQ(spectral_osal_shutdown(g_osal_id), ERR_SUCCESS);
}

#ifdef __linux_

TEST_F(osal_test, interrupt)
{
    uint16_t evt, payload;

    exportTestOutput(gpio_to_test_irq);

    ASSERT_EQ(spectral_osal_initialize(g_osal_id, NULL), ERR_SUCCESS);

    setGpioState(gpio_to_test_irq, 1);
    spectral_osal_wait_for_event(g_osal_id, &evt, &payload);
    ASSERT_EQ(evt, EVENT_NONE);

    setGpioState(gpio_to_test_irq, 0);
    spectral_osal_wait_for_event(g_osal_id, &evt, &payload);
    ASSERT_EQ(evt, EVENT_INTERRUPT);

    spectral_osal_wait_for_event(g_osal_id, &evt, &payload);
    ASSERT_EQ(evt, EVENT_NONE);

    ASSERT_EQ(spectral_osal_check_pending_interrupt(g_osal_id), ERR_SUCCESS);
    spectral_osal_wait_for_event(g_osal_id, &evt, &payload);
    ASSERT_EQ(evt, EVENT_INTERRUPT);

    spectral_osal_wait_for_event(g_osal_id, &evt, &payload);
    ASSERT_EQ(evt, EVENT_NONE);

    ASSERT_EQ(spectral_osal_shutdown(g_osal_id), ERR_SUCCESS);

    unexportTestOutput(gpio_to_test_irq);
}

TEST_F(osal_test, init_with_serial)
{
    ASSERT_EQ(spectral_osal_initialize(g_osal_id, "FTDI:FT1ZVYKI"), ERR_SUCCESS);
    ASSERT_EQ(spectral_osal_shutdown(g_osal_id), ERR_SUCCESS);
}

#endif