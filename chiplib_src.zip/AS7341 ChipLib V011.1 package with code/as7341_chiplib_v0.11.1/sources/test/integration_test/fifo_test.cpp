#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>

#include "as7341_chiplib.h"
#include "error_codes.h"
#include "spectral_osal_logging.h"
#include "gtest/gtest.h"

#ifdef AMS_USE_EXT_COMPONENTS
#include "css_ext_comp_cfg.h"
#include "sensor_library.h"
#endif

#define DEV_ID 0
#define MULT_MS_US 1000
#define NO_DELAY 0xFFFF

#define FLICKER_BUFFER_NUM 3000
#define MAX_MEASUREMENTS 20

static uint16_t g_count;
static uint32_t g_flicker_data_number;
static uint16_t g_flicker_buffer[FLICKER_BUFFER_NUM];
static uint8_t g_meta_data[MAX_MEASUREMENTS][30];
static uint32_t g_meta_data_size[MAX_MEASUREMENTS];
static uint8_t g_error_codes[MAX_MEASUREMENTS];

static bool g_check_callback_error = true;

static uint16_t g_delay_meas_number = 0;
static uint32_t g_meas_delay_time = 0;

#ifdef USE_RPC
extern char g_interface_description[30];
#else
static char *g_interface_description = NULL;
#endif

// put in any custom data members that you need
void fifo_callback(uint8_t device, uint8_t error, void *p_data, uint32_t data_size, void *p_items, uint32_t items_size,
                   void *p_cb_param)
{
    uint16_t copy_data_num;
    uint16_t fifo_data = 65535;
    M_UNUSED_PARAM(p_cb_param);
    M_UNUSED_PARAM(p_items);
    M_UNUSED_PARAM(items_size);

    if (g_check_callback_error) {
        ASSERT_EQ(ERR_SUCCESS, error);
    }

    if (NULL != p_data) {
        fifo_data = *(uint16_t *)p_data;
    }

    if (g_count == g_delay_meas_number) {
        usleep(g_meas_delay_time * MULT_MS_US);
    }
    printf("FIFO_CALLBACK_%d: dev: %d, error: %d, size: %d, data: %d\n", g_count, device, error, data_size, fifo_data);

    if ((FLICKER_BUFFER_NUM - g_flicker_data_number) > (data_size / sizeof(uint16_t))) {
        copy_data_num = data_size / sizeof(uint16_t);
    } else {
        copy_data_num = FLICKER_BUFFER_NUM - g_flicker_data_number;
    }
    if (g_flicker_data_number + data_size < FLICKER_BUFFER_NUM) {
        memcpy(g_flicker_buffer + g_flicker_data_number, p_data, data_size);
        g_flicker_data_number += copy_data_num;
    }

    if (MAX_MEASUREMENTS > g_count) {
        if ((NULL != p_items) && (0 < items_size)) {
            memcpy(g_meta_data[g_count], p_items, (30 < items_size) ? 30 : items_size);
            g_meta_data_size[g_count] = items_size;
        }
        g_error_codes[g_count] = error;

        g_count++;
    }
}

static float timedifference_msec(struct timeval t0, struct timeval t1)
{
    return (t1.tv_sec - t0.tv_sec) * 1000.0f + (t1.tv_usec - t0.tv_usec) / 1000.0f;
}

class fifo_test : public ::testing::Test
{
  public:
    fifo_test()
    {
        // initialization code here
    }

    void SetUp()
    {
        g_delay_meas_number = NO_DELAY;
        g_check_callback_error = true;
        // code here will execute just before the test ensues
        ASSERT_EQ(as7341_initialize(DEV_ID, fifo_callback, NULL, g_interface_description), ERR_SUCCESS);
#ifdef AMS_USE_EXT_COMPONENTS
        ASSERT_EQ(sensor_connect_external_components(DEV_ID, css_ext_components,
                                                     sizeof(css_ext_components) / sizeof(struct css_ext_type)),
                  ERR_SUCCESS);
#endif
    }

    void TearDown()
    {
        // code here will be called just after the test completes
        // ok to through exceptions from here if need be
        as7341_shutdown(DEV_ID);
    }

    ~fifo_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }
};

TEST_F(fifo_test, with_interrupt_min800values)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 1;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state && (800 > g_flicker_data_number)) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
}

TEST_F(fifo_test, with_interrupt_1000values)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 1;
    uint16_t expected_values = 1000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(expected_values, g_flicker_data_number);
}

TEST_F(fifo_test, without_interrupt)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 2000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(expected_values, g_flicker_data_number);
}

TEST_F(fifo_test, stop_after_1000)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 0;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    uint8_t only_once = 0;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);

        if (1000 < g_flicker_data_number && !only_once) {
            ASSERT_EQ(as7341_abort_measurement(DEV_ID), ERR_SUCCESS);
            only_once = 1;
        }
    }

    ASSERT_LE(1000, g_flicker_data_number);
    ASSERT_GT(1040, g_flicker_data_number);
}

#if !defined(USE_RPC) && !defined(TEST_KERNEL_DRIVER)
TEST_F(fifo_test, fifo_overflow)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 0;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    uint8_t only_once = 0;

    g_check_callback_error = false;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);

        if (1000 < g_flicker_data_number && !only_once) {
            /* create overflow */
            usleep(150 * MULT_MS_US);
            only_once = 1;
        }
    }

    ASSERT_LE(1000, g_flicker_data_number);
    ASSERT_GT(1040, g_flicker_data_number);
}
#endif

TEST_F(fifo_test, fifo_timing)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 2000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    struct timeval t0;
    struct timeval t1;
    uint16_t ftime = 179;
    float elapsed;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed = timedifference_msec(t0, t1);

    printf("elapsed time: %f, measured values: %d\n", elapsed, g_flicker_data_number);
    ASSERT_EQ(expected_values, g_flicker_data_number);
    ASSERT_LT(elapsed, 2060);
    ASSERT_GT(elapsed, 1990);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (uint8_t *)&ftime, sizeof(ftime)), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed = timedifference_msec(t0, t1);

    printf("elapsed time: %f, measured values: %d\n", elapsed, g_flicker_data_number);
    ASSERT_EQ(expected_values, g_flicker_data_number);
    ASSERT_LT(elapsed, 1060);
    ASSERT_GT(elapsed, 1000);
}

TEST_F(fifo_test, fifo_fast)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 2000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    struct timeval t0;
    struct timeval t1;
    uint16_t ftime = 179;
    float elapsed;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (uint8_t *)&ftime, sizeof(ftime)), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed = timedifference_msec(t0, t1);

    printf("ftime: %d, elapsed time: %f, measured values: %d\n", ftime, elapsed, g_flicker_data_number);
    ASSERT_EQ(expected_values, g_flicker_data_number);
    ASSERT_LT(elapsed, 1100);
    ASSERT_GT(elapsed, 1000);
}

TEST_F(fifo_test, fifo_fastest_overflow)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 2000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    uint16_t ftime = 15;

    g_check_callback_error = false;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (uint8_t *)&ftime, sizeof(ftime)), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    for (uint16_t i = 0; i < g_count - 1; i++) {
        ASSERT_EQ(g_error_codes[i], ERR_SUCCESS);
    }
    ASSERT_EQ(g_error_codes[g_count - 1], ERR_OVERFLOW);
}

#if defined(USE_RPC) || defined(TEST_KERNEL_DRIVER)
TEST_F(fifo_test, fifo_delay_callback)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 2000;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    uint16_t ftime = 20;

    g_delay_meas_number = 0;
    g_meas_delay_time = 1500;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (uint8_t *)&ftime, sizeof(ftime)), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(expected_values, g_flicker_data_number);
}
#endif

TEST_F(fifo_test, fifo_add_items)
{
    enum as7341_states state;
    uint8_t use_interrupt_pin = 0;
    uint16_t expected_values = 100;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_RESERVED};
    uint16_t i;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, &use_interrupt_pin, sizeof(use_interrupt_pin)),
              ERR_SUCCESS);

    measure_items[0] = ITEM_ID_FGAIN;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(expected_values, g_flicker_data_number);

    for (i = 0; i < g_count; i++) {
        ASSERT_EQ(1, g_meta_data_size[i]);
        ASSERT_EQ(5, g_meta_data[i][0]);
    }
}

TEST_F(fifo_test, auto_gain)
{
    enum as7341_states state;
    uint16_t expected_values = 500;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    struct as7341_auto_gain auto_gain;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_FGAIN, ITEM_ID_RESERVED};
    uint8_t gain;
    uint16_t i;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FGAIN, (void *)&gain, ITEM_SIZE_FGAIN), ERR_SUCCESS);
    ASSERT_EQ(5, gain);

    auto_gain.lower_limit = GAIN_0_5X;
    auto_gain.upper_limit = GAIN_512X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);

    g_count = 0;
    g_flicker_data_number = 0;

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(expected_values, g_flicker_data_number);

    for (i = 0; i < g_count; i++) {
        ASSERT_EQ(1, g_meta_data_size[i]);
        ASSERT_EQ(GAIN_512X, g_meta_data[i][0]);
    }
}

TEST_F(fifo_test, auto_gain_saturation)
{
    enum as7341_states state;
    uint16_t expected_values = 500;
    uint8_t measurement_type = MEASUREMENT_TYPE_FIFO;
    struct as7341_auto_gain auto_gain;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_FGAIN, ITEM_ID_RESERVED};
    uint8_t gain;
    struct as7341_led_config expected_led;

    g_check_callback_error = false;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_TYPE, &measurement_type, ITEM_SIZE_MEAS_TYPE), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&expected_values, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    gain = GAIN_256X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FGAIN, (void *)&gain, ITEM_SIZE_FGAIN), ERR_SUCCESS);

    auto_gain.lower_limit = GAIN_128X;
    auto_gain.upper_limit = GAIN_512X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);

    expected_led.enable = 1;
    expected_led.brightness = 800;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&expected_led, ITEM_SIZE_LED_EXT_1), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);

    usleep(200 * MULT_MS_US);

    g_count = 0;
    g_flicker_data_number = 0;

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(0, g_flicker_data_number);

    ASSERT_EQ(ERR_SATURATION, g_error_codes[0]);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FGAIN, (void *)&gain, ITEM_SIZE_FGAIN), ERR_SUCCESS);
    ASSERT_EQ(GAIN_128X, gain);
}
