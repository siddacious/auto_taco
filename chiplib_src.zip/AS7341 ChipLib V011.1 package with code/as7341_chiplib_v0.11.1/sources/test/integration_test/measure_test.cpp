#include "as7341_chiplib.h"
#include "error_codes.h"
#include "spectral_osal_logging.h"
#include "gtest/gtest.h"
#include <stdio.h>
#include <sys/time.h>
#ifdef USE_RPC
#include "as7341_chiplib_rpc.h"
#endif

#ifdef AMS_USE_EXT_COMPONENTS
#include "css_ext_comp_cfg.h"
#include "sensor_library.h"
#endif

#define DEV_ID 0

#define MAX_MEASUREMENTS 20
#define MAX_CHANNELS 12
static uint16_t g_count;
static uint8_t g_errors[MAX_MEASUREMENTS];
static uint16_t g_channels[MAX_MEASUREMENTS][MAX_CHANNELS];
static uint8_t g_meta_data[MAX_MEASUREMENTS][AS7341_MAX_ITEM_BUFFER_SIZE];
static uint32_t g_meta_data_size[MAX_MEASUREMENTS];

#ifdef USE_RPC
extern char g_interface_description[30];
#else
static char *g_interface_description = NULL;
#endif

static uint32_t m_expected_measurement_data_size = 0;

void print_measured_values(const osal_id_t osal_id, uint16_t id, uint16_t *p_values, uint8_t number, uint8_t *p_items,
                           uint32_t item_size)
{
    uint8_t i;
    char string_buffer[500];
    int buffer_pointer = 0;
    buffer_pointer += sprintf(string_buffer, "OSAL_%d, ID:%3d: ", osal_id.dev, id);
    for (i = 0; i < number; i++) {
        buffer_pointer += sprintf(string_buffer + buffer_pointer, "%d\t", p_values[i]);
    }
    buffer_pointer += sprintf(string_buffer + buffer_pointer, "ITEM_BUF: ");
    for (i = 0; i < item_size; i++) {
        buffer_pointer += sprintf(string_buffer + buffer_pointer, "%02X ", p_items[i]);
    }
    log_info(osal_id, "T_M", "Index: %d, %s", id, string_buffer);
}

// put in any custom data members that you need
static void measurement_callback(uint8_t device, uint8_t error, void *p_data, uint32_t data_size, void *p_items,
                                 uint32_t items_size, void *p_cb_param)
{
    const osal_id_t osal_id = {CHIP_LIB_IDENT, device};

    ASSERT_EQ(0xAABBCCDD, *(uint32_t *)p_cb_param);

    if (MAX_MEASUREMENTS > g_count) {
        if ((NULL != p_items) && (0 < items_size)) {
            memcpy(g_meta_data[g_count], p_items,
                   (AS7341_MAX_ITEM_BUFFER_SIZE < items_size) ? AS7341_MAX_ITEM_BUFFER_SIZE : items_size);
            g_meta_data_size[g_count] = items_size;
        }
        if ((NULL != p_data) && (0 < data_size)) {
            memcpy(g_channels[g_count], p_data, data_size);
        }
        print_measured_values(osal_id, g_count, (uint16_t *)p_data, data_size / sizeof(uint16_t), (uint8_t *)p_items,
                              items_size);
        g_errors[g_count] = error;
    }

    g_count++;

    ASSERT_EQ(m_expected_measurement_data_size, data_size);
}

static float timedifference_msec(struct timeval t0, struct timeval t1)
{
    return (t1.tv_sec - t0.tv_sec) * 1000.0f + (t1.tv_usec - t0.tv_usec) / 1000.0f;
}

class measure_test : public ::testing::Test
{
  private:
    const uint32_t context = 0xAABBCCDD;

  public:
    measure_test()
    {
        // initialization code here
    }

    void SetUp()
    {
        memset(g_errors, 0, sizeof(g_errors));
        memset(g_channels, 0, sizeof(g_channels));
        memset(g_meta_data, 0, sizeof(g_meta_data));
        memset(g_meta_data_size, 0, sizeof(g_meta_data_size));

        g_count = 0;
        m_expected_measurement_data_size = 24;
        // code here will execute just before the test ensues
        ASSERT_EQ(as7341_initialize(DEV_ID, measurement_callback, &context, g_interface_description), ERR_SUCCESS);
#ifdef AMS_USE_EXT_COMPONENTS
        ASSERT_EQ(sensor_connect_external_components(DEV_ID, css_ext_components,
                                                     sizeof(css_ext_components) / sizeof(struct css_ext_type)),
                  ERR_SUCCESS);
#endif
    }

    void TearDown()
    {
        // code here will be called just after the test completes
        // ok to through exceptions from here if need be
        as7341_shutdown(DEV_ID);
    }

    ~measure_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }
};

TEST_F(measure_test, single_measurement)
{
    enum as7341_states state;
    uint16_t exceptect_count = 1;

    m_expected_measurement_data_size = 24;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    g_count = 0;

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(exceptect_count, g_count);
}

TEST_F(measure_test, multi_measurement)
{
    enum as7341_states state;
    uint16_t exceptect_count = 5;

    g_count = 0;
    m_expected_measurement_data_size = 24;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);

    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(exceptect_count, g_count);
}

TEST_F(measure_test, autozero_timing_all_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 10;
    struct timeval t0;
    struct timeval t1;
    float elapsed[4];
    uint32_t i;
    uint8_t autozero;
    const float autozero_offset = 15;
    float uncertainty = 0.9;

    m_expected_measurement_data_size = 24;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    for (i = 0; i < 4; i++) {
        switch (i) {
        case 0:
            autozero = 0;
            break;
        case 1:
            autozero = 1;
            break;
        case 2:
            autozero = 2;
            break;
        case 3:
            autozero = 255;
            break;
        default:
            ASSERT_FALSE(1);
            break;
        }
        ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTOZERO, &autozero, ITEM_SIZE_AUTOZERO), ERR_SUCCESS);

        g_count = 0;
        ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
        gettimeofday(&t0, 0);
        state = STATE_MEASURE;
        while (STATE_MEASURE == state) {
            ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        }
        gettimeofday(&t1, 0);
        elapsed[i] = timedifference_msec(t0, t1);
        ASSERT_EQ(exceptect_count, g_count);
    }

    // ASSERT_GT(elapsed[3], elapsed[0]); // Can't be measured
    ASSERT_GT(elapsed[1], elapsed[0] + (exceptect_count * autozero_offset * uncertainty));
    ASSERT_GT(elapsed[2], elapsed[0] + (exceptect_count * autozero_offset / 2 * uncertainty));
    ASSERT_GT(elapsed[1], elapsed[2]);
}

TEST_F(measure_test, autozero_timing_six_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 10;
    struct timeval t0;
    struct timeval t1;
    float elapsed[4];
    uint32_t i;
    uint8_t autozero;
    const float autozero_offset = 15;
    float uncertainty = 0.6;

    m_expected_measurement_data_size = 12;

    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,       CHANNEL_F2,       CHANNEL_F3,       CHANNEL_F4,
                                        CHANNEL_F5,       CHANNEL_F6,       CHANNEL_DISABLED, CHANNEL_DISABLED,
                                        CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    for (i = 0; i < 4; i++) {
        switch (i) {
        case 0:
            autozero = 0;
            break;
        case 1:
            autozero = 1;
            break;
        case 2:
            autozero = 2;
            break;
        case 3:
            autozero = 255;
            break;
        default:
            ASSERT_FALSE(1);
            break;
        }
        ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTOZERO, &autozero, ITEM_SIZE_AUTOZERO), ERR_SUCCESS);

        g_count = 0;
        ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
        gettimeofday(&t0, 0);
        state = STATE_MEASURE;
        while (STATE_MEASURE == state) {
            ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        }
        gettimeofday(&t1, 0);
        elapsed[i] = timedifference_msec(t0, t1);
        ASSERT_EQ(exceptect_count, g_count);
    }

    // ASSERT_GT(elapsed[3], elapsed[0]); // Can't be measured
    ASSERT_GT(elapsed[1], elapsed[0] + (exceptect_count * autozero_offset * uncertainty));
    ASSERT_GT(elapsed[2], elapsed[0] + (exceptect_count * autozero_offset / 2 * uncertainty));
    ASSERT_GT(elapsed[1], elapsed[2]);
}

TEST_F(measure_test, single_measurement_six_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 1;

    struct timeval t0;
    struct timeval t1;
    float elapsed12, elapsed6;
    uint8_t atime = 255;

    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,       CHANNEL_F2,       CHANNEL_F3,       CHANNEL_F4,
                                        CHANNEL_F5,       CHANNEL_F6,       CHANNEL_DISABLED, CHANNEL_DISABLED,
                                        CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, &atime, ITEM_SIZE_ATIME), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    /* measurement with 12 channels */
    m_expected_measurement_data_size = 24;
    gettimeofday(&t0, 0);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed12 = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    /* measurement with 6 channels */
    m_expected_measurement_data_size = 12;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);
    gettimeofday(&t0, 0);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed6 = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    ASSERT_GT(elapsed12, (elapsed6 * 2) * 0.9);
    ASSERT_LT(elapsed12, (elapsed6 * 2) * 1.1);
}

TEST_F(measure_test, led_pattern_all_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};
    uint16_t i, j;
    const uint16_t led_threshold = 3000;

    m_expected_measurement_data_size = 24;

    led_pattern[0].config = LED_MASK_OFF;
    led_pattern[0].count = 2;
    led_pattern[1].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[1].count = 3;
    led_pattern[2].config = LED_MASK_INTERN;
    led_pattern[2].count = 4;
    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 5;
    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_2;
    led_pattern[4].count = 2;
    led_pattern[5].config = LED_MASK_OFF;
    led_pattern[5].count = 0;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    /* values with LED0 enabled are in saturation */
    uint16_t max_values[MAX_MEASUREMENTS]{led_threshold,    led_threshold, AS7341_SATURATED, AS7341_SATURATED,
                                          AS7341_SATURATED, led_threshold, led_threshold,    led_threshold,
                                          led_threshold,    led_threshold, led_threshold,    led_threshold,
                                          led_threshold,    led_threshold, AS7341_SATURATED, AS7341_SATURATED,
                                          led_threshold,    led_threshold, led_threshold,    led_threshold};
    for (i = 0; i < MAX_MEASUREMENTS; i++) {
        for (j = 0; j < MAX_CHANNELS; j++) {
            ASSERT_GE(max_values[i], g_channels[i][j]);
        }
    }
}

TEST_F(measure_test, led_pattern_six_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = MAX_MEASUREMENTS;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};
    uint16_t i, j;
    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,       CHANNEL_F2,       CHANNEL_F3,       CHANNEL_F4,
                                        CHANNEL_F5,       CHANNEL_F6,       CHANNEL_DISABLED, CHANNEL_DISABLED,
                                        CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};

    m_expected_measurement_data_size = 12;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);

    led_pattern[0].config = LED_MASK_OFF;
    led_pattern[0].count = 2;

    led_pattern[1].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[1].count = 3;

    led_pattern[2].config = LED_MASK_INTERN;
    led_pattern[2].count = 4;

    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 5;

    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_2;
    led_pattern[4].count = 2;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    /* values with LED0 enabled are in saturation */
    uint16_t max_values[MAX_MEASUREMENTS]{500,
                                          500,
                                          AS7341_SATURATED,
                                          AS7341_SATURATED,
                                          AS7341_SATURATED,
                                          500,
                                          500,
                                          500,
                                          500,
                                          500,
                                          500,
                                          500,
                                          500,
                                          500,
                                          AS7341_SATURATED,
                                          AS7341_SATURATED,
                                          500,
                                          500,
                                          500,
                                          500};
    for (i = 0; i < MAX_MEASUREMENTS; i++) {
        for (j = 0; j < MAX_CHANNELS; j++) {
            if (8 > j) {
                ASSERT_GE(max_values[i], g_channels[i][j]);
            } else {
                ASSERT_EQ(0, g_channels[i][j]);
            }
        }
    }
}

TEST_F(measure_test, measure_items)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};
    uint16_t i;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_RESERVED};

    m_expected_measurement_data_size = 24;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    led_pattern[0].config = LED_MASK_OFF;
    led_pattern[0].count = 2;
    led_pattern[1].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[1].count = 3;
    led_pattern[2].config = LED_MASK_INTERN;
    led_pattern[2].count = 4;
    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 5;
    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_2;
    led_pattern[4].count = 2;
    led_pattern[5].config = LED_MASK_OFF;
    led_pattern[5].count = 0;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    measure_items[0] = ITEM_ID_LED_INTERN;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    for (i = 0; i < exceptect_count; i++) {
        ASSERT_EQ(ITEM_SIZE_LED_INTERN, g_meta_data_size[i]);
        if (i >= 2 && i < 5) {
            ASSERT_EQ(LED_MASK_INTERN, g_meta_data[i][0]);
        } else if (i >= 5 && i < 9) {
            ASSERT_EQ(LED_MASK_INTERN, g_meta_data[i][0]);
        } else if (i >= 14 && i <= 15) {
            ASSERT_EQ(LED_MASK_INTERN, g_meta_data[i][0]);
        } else {
            ASSERT_EQ(LED_MASK_OFF, g_meta_data[i][0]);
        }
        ASSERT_EQ(100, g_meta_data[i][2]);
    }
}

TEST_F(measure_test, break_time)
{
    enum as7341_states state;
    uint16_t exceptect_count = 5;
    struct timeval t0;
    struct timeval t1;
    float elapsed[4];
    uint32_t break_time, break_time_actual;
    uint8_t autozero = 0;
    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,       CHANNEL_F2,       CHANNEL_F3,       CHANNEL_F4,
                                        CHANNEL_F5,       CHANNEL_F6,       CHANNEL_DISABLED, CHANNEL_DISABLED,
                                        CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};
    uint8_t int_pin = 1;
    uint32_t min, max, diff;

    m_expected_measurement_data_size = 24;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (void *)&exceptect_count, ITEM_SIZE_MEAS_COUNT), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_INTERRUPT_PIN, (void *)&int_pin, ITEM_SIZE_INTERRUPT_PIN), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTOZERO, &autozero, ITEM_SIZE_AUTOZERO), ERR_SUCCESS);

    /* 12 channels: first measurement without break time */
    g_count = 0;
    break_time = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed[0] = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    /* 12 channels: second measurement with break time */
    g_count = 0;
    break_time = 10000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time_actual, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed[1] = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    /* configure 6 channels */
    m_expected_measurement_data_size = 12;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);

    /* 6 channels: first measurement without break time */
    g_count = 0;
    break_time = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed[2] = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    /* 6 channels: second measurement with break time */
    g_count = 0;
    break_time = 10000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    gettimeofday(&t0, 0);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    gettimeofday(&t1, 0);
    elapsed[3] = timedifference_msec(t0, t1);
    ASSERT_EQ(exceptect_count, g_count);

    min = (exceptect_count - 1) * break_time_actual / 1000 * 5 / 10;
    max = (exceptect_count - 1) * break_time_actual / 1000 * 18 / 10;

    diff = elapsed[1] - elapsed[0];
    printf("12 channels - diff: %d (min: %d - max: %d)\n", diff, min, max);
    ASSERT_GT(diff, min);
    ASSERT_LT(diff, max);

    diff = elapsed[3] - elapsed[2];
    printf("6 channels - diff: %d (min: %d - max: %d)\n", diff, min, max);
    ASSERT_GT(diff, min);
    ASSERT_LT(diff, max);
}

TEST_F(measure_test, single_measurement_with_large_item_buffer)
{
    enum as7341_states state;
    uint16_t exceptect_count = 1;
    uint16_t i;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_LED_PATTERN, ITEM_ID_CHANNELS, ITEM_ID_MEASURE_ITEMS,
                                                      ITEM_ID_SERIAL, ITEM_ID_RESERVED};

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    /* 50byte measure items */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    for (i = 0; i < exceptect_count; i++) {
        ASSERT_EQ(50, g_meta_data_size[i]);
    }

    /* 80byte measure items */
    g_meta_data_size[0] = 0;
    measure_items[0] = ITEM_ID_LED_PATTERN;
    measure_items[1] = ITEM_ID_LED_PATTERN;
    measure_items[2] = ITEM_ID_LED_PATTERN;
    measure_items[3] = ITEM_ID_LED_PATTERN;
    measure_items[4] = ITEM_ID_RESERVED;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    for (i = 0; i < exceptect_count; i++) {
        ASSERT_EQ(80, g_meta_data_size[i]);
    }

    m_expected_measurement_data_size = 0;

    /* 81byte measure items */
    g_meta_data_size[0] = 0;
    measure_items[0] = ITEM_ID_LED_PATTERN;
    measure_items[1] = ITEM_ID_LED_PATTERN;
    measure_items[2] = ITEM_ID_LED_PATTERN;
    measure_items[3] = ITEM_ID_LED_PATTERN;
    measure_items[4] = ITEM_ID_AGAIN;
    measure_items[5] = ITEM_ID_RESERVED;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);
    ASSERT_EQ(0, g_meta_data_size[0]);
    ASSERT_EQ(ERR_SIZE, g_errors[0]);
}

TEST_F(measure_test, measure_auto_gain)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    uint16_t i;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_AGAIN, ITEM_ID_TIMESTAMP, ITEM_ID_RESERVED};
    struct as7341_auto_gain auto_gain;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};
    uint8_t gain;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    led_pattern[0].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[0].count = 2;
    led_pattern[1].config = LED_MASK_OFF;
    led_pattern[1].count = 2;
    led_pattern[2].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[2].count = 2;
    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 2;
    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[4].count = 2;
    led_pattern[5].config = LED_MASK_OFF;
    led_pattern[5].count = 2;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    auto_gain.lower_limit = GAIN_0_5X;
    auto_gain.upper_limit = GAIN_512X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);

    g_count = 0;
    state = STATE_MEASURE;
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    for (i = 0; i < exceptect_count; i++) {
        ASSERT_EQ(9, g_meta_data_size[i]);
    }

    for (i = 0; i < 12; i += 2) {
        if (0 == (i % 4)) {
            ASSERT_GE(5, g_meta_data[i][0]);
            ASSERT_GE(5, g_meta_data[i + 1][0]);
            gain = g_meta_data[i + 1][0];
        } else {
            ASSERT_EQ(gain, g_meta_data[i][0]);
            ASSERT_EQ(GAIN_512X, g_meta_data[i + 1][0]);
        }
    }

    for (i = 12; i < exceptect_count; i++) {
        ASSERT_EQ(GAIN_512X, g_meta_data[i][0]);
    }
}

TEST_F(measure_test, measure_auto_gain_lower_limited)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_AGAIN, ITEM_ID_TIMESTAMP, ITEM_ID_RESERVED};
    struct as7341_auto_gain auto_gain;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};

    m_expected_measurement_data_size = 0;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    led_pattern[0].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[0].count = 2;
    led_pattern[1].config = LED_MASK_OFF;
    led_pattern[1].count = 2;
    led_pattern[2].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[2].count = 2;
    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 2;
    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[4].count = 2;
    led_pattern[5].config = LED_MASK_OFF;
    led_pattern[5].count = 2;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    auto_gain.lower_limit = GAIN_4X;
    auto_gain.upper_limit = GAIN_512X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);

    g_count = 0;
    state = STATE_MEASURE;
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(1, g_count);

    ASSERT_EQ(ERR_SATURATION, g_errors[0]);
}

TEST_F(measure_test, measure_auto_gain_upper_limited)
{
    enum as7341_states state;
    uint16_t exceptect_count = 20;
    uint16_t i;
    uint8_t measure_items[ITEM_SIZE_MEASURE_ITEMS] = {ITEM_ID_AGAIN, ITEM_ID_TIMESTAMP, ITEM_ID_RESERVED};
    struct as7341_auto_gain auto_gain;
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM] = {};
    uint8_t gain;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEASURE_ITEMS, measure_items, ITEM_SIZE_MEASURE_ITEMS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    led_pattern[0].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[0].count = 2;
    led_pattern[1].config = LED_MASK_OFF;
    led_pattern[1].count = 2;
    led_pattern[2].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[2].count = 2;
    led_pattern[3].config = LED_MASK_OFF;
    led_pattern[3].count = 2;
    led_pattern[4].config = LED_MASK_INTERN | LED_MASK_EXT_1;
    led_pattern[4].count = 2;
    led_pattern[5].config = LED_MASK_OFF;
    led_pattern[5].count = 2;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (uint8_t *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    auto_gain.lower_limit = GAIN_0_5X;
    auto_gain.upper_limit = GAIN_128X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);

    g_count = 0;
    state = STATE_MEASURE;
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }
    ASSERT_EQ(exceptect_count, g_count);

    for (i = 0; i < exceptect_count; i++) {
        ASSERT_EQ(9, g_meta_data_size[i]);
    }

    for (i = 0; i < 12; i += 2) {
        if (0 == (i % 4)) {
            ASSERT_GE(5, g_meta_data[i][0]);
            ASSERT_GE(5, g_meta_data[i + 1][0]);
            gain = g_meta_data[i + 1][0];
        } else {
            ASSERT_EQ(gain, g_meta_data[i][0]);
            ASSERT_EQ(GAIN_128X, g_meta_data[i + 1][0]);
        }
    }

    for (i = 12; i < exceptect_count; i++) {
        ASSERT_EQ(GAIN_128X, g_meta_data[i][0]);
    }
}

TEST_F(measure_test, gain_factors)
{
    enum as7341_states state;
    uint16_t exceptect_count = 1;
    struct as7341_led_config expected_led;
    uint16_t gain_factors[AS7341_GAIN_FACTOR_NUM];
    uint8_t expected_again;

    m_expected_measurement_data_size = 24;

    expected_led.enable = 1;
    expected_led.brightness = 100;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&expected_led, ITEM_SIZE_LED_EXT_1), ERR_SUCCESS);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)gain_factors, ITEM_SIZE_GAIN_FACTORS), ERR_SUCCESS);
    gain_factors[GAIN_16X] = 20000;
    gain_factors[GAIN_32X] = 10000;
    gain_factors[GAIN_64X] = 5000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)gain_factors, ITEM_SIZE_GAIN_FACTORS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    g_count = 0;

    /* measurement 1 */
    expected_again = GAIN_16X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    /* measurement 2 */
    expected_again = GAIN_32X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    /* measurement 3 */
    expected_again = GAIN_64X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_SUCCESS);

    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    state = STATE_MEASURE;
    while (STATE_MEASURE == state) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
    }

    ASSERT_EQ(3, g_count);

    ASSERT_GT(g_channels[1][0], g_channels[0][0] * 0.9);
    ASSERT_LT(g_channels[1][0], g_channels[0][0] * 1.1);

    ASSERT_GT(g_channels[2][0], g_channels[0][0] * 0.9);
    ASSERT_LT(g_channels[2][0], g_channels[0][0] * 1.1);
}

#ifdef USE_RPC
TEST_F(measure_test, sync_six_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 10;

    struct timeval t0;
    struct timeval t1;
    float elapsed;
    uint8_t enable = true;

    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,       CHANNEL_F2,       CHANNEL_F3,       CHANNEL_F4,
                                        CHANNEL_F5,       CHANNEL_F6,       CHANNEL_DISABLED, CHANNEL_DISABLED,
                                        CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED, CHANNEL_DISABLED};

    /* configuration of unicom sync pin */
    ASSERT_EQ(as7341_set_sync(0), ERR_SUCCESS);

    m_expected_measurement_data_size = 12;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, &enable, ITEM_SIZE_SYNC_MODE), ERR_SUCCESS);

    gettimeofday(&t0, 0);
    elapsed = 0;
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state && (500 > elapsed)) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        gettimeofday(&t1, 0);
        elapsed = timedifference_msec(t0, t1);
    }

    ASSERT_EQ(STATE_MEASURE, state);
    ASSERT_GT(elapsed, 500);
    ASSERT_EQ(g_count, 0);

    ASSERT_EQ(as7341_set_sync(100000), ERR_SUCCESS);

    gettimeofday(&t0, 0);
    elapsed = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state && (1500 > elapsed)) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        gettimeofday(&t1, 0);
        elapsed = timedifference_msec(t0, t1);
    }

    ASSERT_EQ(STATE_CONFIG, state);
    ASSERT_LT(elapsed, 1200);
    ASSERT_GT(elapsed, 900);
    ASSERT_EQ(g_count, 10);
}

TEST_F(measure_test, sync_twelve_channels)
{
    enum as7341_states state;
    uint16_t exceptect_count = 10;

    struct timeval t0;
    struct timeval t1;
    float elapsed;
    uint8_t enable = true;

    /* configuration of unicom sync pin */
    ASSERT_EQ(as7341_set_sync(0), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_MEAS_COUNT, (uint8_t *)&exceptect_count, ITEM_SIZE_MEAS_COUNT),
              ERR_SUCCESS);

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, &enable, ITEM_SIZE_SYNC_MODE), ERR_SUCCESS);

    gettimeofday(&t0, 0);
    elapsed = 0;
    ASSERT_EQ(as7341_start_measurement(DEV_ID), ERR_SUCCESS);
    g_count = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state && (500 > elapsed)) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        gettimeofday(&t1, 0);
        elapsed = timedifference_msec(t0, t1);
    }

    ASSERT_EQ(STATE_MEASURE, state);
    ASSERT_GT(elapsed, 500);
    ASSERT_EQ(g_count, 0);

    ASSERT_EQ(as7341_set_sync(100000), ERR_SUCCESS);

    gettimeofday(&t0, 0);
    elapsed = 0;
    state = STATE_MEASURE;
    while (STATE_MEASURE == state && (2500 > elapsed)) {
        ASSERT_EQ(as7341_execute_state_machine(DEV_ID, &state), ERR_SUCCESS);
        gettimeofday(&t1, 0);
        elapsed = timedifference_msec(t0, t1);
    }

    ASSERT_EQ(STATE_CONFIG, state);
    ASSERT_LT(elapsed, 2200);
    ASSERT_GT(elapsed, 1900);
    ASSERT_EQ(g_count, 10);
}
#endif