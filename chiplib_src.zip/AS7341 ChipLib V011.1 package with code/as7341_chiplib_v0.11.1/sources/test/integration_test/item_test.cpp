#include <string.h>
#include <unistd.h>

#include "as7341_chiplib.h"
#include "error_codes.h"
#include "gtest/gtest.h"

#ifdef AMS_USE_EXT_COMPONENTS
#include "css_ext_comp_cfg.h"
#include "sensor_library.h"
#endif

#define DEV_ID 0
#define MULT_MS_US 1000

#ifdef USE_RPC
extern char g_interface_description[30];
#else
static char *g_interface_description = NULL;
#endif

void measurement_callback(uint8_t device, uint8_t error, void *p_data, uint32_t data_size, void *p_items,
                          uint32_t items_size, void *p_cb_param)
{
    M_UNUSED_PARAM(p_data);
    M_UNUSED_PARAM(p_items);
    M_UNUSED_PARAM(p_cb_param);
    printf("CALLBACK: dev: %d, error: %d, data size: %d, item_size: %d", device, error, data_size, items_size);
}

class item_test : public ::testing::Test
{
  public:
    item_test()
    {
        // initialization code here
    }

    void SetUp()
    {
        // code here will execute just before the test ensues
        ASSERT_EQ(as7341_initialize(DEV_ID, measurement_callback, NULL, g_interface_description), ERR_SUCCESS);
#ifdef AMS_USE_EXT_COMPONENTS
        ASSERT_EQ(sensor_connect_external_components(DEV_ID, css_ext_components,
                                                     sizeof(css_ext_components) / sizeof(struct css_ext_type)),
                  ERR_SUCCESS);
#endif
    }

    void TearDown()
    {
        // code here will be called just after the test completes
        // ok to through exceptions from here if need be
        ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    }

    ~item_test()
    {
        // cleanup any pending stuff, but no exceptions allowed
    }

    // put in any custom data members that you need
};

TEST_F(item_test, parameter_ASTEP)
{
    uint16_t astep, expected_astep;

    expected_astep = 555;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(expected_astep, astep);

    expected_astep = 65535;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, ITEM_SIZE_ASTEP), ERR_ARGUMENT);

    expected_astep = 65534;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(expected_astep, astep);

    expected_astep = 0xAEEA;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(expected_astep, astep);

    /* test wrong item size */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, 0), ERR_SIZE);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&expected_astep, 0), ERR_SIZE);

    /* test null-pointer */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ASTEP, NULL, ITEM_SIZE_ASTEP), ERR_POINTER);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, NULL, ITEM_SIZE_ASTEP), ERR_POINTER);
}

TEST_F(item_test, parameter_ATIME)
{
    uint8_t atime, expected_atime;

    expected_atime = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, (void *)&expected_atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(expected_atime, atime);

    expected_atime = 0xAE;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, (void *)&expected_atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(expected_atime, atime);

    expected_atime = 255;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, (void *)&expected_atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(expected_atime, atime);

    /* test wrong item size */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, (void *)&expected_atime, 0), ERR_SIZE);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&expected_atime, 0), ERR_SIZE);

    /* test null-pointer */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ATIME, NULL, ITEM_SIZE_ATIME), ERR_POINTER);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, NULL, ITEM_SIZE_ATIME), ERR_POINTER);
}

TEST_F(item_test, parameter_ITIME)
{
    uint32_t itime, expected_itime;
    uint8_t atime, expected_atime;
    uint16_t astep, expected_astep;

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(50000, itime);

    expected_itime = 33333;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    expected_itime = 33333;
    ASSERT_EQ(expected_itime, itime);

    expected_atime = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(expected_atime, atime);

    expected_astep = 11999;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(expected_astep, astep);

    /* second test */
    expected_itime = 11111111;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    expected_itime = 11111150;
    ASSERT_EQ(expected_itime, itime);

    expected_atime = 121;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(expected_atime, atime);

    expected_astep = 32786;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(expected_astep, astep);

    expected_itime = 6;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(expected_itime, itime);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(1, astep);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(0, atime);

    expected_itime = 5;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_ARGUMENT);

    expected_itime = 46602667;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ITIME, (void *)&itime, ITEM_SIZE_ITIME), ERR_SUCCESS);
    ASSERT_EQ(expected_itime, itime);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ASTEP, (void *)&astep, ITEM_SIZE_ASTEP), ERR_SUCCESS);
    ASSERT_EQ(65534, astep);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_ATIME, (void *)&atime, ITEM_SIZE_ATIME), ERR_SUCCESS);
    ASSERT_EQ(255, atime);

    expected_itime = 46602668;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_ITIME, (void *)&expected_itime, ITEM_SIZE_ITIME), ERR_ARGUMENT);
}

TEST_F(item_test, parameter_AGAIN)
{
    uint8_t again, expected_again;

    expected_again = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_AGAIN, (void *)&again, ITEM_SIZE_AGAIN), ERR_SUCCESS);
    ASSERT_EQ(expected_again, again);

    expected_again = 10;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_AGAIN, (void *)&again, ITEM_SIZE_AGAIN), ERR_SUCCESS);
    ASSERT_EQ(expected_again, again);

    expected_again = 11;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, ITEM_SIZE_AGAIN), ERR_ARGUMENT);

    /* test wrong item size */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, 0), ERR_SIZE);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_AGAIN, (void *)&expected_again, 0), ERR_SIZE);

    /* test null-pointer */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AGAIN, NULL, ITEM_SIZE_AGAIN), ERR_POINTER);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_AGAIN, NULL, ITEM_SIZE_AGAIN), ERR_POINTER);
}

TEST_F(item_test, parameter_BREAK)
{
    uint32_t break_time, expected_break_time;

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(0, break_time);

    /* set invalid values */
    break_time = 1;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_ARGUMENT);
    break_time = 2779;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_ARGUMENT);

    expected_break_time = 2780;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&expected_break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(expected_break_time, break_time);

    expected_break_time = 50000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&expected_break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(expected_break_time, break_time);

    break_time = 50001;
    expected_break_time = 50000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(expected_break_time, break_time);

    expected_break_time = 794430;
    break_time = 800000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(expected_break_time, break_time);

    expected_break_time = 9994430;
    break_time = 10000000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_SUCCESS);
    ASSERT_EQ(expected_break_time, break_time);

    /* set first invalid value */
    break_time = 10000001;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, ITEM_SIZE_BREAK), ERR_ARGUMENT);

    /* test wrong item size */
    expected_break_time = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, (void *)&expected_break_time, 0), ERR_SIZE);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, (void *)&break_time, 0), ERR_SIZE);

    /* test null-pointer */
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_BREAK, NULL, ITEM_SIZE_BREAK), ERR_POINTER);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_BREAK, NULL, ITEM_SIZE_BREAK), ERR_POINTER);
}

TEST_F(item_test, parameter_CHANNEL)
{
    uint8_t channels[CHANNEL_NUMBER] = {CHANNEL_F1,    CHANNEL_F2,       CHANNEL_F3,  CHANNEL_F4,
                                        CHANNEL_F5,    CHANNEL_F6,       CHANNEL_F7,  CHANNEL_F8,
                                        CHANNEL_CLEAR, CHANNEL_DISABLED, CHANNEL_NIR, CHANNEL_FLICKER};

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_CHANNELS, channels, ITEM_SIZE_CHANNELS), ERR_SUCCESS);
}

TEST_F(item_test, parameter_VERSION)
{
    struct as7341_version version;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_VERSION, (void *)&version, ITEM_SIZE_VERSION), ERR_NOT_SUPPORTED);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_VERSION, (void *)&version, ITEM_SIZE_VERSION), ERR_SUCCESS);
    ASSERT_EQ(version.major, 0);
    ASSERT_EQ(version.minor, 11);
    ASSERT_EQ(version.patch, 1);
    ASSERT_EQ(version.build, 0);
}

TEST_F(item_test, parameter_SERIAL)
{
    struct as7341_serial serial;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SERIAL, (void *)&serial, ITEM_SIZE_SERIAL), ERR_NOT_SUPPORTED);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_SERIAL, (void *)&serial, ITEM_SIZE_SERIAL), ERR_SUCCESS);
    ASSERT_GT(serial.timestamp, 1451606400); /* value must be higher than unix code timestamp 1.01.2016 */
    ASSERT_GE(serial.id, 0);
    ASSERT_LE(serial.id, 1);
}

TEST_F(item_test, parameter_LED_PATTERN)
{
    struct as7341_led_pattern led_pattern[AS7341_LED_PATTERN_NUM];

    memset(led_pattern, 0, sizeof(led_pattern));

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_LED_PATTERN, (void *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    for (uint32_t i = 0; i < AS7341_LED_PATTERN_NUM; i++) {
        ASSERT_FALSE(0 != led_pattern[i].count || 0 != led_pattern[i].config);

        /* set values for LED pattern */
        led_pattern[i].count = i;
        led_pattern[i].config = i;
    }

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_PATTERN, (void *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);

    /* reinitialize library */
    ASSERT_EQ(as7341_shutdown(DEV_ID), ERR_SUCCESS);
    ASSERT_EQ(as7341_initialize(DEV_ID, measurement_callback, NULL, g_interface_description), ERR_SUCCESS);

    /* check if data are reset again */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_LED_PATTERN, (void *)led_pattern, ITEM_SIZE_LED_PATTERN), ERR_SUCCESS);
    for (uint32_t i = 0; i < AS7341_LED_PATTERN_NUM; i++) {
        ASSERT_FALSE(0 != led_pattern[i].count || 0 != led_pattern[i].config);
    }
}

TEST_F(item_test, parameter_LED)
{
    struct as7341_led_config led_config;
    struct as7341_led_config expected_led;

    expected_led.enable = 0;
    expected_led.brightness = 1000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, sizeof(struct as7341_led_config)),
              ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&led_config, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);
    ASSERT_EQ(expected_led.enable, led_config.enable);
    ASSERT_EQ(expected_led.brightness, led_config.brightness);

    expected_led.enable = 1;
    expected_led.brightness = 50;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&led_config, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);
    ASSERT_EQ(expected_led.enable, led_config.enable);
    ASSERT_EQ(expected_led.brightness, led_config.brightness);

    expected_led.enable = 1;
    expected_led.brightness = 500;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&led_config, ITEM_SIZE_LED_INTERN), ERR_SUCCESS);
    ASSERT_EQ(expected_led.enable, led_config.enable);
    ASSERT_EQ(expected_led.brightness, led_config.brightness);

    expected_led.brightness = 1500;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_INTERN, (void *)&expected_led, ITEM_SIZE_LED_INTERN), ERR_ARGUMENT);

    expected_led.enable = 1;
    expected_led.brightness = 500;
#ifdef USE_RPC
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_0, (void *)&expected_led, ITEM_SIZE_LED_EXT_0), ERR_SUCCESS);
#else
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_0, (void *)&expected_led, ITEM_SIZE_LED_EXT_0),
              ERR_NOT_SUPPORTED);
#endif
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_5, (void *)&expected_led, ITEM_SIZE_LED_EXT_5),
              ERR_NOT_SUPPORTED);

    expected_led.enable = 1;
    expected_led.brightness = 0xFFFF;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&expected_led, ITEM_SIZE_LED_EXT_1), ERR_SUCCESS);
    usleep(1000 * MULT_MS_US);
    expected_led.enable = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_1, (void *)&expected_led, ITEM_SIZE_LED_EXT_1), ERR_SUCCESS);

    expected_led.enable = 1;
    expected_led.brightness = 0xFFFF;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_2, (void *)&expected_led, ITEM_SIZE_LED_EXT_2), ERR_SUCCESS);
    usleep(1000 * MULT_MS_US);
    expected_led.enable = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_2, (void *)&expected_led, ITEM_SIZE_LED_EXT_2), ERR_SUCCESS);

    expected_led.enable = 1;
    expected_led.brightness = 0xFFFF;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_3, (void *)&expected_led, ITEM_SIZE_LED_EXT_3), ERR_SUCCESS);
    usleep(1000 * MULT_MS_US);
    expected_led.enable = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_3, (void *)&expected_led, ITEM_SIZE_LED_EXT_3), ERR_SUCCESS);

    expected_led.enable = 1;
    expected_led.brightness = 0xFFFF;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_4, (void *)&expected_led, ITEM_SIZE_LED_EXT_4), ERR_SUCCESS);
    usleep(1000 * MULT_MS_US);
    expected_led.enable = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_LED_EXT_4, (void *)&expected_led, ITEM_SIZE_LED_EXT_4), ERR_SUCCESS);
}

TEST_F(item_test, config_block_get)
{
    uint32_t size = 0, size_2, count = 0;
    uint8_t data_buffer[1000];
    uint8_t id;

    ASSERT_EQ(as7341_get_configuration(DEV_ID, NULL, &size), ERR_SUCCESS);
    size_2 = size;
    ASSERT_EQ(as7341_get_configuration(DEV_ID, data_buffer, &size_2), ERR_SUCCESS);

    ASSERT_GT(size, size_2); /* size of 4 unsupported items */

    id = 1;
    while (count < size_2) {
        if ((ITEM_ID_LED_EXT_5 == id) || (ITEM_ID_TEMP_EXT_0 == id) || (ITEM_ID_TEMP_EXT_5 == id)) {
            id++;
        }
#ifndef USE_RPC
        else if (ITEM_ID_LED_EXT_0 == id) {
            id++;
        }
#endif

        ASSERT_EQ(id, data_buffer[count + 1]);
        count += data_buffer[count] + 2;
        id++;
    }
}

TEST_F(item_test, config_block_set)
{
    uint8_t data_buffer[1000];

    data_buffer[0] = ITEM_SIZE_ATIME;
    data_buffer[1] = ITEM_ID_ATIME;
    data_buffer[2] = 25;
    data_buffer[3] = ITEM_SIZE_ASTEP;
    data_buffer[4] = ITEM_ID_ASTEP;
    data_buffer[5] = 0x1F;
    data_buffer[6] = 0x1A;
    data_buffer[7] = ITEM_SIZE_AGAIN;
    data_buffer[8] = ITEM_ID_AGAIN;
    data_buffer[9] = 4;

    ASSERT_EQ(as7341_set_configuration(DEV_ID, data_buffer, 10), ERR_SUCCESS);
}

TEST_F(item_test, config_block_get_set)
{
    uint32_t size = 0;
    uint8_t data_buffer[1000];

    ASSERT_EQ(as7341_get_configuration(DEV_ID, NULL, &size), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_configuration(DEV_ID, data_buffer, &size), ERR_SUCCESS);

    ASSERT_EQ(as7341_set_configuration(DEV_ID, data_buffer, size), ERR_SUCCESS);
}

TEST_F(item_test, parameter_temperature)
{
    int32_t temperature;
    int32_t min_temp = 20000;
    int32_t max_temp = 40000;

    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_TEMP_EXT_0, (void *)&temperature, ITEM_SIZE_TEMP_EXT_0),
              ERR_NOT_SUPPORTED);

#ifdef USE_RPC
    err_code_t result;
    usleep(100 * MULT_MS_US); // Sleep that first measurement is finished
    result = as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_0, (void *)&temperature, ITEM_SIZE_TEMP_EXT_0);
    ASSERT_TRUE(ERR_SUCCESS == result || ERR_NOT_SUPPORTED == result);
    if (ERR_SUCCESS == result) {
        ASSERT_LE(min_temp, temperature);
        ASSERT_GE(max_temp, temperature);
    }
#else
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_0, (void *)&temperature, ITEM_SIZE_TEMP_EXT_0),
              ERR_NOT_SUPPORTED);
#endif

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_5, (void *)&temperature, ITEM_SIZE_TEMP_EXT_5),
              ERR_NOT_SUPPORTED);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_1, (void *)&temperature, ITEM_SIZE_TEMP_EXT_1), ERR_SUCCESS);
    ASSERT_LE(min_temp, temperature);
    ASSERT_GE(max_temp, temperature);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_2, (void *)&temperature, ITEM_SIZE_TEMP_EXT_2), ERR_SUCCESS);
    ASSERT_LE(min_temp, temperature);
    ASSERT_GE(max_temp, temperature);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_3, (void *)&temperature, ITEM_SIZE_TEMP_EXT_3), ERR_SUCCESS);
    ASSERT_LE(min_temp, temperature);
    ASSERT_GE(max_temp, temperature);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TEMP_EXT_4, (void *)&temperature, ITEM_SIZE_TEMP_EXT_4), ERR_SUCCESS);
    ASSERT_LE(min_temp, temperature);
    ASSERT_GE(max_temp, temperature);
}

TEST_F(item_test, parameter_fgain)
{
    uint8_t fgain;

    /* check default fgain */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain, ITEM_SIZE_FGAIN), ERR_SUCCESS);
    ASSERT_EQ(5, fgain);

    fgain = 10;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain, ITEM_SIZE_FGAIN), ERR_SUCCESS);
    fgain = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain, ITEM_SIZE_FGAIN), ERR_SUCCESS);
    ASSERT_EQ(10, fgain);

    fgain = 11;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FGAIN, (void *)&fgain, ITEM_SIZE_FGAIN), ERR_ARGUMENT);
}

TEST_F(item_test, parameter_ftime)
{
    uint16_t ftime;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_SUCCESS);
    ASSERT_EQ(359, ftime);

    ftime = 179;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_SUCCESS);
    ftime = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_SUCCESS);
    ASSERT_EQ(179, ftime);

    ftime = 0xFFFF;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_ARGUMENT);
}

TEST_F(item_test, parameter_ftime_us)
{
    uint32_t ftime_us, expected_ftime_us;
    uint16_t ftime;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ASSERT_EQ(1000, ftime_us);

    /* first test */
    expected_ftime_us = 2000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&expected_ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ftime_us = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ASSERT_EQ(expected_ftime_us, ftime_us);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_SUCCESS);
    ASSERT_EQ(719, ftime);

    /* second test */
    expected_ftime_us = 2;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&expected_ftime_us, ITEM_SIZE_FTIME_US), ERR_ARGUMENT);

    expected_ftime_us = 3;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&expected_ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ftime_us = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ASSERT_EQ(expected_ftime_us, ftime_us);

    expected_ftime_us = 5689;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&expected_ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ftime_us = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&ftime_us, ITEM_SIZE_FTIME_US), ERR_SUCCESS);
    ASSERT_EQ(expected_ftime_us, ftime_us);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FTIME, (void *)&ftime, ITEM_SIZE_FTIME), ERR_SUCCESS);
    ASSERT_EQ(2047, ftime);

    expected_ftime_us = 5690;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FTIME_US, (void *)&expected_ftime_us, ITEM_SIZE_FTIME_US), ERR_ARGUMENT);
}

TEST_F(item_test, parameter_fchannels)
{
    uint32_t fchannels;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels, ITEM_SIZE_FCHANNELS), ERR_SUCCESS);
    ASSERT_EQ(FCHANNEL_FLICKER_MASK, fchannels);

    fchannels = FCHANNEL_NIR_MASK;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels, ITEM_SIZE_FCHANNELS), ERR_SUCCESS);
    fchannels = 0;
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels, ITEM_SIZE_FCHANNELS), ERR_SUCCESS);
    ASSERT_EQ(FCHANNEL_NIR_MASK, fchannels);

    fchannels = (1 << 20) - 1;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels, ITEM_SIZE_FCHANNELS), ERR_SUCCESS);

    fchannels = (1 << 20);
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_FCHANNELS, (void *)&fchannels, ITEM_SIZE_FCHANNELS), ERR_ARGUMENT);
}

TEST_F(item_test, parameter_timestamp)
{
    uint64_t timestamp1, timestamp2;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TIMESTAMP, (void *)&timestamp1, ITEM_SIZE_TIMESTAMP), ERR_SUCCESS);

    usleep(500 * MULT_MS_US);

    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_TIMESTAMP, (void *)&timestamp2, ITEM_SIZE_TIMESTAMP), ERR_SUCCESS);

    ASSERT_LT(timestamp2 - timestamp1, 520000);
    ASSERT_GT(timestamp2 - timestamp1, 500000);
}

TEST_F(item_test, parameter_auto_gain)
{
    struct as7341_auto_gain auto_gain;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);
    ASSERT_EQ(GAIN_0_5X, auto_gain.lower_limit);
    ASSERT_EQ(GAIN_0_5X, auto_gain.upper_limit);

    /* check wrong parameter ranges */
    auto_gain.lower_limit = GAIN_0_5X;
    auto_gain.upper_limit = 11;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_ARGUMENT);
    auto_gain.lower_limit = 11;
    auto_gain.upper_limit = GAIN_0_5X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_ARGUMENT);
    auto_gain.lower_limit = GAIN_1X;
    auto_gain.upper_limit = GAIN_0_5X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_ARGUMENT);

    /* check good parameter range */
    auto_gain.lower_limit = GAIN_0_5X;
    auto_gain.upper_limit = GAIN_512X;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_AUTO_GAIN_RANGE, (void *)&auto_gain, ITEM_SIZE_AUTO_GAIN_RANGE),
              ERR_SUCCESS);
}

TEST_F(item_test, parameter_gain_factors)
{
    uint16_t gain_factors[AS7341_GAIN_FACTOR_NUM];

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)gain_factors, ITEM_SIZE_GAIN_FACTORS), ERR_SUCCESS);
    ASSERT_EQ(9770, gain_factors[0]);
    ASSERT_EQ(9770, gain_factors[1]);
    ASSERT_EQ(9770, gain_factors[2]);
    ASSERT_EQ(9620, gain_factors[3]);
    ASSERT_EQ(10000, gain_factors[4]);
    ASSERT_EQ(10000, gain_factors[5]);
    ASSERT_EQ(10000, gain_factors[6]);
    ASSERT_EQ(10000, gain_factors[7]);
    ASSERT_EQ(10000, gain_factors[8]);
    ASSERT_EQ(10130, gain_factors[9]);
    ASSERT_EQ(10320, gain_factors[10]);

    /* check wrong parameter ranges */
    gain_factors[0] = 0;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)&gain_factors, ITEM_SIZE_GAIN_FACTORS),
              ERR_ARGUMENT);
    gain_factors[0] = 20001;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)&gain_factors, ITEM_SIZE_GAIN_FACTORS),
              ERR_ARGUMENT);

    /* check good parameter range */
    gain_factors[0] = 1;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)&gain_factors, ITEM_SIZE_GAIN_FACTORS),
              ERR_SUCCESS);
    gain_factors[0] = 20000;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_GAIN_FACTORS, (void *)&gain_factors, ITEM_SIZE_GAIN_FACTORS),
              ERR_SUCCESS);
}

TEST_F(item_test, parameter_sync_mode)
{
    uint8_t enabled;

    /* check default value */
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_SUCCESS);
    ASSERT_FALSE(enabled);

    enabled = true;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_SUCCESS);
    ASSERT_TRUE(enabled);

    enabled = false;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_SUCCESS);
    ASSERT_EQ(as7341_get_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_SUCCESS);
    ASSERT_FALSE(enabled);

    /* check wrong parameter ranges */
    enabled = 2;
    ASSERT_EQ(as7341_set_item(DEV_ID, ITEM_ID_SYNC_MODE, (void *)&enabled, sizeof(enabled)), ERR_ARGUMENT);
}